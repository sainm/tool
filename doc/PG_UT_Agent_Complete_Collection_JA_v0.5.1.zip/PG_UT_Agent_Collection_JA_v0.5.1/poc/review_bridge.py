"""同一ターンへのレビュー結果返却を検証する、ローカル専用 MCP サーバー。"""
from __future__ import annotations

import argparse
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import secrets
import sqlite3
import sys
import threading
import time


BASELINE = {
    "scope": "数量登録画面",
    "work": "数量チェックの上限値を変更",
    "purpose": "上限値以内の数量を受け入れ、超過値の登録を止める。",
    "condition": "",
    "caseName": "",
    "caseCondition": "",
}
TRIAL_DIR = Path(__file__).resolve().parent
IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")


class ReviewError(Exception):
    """利用者に返す検証エラー。"""


def json_text(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


class ReviewBridge:
    def __init__(self, database: Path):
        self.database = database
        database.parent.mkdir(parents=True, exist_ok=True)
        self.changed = threading.Condition()
        self.write_lock = threading.Lock()
        self.waits: dict[object, tuple[str, threading.Event]] = {}
        self.link_base = ""
        with closing(self.open_db()) as db, db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    review_id TEXT PRIMARY KEY,
                    job_id TEXT NOT NULL,
                    attempt_id TEXT NOT NULL,
                    wait_token TEXT NOT NULL,
                    browser_token TEXT NOT NULL,
                    decision TEXT,
                    event_id TEXT,
                    received INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(job_id, attempt_id)
                )
            """)

    def open_db(self):
        db = sqlite3.connect(self.database, timeout=5)
        db.row_factory = sqlite3.Row
        return db

    def request_review(self, job_id: str, attempt_id: str) -> dict:
        if not all(isinstance(key, str) and IDENTIFIER.fullmatch(key)
                   for key in (job_id, attempt_id)):
            raise ReviewError("案件 ID と試行 ID を確認してください。")
        with closing(self.open_db()) as db, db:
            db.execute(
                """INSERT INTO reviews (review_id, job_id, attempt_id, wait_token, browser_token)
                   VALUES (?, ?, ?, ?, ?) ON CONFLICT(job_id, attempt_id) DO NOTHING""",
                (secrets.token_hex(16), job_id, attempt_id,
                 secrets.token_urlsafe(24), secrets.token_urlsafe(24)),
            )
            row = db.execute("SELECT * FROM reviews WHERE job_id=? AND attempt_id=?",
                             (job_id, attempt_id)).fetchone()
        return {
            "review_id": row["review_id"],
            "wait_token": row["wait_token"],
            "review_url": self.link_base + "/review/" + row["review_id"] + "/" + row["browser_token"],
            "instruction": "この会話を開いたまま、レビュー画面で確認します。",
        }

    def read_review(self, review_id: str) -> sqlite3.Row:
        with closing(self.open_db()) as db:
            row = db.execute("SELECT * FROM reviews WHERE review_id=?", (review_id,)).fetchone()
        if row is None:
            raise ReviewError("レビュー情報を確認できません。")
        return row

    def verify_token(self, review_id: str, token: str, field: str) -> sqlite3.Row:
        row = self.read_review(review_id)
        if not isinstance(token, str) or not secrets.compare_digest(token, row[field]):
            raise ReviewError("レビュー情報を確認できません。")
        return row

    def browser_status(self, review_id: str, token: str) -> dict:
        with self.changed:
            row = self.verify_token(review_id, token, "browser_token")
            draft = None
            if row["decision"]:
                draft = BASELINE | {change["field"]: change["after"]
                                    for change in json.loads(row["decision"])["changes"]}
                if draft["caseName"]:
                    draft["caseCondition"] = draft["condition"]
            return {
                "connected": any(rid == review_id for rid, _ in self.waits.values()),
                "approved": row["decision"] is not None,
                "delivered": bool(row["received"]),
                "draft": draft,
            }

    def approve(self, review_id: str, token: str, draft: dict) -> dict:
        self.verify_token(review_id, token, "browser_token")
        if not isinstance(draft, dict) or set(draft) != set(BASELINE):
            raise ReviewError("編集内容を確認してください。")
        if not all(isinstance(value, str) and len(value) <= 500 for value in draft.values()):
            raise ReviewError("入力値を確認してください。")
        normalized = {key: draft[key].strip() for key in BASELINE}
        if not all(normalized[key] for key in ("scope", "work", "purpose")):
            raise ReviewError("適用画面、改修作業、検証内容は必須です。")
        condition = normalized["condition"]
        case = normalized["caseName"]
        if normalized == BASELINE or ((condition or case) and
                                      not (condition and case and condition == normalized["caseCondition"])):
            raise ReviewError("変更内容と必須条件のテストケースを確認してください。")
        decision = {
            "subject_revision": "r12",
            "release_revision": "r13",
            "changes": [{"field": key, "before": old, "after": normalized[key]}
                        for key, old in BASELINE.items()
                        if key != "caseCondition" and old != normalized[key]],
            "planned_coverage": {"mapped": 8 if condition else 7, "required": 8 if condition else 7},
            "next_action": "承認版と変更点を元の会話に表示する。検証専用のためリポジトリ変更とテスト実行は行わない。",
        }
        payload = json_text(decision)
        with self.changed, closing(self.open_db()) as db, db:
            changed = db.execute(
                """UPDATE reviews SET decision=?, event_id=?
                   WHERE review_id=? AND decision IS NULL""",
                (payload, secrets.token_hex(16), review_id),
            ).rowcount
            if not changed:
                current = db.execute("SELECT decision FROM reviews WHERE review_id=?", (review_id,)).fetchone()
                if current["decision"] != payload:
                    raise ReviewError("承認済みの版が変更されています。")
        with self.changed:
            self.changed.notify_all()
        return self.browser_status(review_id, token)

    def register_wait(self, rpc_id, review_id: str, token: str, timeout_seconds: int):
        self.verify_token(review_id, token, "wait_token")
        if type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 900:
            raise ReviewError("待機時間は 1～900 秒で指定してください。")
        with self.changed:
            if any(other == review_id for other, _ in self.waits.values()):
                raise ReviewError("同じレビューはすでに待機中です。")
            cancelled = threading.Event()
            self.waits[rpc_id] = (review_id, cancelled)
        threading.Thread(target=self.wait, args=(rpc_id, review_id, cancelled, timeout_seconds),
                         daemon=True).start()

    def wait(self, rpc_id, review_id: str, cancelled: threading.Event, timeout_seconds: int):
        deadline = time.monotonic() + timeout_seconds
        try:
            with self.changed:
                while not cancelled.is_set():
                    row = self.read_review(review_id)
                    if row["decision"] is not None:
                        answer = {
                            "status": "approved",
                            "event_id": row["event_id"],
                            "job_id": row["job_id"],
                            "attempt_id": row["attempt_id"],
                            **json.loads(row["decision"]),
                        }
                        return self.tool_reply(rpc_id, answer)
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return self.tool_reply(rpc_id, {"status": "timeout", "review_id": review_id})
                    self.changed.wait(remaining)
                self.tool_reply(rpc_id, {"status": "cancelled", "review_id": review_id})
        finally:
            with self.changed:
                self.waits.pop(rpc_id, None)

    def cancel(self, rpc_id):
        with self.changed:
            if rpc_id in self.waits:
                self.waits[rpc_id][1].set()
                self.changed.notify_all()

    def acknowledge(self, review_id: str, token: str, event_id: str) -> dict:
        with closing(self.open_db()) as db, db:
            row = self.verify_token(review_id, token, "wait_token")
            if row["event_id"] is None or row["event_id"] != event_id:
                raise ReviewError("返却された承認イベントを確認してください。")
            db.execute("UPDATE reviews SET received=1 WHERE review_id=? AND event_id=?", (review_id, event_id))
        return {"received": True, "event_id": event_id}

    def emit(self, message):
        with self.write_lock:
            print(json_text({"jsonrpc": "2.0", **message}), flush=True)

    def tool_reply(self, rpc_id, value, failure=False):
        self.emit({"id": rpc_id, "result": {
            "isError": failure,
            "content": [{"type": "text", "text": json_text(value)}],
        }})


def tool_schema(name, description, properties, required):
    return {"name": name, "description": description, "inputSchema": {
        "type": "object", "properties": properties, "required": required,
        "additionalProperties": False,
    }}


TEXT = {"type": "string"}
TOOLS = [
    tool_schema("request_review", "日本語の模擬レビュー画面を同じ会話で開く。",
                {"job_id": TEXT, "attempt_id": TEXT}, ["job_id", "attempt_id"]),
    tool_schema("wait_for_review", "レビュー結果を現在の MCP 呼び出しで待つ。新しい会話を作らない。",
                {"review_id": TEXT, "wait_token": TEXT,
                 "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 900}},
                ["review_id", "wait_token"]),
    tool_schema("ack_review_delivery", "返却イベントの受領を記録する。",
                {"review_id": TEXT, "wait_token": TEXT, "event_id": TEXT},
                ["review_id", "wait_token", "event_id"]),
]


def serve_mcp(bridge: ReviewBridge):
    for line in sys.stdin:
        try:
            message = json.loads(line)
        except ValueError:
            bridge.emit({"id": None, "error": {"code": -32700, "message": "Invalid JSON"}})
            continue
        if not isinstance(message, dict):
            continue
        rpc_id = message.get("id")
        method = message.get("method")
        params = message.get("params", {})
        if not isinstance(params, dict):
            continue
        if method == "notifications/cancelled":
            bridge.cancel(params.get("requestId"))
        if "id" not in message or method is None:
            continue
        try:
            if method == "initialize":
                version = params.get("protocolVersion")
                supported = {"2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25"}
                bridge.emit({"id": rpc_id, "result": {
                    "protocolVersion": version if isinstance(version, str) and version in supported else "2025-11-25",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "pgut-review-trial", "version": "0.4.0"},
                }})
            elif method == "ping":
                bridge.emit({"id": rpc_id, "result": {}})
            elif method == "tools/list":
                bridge.emit({"id": rpc_id, "result": {"tools": TOOLS}})
            elif method == "tools/call":
                args = params.get("arguments", {})
                if params.get("name") == "request_review":
                    bridge.tool_reply(rpc_id, bridge.request_review(args["job_id"], args["attempt_id"]))
                elif params.get("name") == "wait_for_review":
                    bridge.register_wait(rpc_id, args["review_id"], args["wait_token"],
                                         args.get("timeout_seconds", 300))
                elif params.get("name") == "ack_review_delivery":
                    bridge.tool_reply(rpc_id, bridge.acknowledge(args["review_id"], args["wait_token"], args["event_id"]))
                else:
                    raise ReviewError("検証用ツールを特定できません。")
            else:
                bridge.emit({"id": rpc_id, "error": {"code": -32601, "message": "Method not found"}})
        except (ReviewError, KeyError, TypeError) as error:
            bridge.tool_reply(rpc_id, {"message": str(error)}, failure=True)


def handler_for(bridge: ReviewBridge):
    class ReviewHandler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            return

        def respond(self, code: int, payload, html=False):
            data = (payload if html else json_text(payload)).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/html; charset=utf-8" if html else "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def route(self):
            if self.headers.get("Host") != bridge.link_base.split("://", 1)[1]:
                raise ReviewError("接続先を確認してください。")
            segments = self.path.split("/")
            if len(segments) not in (4, 5) or segments[1] != "review":
                raise ReviewError("レビュー URL を確認してください。")
            _, _, review_id, token, *action = segments
            bridge.verify_token(review_id, token, "browser_token")
            return review_id, token, (action[0] if action else "")

        def do_GET(self):
            try:
                review_id, token, action = self.route()
                if action == "state":
                    return self.respond(200, bridge.browser_status(review_id, token))
                if action:
                    raise ReviewError("レビュー URL を確認してください。")
                fragment = (TRIAL_DIR / "review.html").read_text(encoding="utf-8")
                adapter = (TRIAL_DIR / "connected.js").read_text(encoding="utf-8")
                self.respond(200, '<!doctype html><html lang="ja"><meta charset="utf-8">'
                             '<meta name="viewport" content="width=device-width,initial-scale=1">'
                             '<title>改修・テストレビュー</title>'
                             '<style>body{max-width:1040px;margin:24px auto;padding:0 14px}</style>'
                             + fragment.replace('id="review-jp"', 'id="review-jp" data-connected-example="true"', 1)
                             + '<script>' + adapter + '</script></html>', html=True)
            except ReviewError as error:
                self.respond(404, {"message": str(error)})

        def do_POST(self):
            try:
                review_id, token, action = self.route()
                if action != "approve" or self.headers.get("Origin") != bridge.link_base:
                    return self.respond(403, {"message": "承認操作の接続元を確認してください。"})
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 16_384:
                    raise ReviewError("入力サイズを確認してください。")
                draft = json.loads(self.rfile.read(length))
                self.respond(200, bridge.approve(review_id, token, draft))
            except ReviewError as error:
                self.respond(409, {"message": str(error)})
            except (TypeError, ValueError):
                self.respond(400, {"message": "入力形式を確認してください。"})

    return ReviewHandler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, default=TRIAL_DIR / ".trial" / "reviews.sqlite3")
    args = parser.parse_args()
    bridge = ReviewBridge(args.db)
    with ThreadingHTTPServer(("127.0.0.1", 0), handler_for(bridge)) as http:
        bridge.link_base = "http://127.0.0.1:" + str(http.server_port)
        threading.Thread(target=http.serve_forever, daemon=True).start()
        try:
            serve_mcp(bridge)
        finally:
            http.shutdown()


if __name__ == "__main__":
    main()

