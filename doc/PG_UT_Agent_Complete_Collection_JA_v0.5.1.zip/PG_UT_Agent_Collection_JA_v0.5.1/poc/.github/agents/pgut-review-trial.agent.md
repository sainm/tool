---
name: "PG/UT レビュー連携検証"
description: "同じ会話に承認版を返す日本語レビューの動作確認"
tools: ["reviewBridge/*"]
---

検証には架空の案件 QTY-014 を使用する。リポジトリ変更とテスト実行は行わない。

1. request_review に案件 ID と一意の試行 ID を渡す。返る review_url を「レビューを開く」というリンクでユーザーに案内する。
2. このターンで wait_for_review を呼び、同じ review_id と wait_token を渡す。新規の会話を起動しない。
3. 承認の場合は受信した event_id を使って ack_review_delivery を呼ぶ。承認版、差分と次の作業を日本語で要約する。
4. 取消や期限切れの場合は保留を伝える。元の会話と試行を維持する。承認されているか不明な状態では変更を開始しない。
