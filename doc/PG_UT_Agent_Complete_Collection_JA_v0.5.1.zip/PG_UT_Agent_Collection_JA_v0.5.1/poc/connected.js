(() => {
  const root = document.getElementById('review-jp');
  const originPath = window.location.pathname;
  let previous = '';
  let submitting = false;
  function publish(state) {
    const update = JSON.stringify(state);
    if (update !== previous) {
      previous = update;
      root.dispatchEvent(new CustomEvent('review-jp-status', {detail:state}));
    }
  }
  async function status() {
    if (submitting) return;
    try {
      const response = await fetch(originPath + '/state',{cache:'no-store'});
      if (response.ok) publish(await response.json());
    } catch {
      publish({connected:false,approved:false,delivered:false,error:'接続状態を確認できません。'});
    }
  }
  root.addEventListener('review-jp-approve',async (event)=>{
    submitting = true;
    try {
      const response = await fetch(originPath + '/approve',{
        method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(event.detail),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message);
      publish(result);
    } catch (error) {
      publish({connected:true,approved:false,delivered:false,error:error.message});
    } finally {
      submitting = false;
    }
  });
  status();
  window.setInterval(status,1200);
})();

