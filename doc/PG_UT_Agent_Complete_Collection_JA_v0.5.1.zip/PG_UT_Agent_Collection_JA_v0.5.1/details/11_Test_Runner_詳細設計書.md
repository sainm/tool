# 11　Test Runner 詳細設計書

> 文書ID：PGUT-D11　｜　版：1.0 設計案　｜　作成日：2026-11-24  
> 基準資料：PG/UT Agent UI Test Design v0.3（第11, 18, 19章）  
> 状態：詳細設計案・未実装／実システム未検証。業務名、ID、画面、数値、API は明示のない限り提案例。

[設計書一覧](README.md)

> 適用基準は [統合詳細設計書 v0.5.1](../PG_UT_Agent_Integrated_Detailed_Design_JA_v0.5.1.md)。大規模変更の開発・テストバッチは §12、画面操作と元の Copilot 会話への返却は §9～§10、共通契約・受入は §13 を参照する。

## 1. 役割と実行単位

承認済 DSL を解釈して Playwright API を呼び出す固定エンジン。AI による毎ステップの判断・Playwright ソース生成は不要。Run は task_id、revision、snapshot_id、code_revision、environment_id、lease_ids を固定する。ブラウザは Tool Server が所有し、Recorder、Inspector、Runner の操作権を切り替える。

**図 11-01　実行制御（設計図）**

```mermaid
flowchart TD
  n0["実行要求"]
  n1["承認・版・環境検査"]
  n2["データ租約・変数検査"]
  n3["画面状態・Binding検査"]
  n4["STARTED記録"]
  n5["Playwright API"]
  n6["事後状態・断言"]
  n7["結果・Evidence"]
  n8["次ステップ"]
  n9["更新結果不明"]
  n10["RECOVERY_REQUIRED"]
  n0 --> n1
  n1 --> n2
  n2 --> n3
  n3 --> n4
  n4 --> n5
  n5 --> n6
  n6 --> n7
  n7 --> n8
  n8 --> n3
  n5 --> n9
  n9 --> n10
```

## 2. ステップ処理

|順序|処理|失敗時|
|---|---|---|
|1|承認ハッシュ、対象環境、コード版、Run排他|APPROVAL_REQUIRED / VERSION_MISMATCH|
|2|lease、変数型・参照、業務前提、副作用許可|DATA_UNSAFE / BLOCKED|
|3|画面署名、Frame、表、行キー、Locator一意性、操作可能性|AMBIGUOUS_TARGET / STATE_MISMATCH|
|4|ステップ開始、意図、試行ID、副作用を永続化|永続化失敗なら操作禁止|
|5|操作種別の固定実装を呼出、条件待機|TIMEOUT / 操作失敗|
|6|事後状態、期待結果、DB等の許可済断言|FAIL 又は INCONCLUSIVE|
|7|観測値、時刻、証跡、終端状態を保存|書込結果不明はRECOVERY_REQUIRED|
|8|依存成功の場合のみ次へ|後続依存ステップはNOT_RUN|
画面署名はURL、タイトル、Form action、必須/禁止要素、Table見出し、ボタン状態等で識別する。待機は指定条件と時間上限を用いる。DB 断言は確認済の読み取りクエリ参照のみとする。画面上の登録成功表示は未確認の全DB更新を証明しない。

## 3. 実行状態・復旧

**図 11-02　停止・回復の分岐（設計図）**

```mermaid
flowchart TD
  n0["READY"]
  n1["RUNNING"]
  n2["PAUSED"]
  n3["事前条件再検証"]
  n4["BLOCKED"]
  n5["FAILED"]
  n6["COMPLETED"]
  n7["RECOVERY_REQUIRED"]
  n8["人による副作用確認"]
  n9["新Run又は安全な継続"]
  n0 --> n1
  n1 --> n2
  n2 --> n3
  n3 --> n1
  n3 --> n4
  n1 --> n5
  n1 --> n6
  n1 --> n7
  n7 --> n8
  n8 --> n9
  n8 --> n4
```

|障害|復旧方法|
|---|---|
|Locator失敗|同一業務項目を再調査、定義変更なら再承認|
|ブラウザ存続・断点|状態とleaseを再確認し継続|
|セッション消失|ログインだけで業務状態は復元不可。チェックポイントを再構築又は新Run|
|登録クリック後のタイムアウト|自動再クリック禁止。許可済照会で結果確認。不明ならRECOVERY_REQUIRED|
|プロセス異常終了|STARTEDで未終了の書込ステップを不確定として隔離|
|コード欠陥|MainからPG/UTへ戻し、新コード版で回帰|

## 4. 共通部品と変数

ログイン、メニュー、検索、業務行選択、日付、選択肢、ファイル操作、メッセージ、DB検証をプロジェクト設定可能な部品として管理する。部品内部も承認済操作と同じ副作用制御に従う。変数は Case/Run の scope、型、secret を持つ。画面から取得した業務番号は後続検索へ渡せるが、仕様の期待値として自動採用しない。

## 5. 結果判定・並行性

PASS は対象の必須断言が全て確認された場合のみ。FAIL は期待と実際の不一致、BLOCKED は前提・権限不足、NOT_RUN は未実行、INCONCLUSIVE は証拠不足とする。Run 全体の COMPLETED と Case の PASS を混同しない。デバッグは debug run として独立記録。1セッション1操作主体とし、並列実行は独立Context、独立データ、外部副作用の隔離が確認できた場合のみ許す。

**参考図 22　画面状態識別**

```mermaid
flowchart TD
 N0["業務レベル計画"]
 N1["画面単位の調査"]
 N2["構造化結果"]
 N3["外部実行状態・変数・証跡"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
```

**参考図 23　コンテキスト分割**

```mermaid
flowchart TD
 A[失敗証跡] --> B[Locator・待機]
 A --> C[データ・環境]
 A --> D[テスト手順・仕様]
 A --> E[製品不具合]
 B --> F[検証付き修正]
 C --> G[前提条件を再構築]
 D --> H[人工承認]
 E --> I[PG工程へ戻す]
```

**参考図 24　失敗の分類**

```mermaid
flowchart TD
 A[実行停止・証跡保存] --> B{副作用と前提状態を確認}
 B -->|再開可能| C[現在ステップから再開]
 B -->|復旧可能| D[データ復旧・チェックポイント再実行]
 B -->|不明または不可逆| E[隔離・人工判断]
```

![参考図 35　実行状態と復旧](../figures/figure-51bf0030dcf36b8f.png)

## 関連設計書

- [04　テストデータ Agent 詳細設計書](04_テストデータ_Agent_詳細設計書.md)
- [07　Test DSL データ構造設計書](07_Test_DSL_データ構造設計書.md)
- [08　Legacy UI Inspector 詳細設計書](08_Legacy_UI_Inspector_詳細設計書.md)
- [12　MCP インターフェース仕様書](12_MCP_インターフェース仕様書.md)
- [14　テスト成果物・Evidence 設計書](14_テスト成果物・Evidence_設計書.md)

## 残課題・確定条件

実システムの代表画面、設計書、データ権限、対象 Copilot harness、既存 MCP 契約及び成果物テンプレートを確認して差分改訂する。未確認仕様・実装・試験結果を確定済みとして扱わない。
