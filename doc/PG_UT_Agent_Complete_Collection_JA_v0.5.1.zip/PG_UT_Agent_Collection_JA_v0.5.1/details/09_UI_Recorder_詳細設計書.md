# 09　UI Recorder 詳細設計書

> 文書ID：PGUT-D09　｜　版：1.0 設計案　｜　作成日：2026-11-24  
> 基準資料：PG/UT Agent UI Test Design v0.3（第9, 20.2章）  
> 状態：詳細設計案・未実装／実システム未検証。業務名、ID、画面、数値、API は明示のない限り提案例。

[設計書一覧](README.md)

> 適用基準は [統合詳細設計書 v0.5.1](../PG_UT_Agent_Integrated_Detailed_Design_JA_v0.5.1.md)。大規模変更の開発・テストバッチは §12、画面操作と元の Copilot 会話への返却は §9～§10、共通契約・受入は §13 を参照する。

## 1. 目的・構成

人工で Chrome を操作したイベントから、日文自然言語の候補を生成する。Playwright Codegen ソースを成果物としない。初期は軽量イベント収集器を Tool Server と同一ブラウザ Context に配置する。Playwright の addInitScript / exposeBinding 等を候補とし、既存サーバへの改修は不要。対象ブラウザの接続方式で注入・Frame 対応を検証する。

**図 09-01　録制処理（設計図）**

```mermaid
flowchart TD
  n0["操作前DOM・イベント"]
  n1["イベント収集"]
  n2["順序付け・重複除去"]
  n3["機密値除去"]
  n4["Table・項目意味対応"]
  n5["テンプレート自然言語"]
  n6["曖昧・Copilot補完"]
  n7["Studio草稿・人の確認"]
  n0 --> n1
  n1 --> n2
  n2 --> n3
  n3 --> n4
  n4 --> n5
  n4 --> n6
  n6 --> n5
  n5 --> n7
```

## 2. モード

|モード|動作|
|---|---|
|操作記録|通常の click/input/change/submit/navigation/popup を採取。人の操作は実際に実行されるためデータ安全条件を満たす|
|検証記録|対象要素を選択し断言候補を追加。通常クリックの副作用を抑制し、期待値を人・正式仕様が確定|
|要素拾取|binding 候補を取得し、選択位置・画面状態を保存|
|停止|録制セッションを閉じ、イベントを正規化・草稿化|
検証拾取のクリック抑制が対象UIで確実でない場合はスクリーンショット・DOM一覧から選択し、実クリックを行わない。

## 3. イベントデータ

|属性|内容|
|---|---|
|recording_id, event_id, sequence, captured_at|順序・重複管理|
|page_id, frame_id, generation|文書の同一性、遷移対応|
|kind|click/input/change/key/submit/navigation/popup 等|
|target_snapshot|操作前の tag/name/type、form/table、行キー・列パス候補|
|value_ref|入力値又は変数参照。秘密値禁止|
|state_before/state_after|画面識別候補、遷移証拠|
|confidence/status|候補、確認済、曖昧、除外|
|source_event_ids|生成手順との追跡|

## 4. 正規化

- IME composition 中は確定前の文字を保存せず、compositionend と最終 input を統合する。
- 同一要素への連続 input は確定値の一手順にまとめ、blur・submit・対象変更で確定する。途中値が業務処理を発火する場合は統合しない。
- checkbox/select の click と change、Enter と submit 等は同一操作候補として相関。実際の意味が不明なら両イベントを保持してレビューする。
- 操作前の要素文脈を先に保存し、遷移後に旧DOMを取得する方式を避ける。Frame ごとの順序と Page の遷移を関連づける。
- password、token、個人情報、ファイル実パスは記録前にフィルタ又は変数化する。録制データを自動入庫しない。

## 5. 例・変換

|原イベント（仮想）|自然言語候補|
|---|---|
|fill gyomuNo A001|業務番号に「A001」を入力する。|
|click value=検索|検索ボタンを押下する。|
|select row S002|商品番号「S002」の明細を選択する。|
|input quantity in S002 =999|商品番号「S002」の明細の数量に999を入力する。|
|click 確認|確認ボタンを押下する。|
値の固定・変数化は Studio で選択。行の意味が不明なら曖昧と表示し、勝手に先頭行・固定 nth を採用しない。観測結果は期待値ではない。仕様がない場合は正式断言の承認待ちにする。

**参考図 18　操作・検証録制**

```mermaid
flowchart TD
 N0["生イベント"]
 N1["機密情報除外"]
 N2["入力イベント集約"]
 N3["DOM・Table文脈付与"]
 N4["自然言語候補・DSL草案"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
 N3 --> N4
```

![参考図 37　録制イベント正規化](../figures/figure-ff60d16ccdde0af2.png)

## 6. API・状態・異常

start_recording(session_id, mode) → recording_id。stop_recording(recording_id) → event_refs, draft_step_refs, gaps。get_recorded_events はページングとマスク済結果を返す。RECORDING → STOPPING → NORMALIZED → REVIEW_REQUIRED。ブラウザ切断・イベント欠落は PARTIAL、競合操作は SESSION_BUSY。再録制時は元イベントを消さず別セッションにする。録制中は Runner 操作権をロックする。

## 7. 技術参照

[Playwright BrowserContext API](https://playwright.dev/docs/api/class-browsercontext)（確認日 2026-11-24）。対象バージョンの接続・イベント取得を実機で検証する。

## 関連設計書

- [06　自然言語テストスクリプト仕様書](06_自然言語テストスクリプト仕様書.md)
- [08　Legacy UI Inspector 詳細設計書](08_Legacy_UI_Inspector_詳細設計書.md)
- [10　UI Test Studio 画面設計書](10_UI_Test_Studio_画面設計書.md)
- [12　MCP インターフェース仕様書](12_MCP_インターフェース仕様書.md)

## 残課題・確定条件

実システムの代表画面、設計書、データ権限、対象 Copilot harness、既存 MCP 契約及び成果物テンプレートを確認して差分改訂する。未確認仕様・実装・試験結果を確定済みとして扱わない。
