# 07　Test DSL データ構造設計書

> 文書ID：PGUT-D07　｜　版：1.0 設計案　｜　作成日：2026-11-24  
> 基準資料：PG/UT Agent UI Test Design v0.3（第8, 11, 19章）  
> 状態：詳細設計案・未実装／実システム未検証。業務名、ID、画面、数値、API は明示のない限り提案例。

[設計書一覧](README.md)

> 適用基準は [統合詳細設計書 v0.5.1](../PG_UT_Agent_Integrated_Detailed_Design_JA_v0.5.1.md)。大規模変更の開発・テストバッチは §12、画面操作と元の Copilot 会話への返却は §9～§10、共通契約・受入は §13 を参照する。

## 1. モデルと責務

DSL は自然言語を決定的な操作に変換した機械実行用データである。任意 JavaScript、任意 SQL、任意コマンドを許可しない。共通 Schema と参照整合性検査を併用する。下記は論理契約であり、実行ライブラリの完成品ではない。

**図 07-01　データモデル（設計図）**

```mermaid
flowchart TD
  n0["TestTask"]
  n1["TestPlan"]
  n2["TestCase"]
  n3["TestStep"]
  n4["DataRequirement"]
  n5["TargetRef"]
  n6["Assertion"]
  n7["ScreenState"]
  n8["Binding"]
  n9["Frame・Table・RowKey"]
  n10["VariableRef"]
  n11["Revision・Approval"]
  n12["Run"]
  n13["StepResult"]
  n14["Evidence"]
  n0 --> n1
  n1 --> n2
  n2 --> n3
  n2 --> n4
  n3 --> n5
  n3 --> n6
  n3 --> n7
  n5 --> n8
  n8 --> n9
  n3 --> n10
  n0 --> n11
  n11 --> n12
  n12 --> n13
  n13 --> n14
```

## 2. オブジェクト定義

|モデル|必須属性|補足|
|---|---|---|
|Task|task_id, project_id, business_id, snapshot_id, code_revision, status|環境IDも実行時固定|
|Plan|plan_id, scope, case_ids, spec_refs, gaps|既知仕様範囲|
|Case|case_id, purpose, spec_refs, prerequisites, steps, data_requirement_refs|論理仕様と実行状態別管理|
|Step|step_id, nl, action, pre_state, post_state, side_effect, evidence_policy|依存ID、タイムアウト、対象、入力等は動作別|
|Binding|binding_id, screen_id, frame_ref, form_ref, table_ref, row_predicates, column_path, locator_candidates, evidence_refs|対象の意味と実行位置を分離|
|ScreenState|state_id, signature, required_features, forbidden_features|URLのみ不可|
|Variable|name, type, source, secret, scope|実値は実行時のみ|
|Assertion|assertion_id, operator, expected, spec_ref, target_ref|不明な期待値は実行不可|
|Revision|revision, parent_revision, nl_hash, dsl_hash, binding_hash, data_policy_hash|snapshot・codeと併せて承認対象|
|Approval|approval_id, revision, content_hash, reviewer, approved_at|認証済ユーザのみ承認|
|Run|run_id, revision, environment_id, lease_ids, status, started_at|定義不変|
|StepResult|step_id, attempt, journal_state, outcome, observed, evidence_refs|再試行履歴保持|

## 3. 動作別仕様

|action|入力|事前・事後条件|
|---|---|---|
|navigate_menu|menu_ref|ログイン済、遷移先確認|
|fill / select / check|target_ref, value 又は value_ref|一意、可視、操作可能。選択値/真偽型検査|
|clear / click|target_ref|操作可能、副作用判定|
|select_row|table_ref, row_predicates|業務キーで一意、対象セル確認|
|assert_value / assert_message / assert_state|assertion|期待仕様出典、実値比較|
|capture|target_ref, variable_name|型・機密性・定義済変数|
|wait|condition, timeout_ms|条件成立又はTIMEOUT|
|screenshot|evidence_label|マスク方針適用|
|assert_db|approved_query_ref, parameters, expected, spec_ref|読み取り権限、確認済み表・項目|

## 4. JSON 例（TC04 の一部）

```json
{
  "schema_version": "1.0-draft",
  "task_id": "TASK-001",
  "project_id": "P-A",
  "snapshot_id": "SNAP-01",
  "code_revision": "CODE-01",
  "revision": 2,
  "case_id": "TC04",
  "steps": [
    {
      "step_id": "S05",
      "nl": "数量に999を入力する。",
      "action": "fill",
      "pre_state": "EDIT",
      "post_state": "EDIT",
      "target_ref": "B-QTY",
      "value": "999",
      "side_effect": "UNKNOWN",
      "evidence_policy": "ON_FAILURE",
      "timeout_ms": 5000
    }
  ]
}
```
例では入力による副作用が未確認のため UNKNOWN としており、そのまま正式実行できない。プロジェクトの許可済操作分類と実画面検証により確定する。値は JSON の文字列・数値・真偽を区別する。比較時の数値化、空白、日付フォーマットは仕様に明記された正規化だけを使用する。

## 5. バリデーションと改訂

Schema は必須、型、enum、最大長、追加属性を検査する。セマンティック検査は参照先の存在、同一プロジェクト・Snapshot、循環依存、ステップID重複、変数の定義前参照、画面状態の連続性、Locator一意性、仕様出典、許可済副作用を確認する。いずれか不足なら READY を拒否する。
承認対象は canonical JSON に基づくハッシュ（SHA-256候補）とし、正規化方式は実装時固定する。自由文、DSL、binding、データ方針、Snapshot、code_revision の変更は新 revision を作成。比較更新によって競合を拒否する。実行中の定義は immutable とし、別草稿で変更する。

## 6. 例外コードと状態

INVALID_INPUT、VERSION_MISMATCH、REVISION_CONFLICT、APPROVAL_REQUIRED、UNRESOLVED_VARIABLE、AMBIGUOUS_TARGET、KNOWLEDGE_GAP、DATA_UNSAFE。構造的に正しい JSON でも仕様・権限が正しいとは限らない。正式実行の受理判定は Tool Server と Runner が行う。

**参考図 16　自然言語とDSL**

```mermaid
flowchart TD
 N0["URL・タイトル・Form・特征要素・状態"]
 N1["画面状態候補"]
 N2["前提条件照合"]
 N3["一意なら操作許可"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
```

**参考図 22　画面状態識別**

```mermaid
flowchart TD
 N0["業務レベル計画"]
 N1["画面単位の調査"]
 N2["構造化結果"]
 N3["外部実行状態・変数・証跡"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
```

**参考図 23　コンテキスト分割**

```mermaid
flowchart TD
 N0["承認済Rev.01"]
 N1["自然言語編集"]
 N2["旧承認失効"]
 N3["影響分析・DSL再生成"]
 N4["Rev.02承認"]
 N5["実行許可"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
 N3 --> N4
 N4 --> N5
```

**参考図 34　自然言語の変更と承認**

```mermaid
flowchart TD
 A[実行停止・証跡保存] --> B{副作用と前提状態を確認}
 B -->|再開可能| C[現在ステップから再開]
 B -->|復旧可能| D[データ復旧・チェックポイント再実行]
 B -->|不明または不可逆| E[隔離・人工判断]
```

![参考図 35　実行状態と復旧](../figures/figure-51bf0030dcf36b8f.png)

## 関連設計書

- [06　自然言語テストスクリプト仕様書](06_自然言語テストスクリプト仕様書.md)
- [08　Legacy UI Inspector 詳細設計書](08_Legacy_UI_Inspector_詳細設計書.md)
- [11　Test Runner 詳細設計書](11_Test_Runner_詳細設計書.md)
- [12　MCP インターフェース仕様書](12_MCP_インターフェース仕様書.md)

## 残課題・確定条件

実システムの代表画面、設計書、データ権限、対象 Copilot harness、既存 MCP 契約及び成果物テンプレートを確認して差分改訂する。未確認仕様・実装・試験結果を確定済みとして扱わない。
