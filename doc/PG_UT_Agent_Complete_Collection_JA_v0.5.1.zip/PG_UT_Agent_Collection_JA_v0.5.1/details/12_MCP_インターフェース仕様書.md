# 12　MCP インターフェース仕様書

> 文書ID：PGUT-D12　｜　版：1.0 設計案　｜　作成日：2026-11-24  
> 基準資料：PG/UT Agent UI Test Design v0.3（第13, 21章）  
> 状態：詳細設計案・未実装／実システム未検証。業務名、ID、画面、数値、API は明示のない限り提案例。

[設計書一覧](README.md)

> 適用基準は [統合詳細設計書 v0.5.1](../PG_UT_Agent_Integrated_Detailed_Design_JA_v0.5.1.md)。大規模変更の開発・テストバッチは §12、画面操作と元の Copilot 会話への返却は §9～§10、共通契約・受入は §13 を参照する。

## 1. 共通契約

以下は開発対象のアプリ層 MCP tool 名と論理 Schema であり、Playwright や Copilot に既に存在する標準ツール名ではない。実際の MCP SDK、transport、tool namespace、認証方式は PoC で固定する。MCP と Studio HTTP は共通のサービス層・検証処理を呼ぶ。
```json
{
  "task_id": "TASK-001",
  "project_id": "P-A",
  "snapshot_id": "SNAP-01",
  "revision": 2,
  "request_id": "REQ-001",
  "payload": {}
}
```
作成前の task_id、知識非参照操作の snapshot_id は不要。変更・実行操作は revision と request_id 必須。応答は status（OK/PARTIAL/BLOCKED/ERROR）、data、evidence_refs、errors、next_action を返す。errors は code、message、retryable、missing_inputs を持つ。認証済ユーザ、接続権限はサーバが解決し、入力の自己申告を信頼しない。

## 2. 知識・データ系

|tool|入力 payload|応答 data|制約|
|---|---|---|---|
|get_screen_test_knowledge|screen_id, filters, cursor|items, checks, events, gaps, source_refs, next_cursor|固定Snapshot|
|get_screen_checks|screen_id, event/item filters, cursor|known_checks, total_known, scope, gaps|0件と確認済なしを区別|
|get_item_checks / get_event_checks|item_id / event_id|checks, applicability, gaps|同一画面版|
|get_check_detail / get_check_dependencies|check_id|rule, predecessors, data_refs, source_refs|出典必須|
|get_check_coverage / get_related_checks|screen_id/check_id|investigation_units / related_checks|調査率とテスト率を区別|
|get_check_diff|from_snapshot, to_snapshot, check_ids|added, changed, deleted, affected_refs|版存在確認|
|get_db_metadata|environment_id, allowed_schema, filter|tables, columns, constraints, comments|読み取り限定|
|query_candidates|source_ref, predicates, limit, timeout_ms|masked_candidates, evidence|上限強制、任意書込不可|
|validate_test_data|candidate_id, predicate_refs|verified, unknown, evidence|暗黙書込不可|
|reserve_test_data / release_test_data|candidate_id, policy / lease_id|lease, expiry, status|原子更新、復旧確認|

## 3. タスク・編集系

|tool|入力 payload|応答 data|制約|
|---|---|---|---|
|create_test_task|business_id, scope, input_refs|task_id, revision|request_id重複防止|
|save_test_plan|base_revision, plan|revision, validation|比較更新|
|open_test_editor|task_id|loopback_url|認証済、短期セッション|
|get_review_status|revision|approval, hashes, status|読み取り|
|get_script_diff|from_revision, to_revision|changed_steps, changed_expectations|版の存在|
|update_test_definition|base_revision, nl, dsl, binding_refs|draft_revision, validation|旧承認不適用|
承認操作は認証済人間の Studio 操作に限定し、Agent ツールから代理承認しない。承認 hash が現在の revision と一致することをサーバで強制する。

## 4. ブラウザ・実行系

|tool|入力 payload|応答 data|制約|
|---|---|---|---|
|inspect_screen|get session_id, frame_ref, scope|screen_model, generation|限量・マスク|
|get_table_structure / get_table_rows|table_ref, filter, limit|grid / row samples|親子Tableを分離|
|resolve_locator / validate_locator|target_ref, state, row_predicates / binding_ref|candidates, match_count, evidence|曖昧操作不可|
|start_recording / stop_recording|session_id, mode / recording_id|recording_id / draft_refs|操作権排他|
|get_recorded_events|recording_id, cursor|events, next_cursor|機密値除去|
|execute_step|revision, step_id, lease_ids, mode|run_id, step_result|debug又は実行中の制御|
|execute_test|revision, environment_id, lease_ids, idempotency_key|run_id, status|承認・安全ゲート|
|get_test_result|run_id|status, step_results, evidence_refs|権限と版|
|export_evidence|run_id, format|report_refs, manifest_ref|マスク済|
長時間実行は run_id を早期返却し、状態取得で追跡する。人手編集待ちで MCP を無期限にブロックしない。

**図 12-01　共通検証パイプライン（設計図）**

```mermaid
flowchart TD
  n0["MCP・HTTP要求"]
  n1["認証・権限"]
  n2["Schema・版検証"]
  n3["排他・冪等性"]
  n4["許可済サービス"]
  n5["監査・結果"]
  n6["構造化エラー"]
  n0 --> n1
  n1 --> n2
  n2 --> n3
  n3 --> n4
  n4 --> n5
  n2 --> n6
  n3 --> n6
```

## 5. エラー・再試行

|code|意味|再試行条件|
|---|---|---|
|INVALID_INPUT / VERSION_MISMATCH|形式又は版不整合|入力修正|
|REVISION_CONFLICT|比較元が古い|最新差分取得|
|APPROVAL_REQUIRED|未承認・ハッシュ不一致|人の再承認|
|KNOWLEDGE_GAP|必要根拠なし|追加調査|
|AMBIGUOUS_TARGET / STATE_MISMATCH|対象・状態不一致|調査と再検証|
|DATA_NOT_FOUND / DATA_UNSAFE|候補なし・安全性不足|別候補又は許可条件確定|
|SESSION_LOST / SESSION_BUSY|会話・操作権消失/競合|再構築又は解放|
|SIDE_EFFECT_UNKNOWN|更新結果不明|自動再試行不可|
|BUDGET_EXCEEDED / FORBIDDEN|制限又は権限|人の判断、許可範囲変更|
|TOOL_UNAVAILABLE / TIMEOUT|ツール・待機障害|副作用なし確認後のみ|
書込系の同一 request_id は結果を再利用し、異なる payload の再使用は拒否。外部DBの exactly-once は保証しない。SQL 文の文字列判定だけに依存せずDBの読み取り権限、許可済クエリ、時間・件数制限を併用する。

## 関連設計書

- [04　テストデータ Agent 詳細設計書](04_テストデータ_Agent_詳細設計書.md)
- [05　画面単位テスト知識モデル設計書](05_画面単位テスト知識モデル設計書.md)
- [07　Test DSL データ構造設計書](07_Test_DSL_データ構造設計書.md)
- [08　Legacy UI Inspector 詳細設計書](08_Legacy_UI_Inspector_詳細設計書.md)
- [09　UI Recorder 詳細設計書](09_UI_Recorder_詳細設計書.md)
- [10　UI Test Studio 画面設計書](10_UI_Test_Studio_画面設計書.md)
- [11　Test Runner 詳細設計書](11_Test_Runner_詳細設計書.md)

## 残課題・確定条件

実システムの代表画面、設計書、データ権限、対象 Copilot harness、既存 MCP 契約及び成果物テンプレートを確認して差分改訂する。未確認仕様・実装・試験結果を確定済みとして扱わない。
