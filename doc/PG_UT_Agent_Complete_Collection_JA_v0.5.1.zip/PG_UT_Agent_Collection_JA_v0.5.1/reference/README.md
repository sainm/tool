# 設計履歴・根拠

[配布物の入口](../README.md)

- [PG Agent 詳細設計](PG_Agent_詳細設計書.md) — PG の検討履歴。今回の実装では統合設計の入出力・TDD・バッチ接続を使用する。
- [Subagent・Skill・テスト観点設計 v0.1](PG_UT_Agent_Subagent_Skill_TestPerspective_Design_v0.1.md) — 役割、テスト観点と品質方針の議論をまとめた参照資料。原文を収録。
- [UI テスト全体設計 v0.3](PG_UT_Agent_UI_Test_Design_v0.3.md) — データ準備方式 L1～L5 の原定義は §6.3。原文と図版を収録。
