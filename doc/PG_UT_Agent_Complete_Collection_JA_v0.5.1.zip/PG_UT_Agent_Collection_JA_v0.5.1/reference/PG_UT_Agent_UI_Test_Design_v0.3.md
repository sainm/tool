# PG/UT Agent — UI 测试与测试数据准备整体设计

> 設計履歴・根拠の参照用。現在の実装範囲・承認・実行方式は [統合詳細設計書](../PG_UT_Agent_Integrated_Detailed_Design_JA_v0.5.1.md) に従う。


> 版本：v0.3（详细设计强化版）  
> 日期：2026-11-24  
> 范围：本次对话中关于 UI 测试、Test Plan Agent、Test Data Agent、运行时画面解析、自然语言录制与编辑、知识库 Check 模型的全部主要设计讨论。  
> 状态：设计提案，尚未在实际系统完成 PoC。文中业务、表、画面、接口及数值均为示例或拟定定义，非既存系统实测结果。

## 目录

1. 背景与约束
2. 整体架构与 PG/UT 流程
3. UI 测试范围与测试计划
4. 知识库：画面单位测试知识模型
5. Check 规格结构化设计
6. Test Data Agent 与共通 JDBC 限制
7. Legacy UI Inspector 与复杂 Table
8. 自然语言测试脚本与 Test DSL
9. 人工录制与验证录制
10. 本地可视化工作台及 Copilot 交接
11. Test Runner、状态与异常处理
12. 资产、版本、覆盖率与成果物
13. MCP 接口与 Agent Skill
14. 完整案例推演
15. 实现阶段、PoC 与未决事项
16. Agent 编排与单入口配置
17. 知识完整性与增量治理
18. 数据调查决策与生命周期
19. DSL、审批及恢复协议
20. 运行时解析与录制算法
21. MCP 契约与安全控制
22. PoC 验收与 Review 追踪

---

## 1. 背景与约束

### 1.1 目标

构建面向多个既存 Java Web 项目的 PG/UT Agent，利用知识库、GitHub Copilot、MCP 与 Playwright，实现从设计差分到程序修改、UT、UI 测试及成果物生成的流程。UI 测试不是单纯的浏览器点击自动化，其核心包括测试规格理解、数据准备、画面操作、预期结果判定、人工修正和回归复用。

### 1.2 用户已明确的条件

| 项目 | 条件 |
|---|---|
| Agent 环境 | VS Code 中的 GitHub Copilot Custom Agent；不自研独立 Agent |
| 任务分派 | 通过 Custom Agent / Task / Subagent 进行职责分离；具体版本的调用能力须验证 |
| 知识取得 | 优先通过知识库 MCP 获取设计书、代码及 Graph 关系，必要时补充原始代码调查 |
| 系统 | 既存 Java Web、Struts 1、早期 JSP 转换而来，可以在 Chrome 运行 |
| HTML 特征 | name 属性使用较多，缺少 label，存在 Table 布局或明细 |
| 数据访问 | 共通 JDBC，通过反射或动态规则拼接 SQL，难以从业务代码直接找到 DB 访问 |
| 设计书 | 不完整；不能假定存在完整的 DB 更新或 Check 规格 |
| DB | 存在既存数据，但不能保证满足某个测试场景 |
| 改造限制 | 不宜修改既存系统或加入 JDBC/SQL Runtime Inspector；本方案不依赖该能力 |
| 测试范围 | 初期从 Menu 进入单一业务，可包含多个画面；不要求跨业务完整 UI 链路 |
| 测试资产 | 人员可视化修改自然语言脚本，不以生成 Playwright 源代码为必要条件 |
| 知识治理 | 调查结果与正式知识分离，主动提交并审核后才允许更新 RAG、Graph、正式 Snapshot |

### 1.3 设计原则

- 正式设计规格决定预期结果；代码与实际行为是实现证据，不能自动替代规格。
- 知识库优先，按任务取得最小必要知识；缺失时按需调查。
- AI 负责理解、计划、语义映射、判断；固定工具负责结构解析、验证、权限及确定性执行。
- 不为了测试全面改造 JSP、增加 label 或 test ID，不假设所有项目的表结构相同。
- 不要求先掌握全部 DB 依赖才能进行输入 Check 测试；按场景决定调查深度。
- 不自动修改期望值以使测试通过，不掩盖真实 Bug。
- 未满足条件时明确标记阻塞、未确认或不可测试，不虚构结果。

## 2. 整体架构与 PG/UT 流程

### 2.1 PG/UT 全流程

**图 01 · PG/UT 主流程与 UI 并行设计**

```mermaid
flowchart TD
 A["设计差分 / 修改内容"]
 B["人工确认① → 影响分析 → 人工确认②"]
 P["PG / TDD / UT / Coverage"]
 T["Test Plan：逻辑计划"]
 D["环境与数据准备 / 画面绑定"]
 M["自然语言编辑 / DSL 审批"]
 R["Runner 执行"]
 F["失败分类 / 修订"]
 O["结果 / Evidence"]
 K["主动提交 / 审核 / 正式知识"]
 A --> B
 B --> P
 B --> T
 P --> D
 T --> D
 D --> M
 M --> R
 R -->|失败| F
 F -->|修订后| M
 R -->|完成| O
 O -->|可复用候选| K
```

测试计划可以在 PG 修改前生成，避免根据修改后的代码倒推预期结果。运行时的元素绑定与数据验证需等待可用的测试环境。人工确认既可出现在原 PG/UT 两个关口，也可在 UI 测试定义、规格变更和数据写入处设置独立关口。

### 2.2 系统组成

**图 02 · 单入口 Agent 与工具整体架构**

```mermaid
flowchart TD
 A["用户：仅选择 PG/UT Agent"]
 M["Main Agent / 统一任务与审批"]
 I["影响分析 / PG / UT / 隐藏 Subagent"]
 P["Test Plan / Test Data / 隐藏 Subagent"]
 S["UI 阶段 Skill / 临时任务"]
 T["共通 MCP / Tool Server"]
 K["知识库 / DB MCP"]
 W["本地 Web 工作台"]
 R["Inspector / Recorder / Runner"]
 C["同一受控 Chrome"]
 F["测试资产 / 运行记录"]
 A --> M
 M -->|task| I
 M -->|task| P
 M --> S
 I --> T
 P --> T
 S --> T
 T --> K
 T --> W
 T --> R
 T --> F
 R --> C
```

| 组件 | 职责 |
|---|---|
| Main Agent | 流程、任务拆分、人工确认、PG/UT 与 UI 结果汇总 |
| Test Plan Agent | 测试范围、规格查询、Check 场景、数据需求、自然语言脚本、覆盖检查 |
| Test Data Agent | 数据条件调查、候选查找、可用性验证、受控准备和恢复 |
| UI 测试阶段（Main Agent + Skill） | 操作计划、运行时画面理解、元素绑定、执行与失败分析协调；不单独定义可见 Agent |
| UI Inspector | 实际 DOM、Table、Frame、元素属性、布局及定位验证 |
| Recorder | 采集人工操作事件及上下文，不以生成源代码为目标 |
| UI Test Studio | 自然语言编辑、元素拾取、确认、数据、调试、结果 |
| Test Runner | 解释已确认的 DSL，使用 Playwright API 确定性执行 |
| 知识库 MCP | 获取版本化的设计知识、Check 列表、关系及证据 |
| DB MCP | 限定权限的元数据与查询工具；写入须独立受控 |

## 3. UI 测试范围与测试计划

### 3.1 单业务范围

**图 03 · 3.1 单业务范围**

```mermaid
flowchart TD
 A[其他业务 A] --> D[既存 DB / 前置数据]
 B[其他业务 B] --> D
 D --> C[Test Data Agent]
 C --> M[Menu]
 M --> S[查询画面]
 S --> E[编辑画面]
 E --> F[确认画面]
 F --> G[完成画面]
 G --> H[画面验证 / 必要时 DB 验证]
```

不必执行 A、B 的全部 UI，但必要时调查其数据依赖。若无法找到或安全准备前置数据，应标记阻塞，而非默认跨业务执行。

示例任务范围（拟定字段）：

```yaml
test_scope:
  entry: menu
  cross_business: false
  verify_database: true
```

`entry` 指从 Menu 正常进入业务；`cross_business` 表示不要求跨业务 UI 前置链路；`verify_database` 按测试目的设定，查询显示或纯前端 Check 不一定要求 DB 验证。以上并非 Playwright 标准配置。

### 3.2 测试计划的输入与输出

| 输入 | 输出 |
|---|---|
| 项目、业务、画面及知识库 Snapshot | 测试范围和规格追踪矩阵 |
| 设计差分及已确认的影响分析 | 正常系、异常系、边界值、回归场景 |
| 画面项目、Check、事件及迁移 | 逻辑测试场景、预期结果及来源 |
| 数据成立条件、权限及环境 | 数据准备请求、前置条件 |
| 已验证的画面操作知识 | 自然语言步骤与绑定候选 |

逻辑测试场景定义“测什么、为什么、期望什么”；物理测试定义说明“使用什么数据、怎样到达画面、操作哪个元素”。两者分离，不能因暂时无法定位元素而丢失逻辑测试场景。

### 3.3 知识充足性检查

**图 04 · 3.3 知识充足性检查**

```mermaid
flowchart TD
 A[识别测试任务必要知识] --> B[知识库结构化查询 / RAG / Graph]
 B --> C{足以支持当前步骤?}
 C -->|是| D[生成测试定义]
 C -->|否| E[按缺口启动调查]
 E --> F[设计书 / 代码 / 浏览器 / DB / 人工]
 F --> G[保存任务调查证据]
 G --> H{缺口解决?}
 H -->|是| D
 H -->|否且可继续| E
 H -->|达到预算或无法确认| I[记录阻塞或待确认]
 G --> J[复用候选: 主动提交及审核]
```

检查内容包括：入口、权限、画面迁移、业务项目、Check、消息、测试数据、DB 验证需求、环境和版本。返回结果应包括来源、调查范围及未知项。RAG 返回片段不等于知识完整。

## 4. 知识库：画面单位测试知识模型

### 4.1 为什么需要结构化一览

普通 RAG 不能保证一次检索返回指定画面的全部 Check；Graph 的代码调用关系也不足以直接确定测试规格。应当增加按画面、事件、版本读取的结构化知识集合，保留原文证据。

**图 05 · 画面知识包：规格、实现及缺口**

```mermaid
flowchart TD
 A["画面 ID + Snapshot"]
 B["画面项目 / Check / 事件"]
 C["迁移 / 消息 / 业务处理"]
 D["数据条件 / 权限 / 外部依赖"]
 M["正式规格 + 来源 / 未知项"]
 P["Test Plan"]
 T["Test Data"]
 A --> B
 A --> C
 A --> D
 B --> M
 C --> M
 D --> M
 M --> P
 M --> T
```

### 4.2 规格分类与优先来源

| 知识一览（日文） | 正式规格来源 | 实现调查来源 | 测试用途 |
|---|---|---|---|
| 画面一覧 | 画面一覧、画面設計書 | JSP、Struts 配置 | 测试对象 |
| メニュー一覧 | メニュー定義書 | Menu 配置、浏览器 | 入口 |
| 業務フロー | 業務フロー図、業務仕様書 | Action、Service | 场景 |
| 画面項目一覧 | 画面項目定義書、レイアウト | JSP、Form、DOM | 项目及操作 |
| チェック仕様一覧 | **チェック仕様書** | Validator、JS、Action、Service | Check 测试 |
| 画面イベント一覧 | 画面イベント定義書 | JS、Controller | 事件及联动 |
| 画面遷移一覧 | 画面遷移図 | Struts Forward、实际画面 | 迁移 |
| メッセージ一覧 | メッセージ定義書 | Properties、画面 | 期望消息 |
| 業務処理一覧 | 処理詳細設計書 | Service、Action | 业务结果 |
| DB処理一覧 | DB更新仕様書、SQL定義書 | 可取得的 JDBC 映射、DB | 数据验证 |
| テーブル一覧 | テーブル定義書、ER図 | DB Metadata | 数据调查 |
| 権限仕様一覧 | 権限定義書 | 权限代码、运行调查 | 角色及可操作性 |
| テストデータ条件一覧 | 業務仕様書、処理詳細設計書 | DB、UI、代码 | 数据准备 |
| 外部連携一覧 | 外部IF仕様書 | 接口代码、环境配置 | 外部依赖 |
| 画面操作定義 | 已审核的运行调查 | DOM、Locator、Frame | 实际执行 |

名称为建议的逻辑分类，需与各项目实际设计书体系映射。没有独立文档不代表规则不存在；缺失须明确标记。

### 4.3 抽取与增量更新建议

1. 以项目、画面 ID、事件 ID、项目 ID 为关联锚点；先识别设计书类型和章节，不依赖文件名唯一判断。
2. 将文档分解为规格记录，保留原始位置、版本、抽取方法；代码或运行时证据单独保存。
3. 对项目、Check、事件及消息建立稳定 ID；无法确定映射的记录列为候选。
4. 对照画面项目和事件，检查未覆盖、重复、冲突、未识别的规格。
5. 对设计差分重新抽取受影响的记录和依赖关系，避免全量重建；保留删除、替换和版本关系。
6. 经过主动提交、审核及正式发布后更新 Snapshot；未经审核的调查不对正式 RAG/Graph 可见。

## 5. Check 规格结构化设计

### 5.1 Check 不是单一项目属性

**图 06 · 5.1 Check 不是单一项目属性**

```mermaid
flowchart TD
 S[編集画面] --> I1[業務番号]
 S --> I2[数量]
 S --> I3[開始日 / 終了日]
 S --> I4[商品明細]
 I1 --> C1[必須 / 桁数 / DB存在]
 I2 --> C2[必須 / 数値 / 範囲]
 I3 --> C3[項目間整合性]
 I4 --> C4[明細重複 / 合計]
 S --> C5[業務状態 / 権限 / 排他]
```

必须支持单项目、多项目、明细行、整张明细表、业务及权限级检查。知道画面 ID 后取得的是该 Snapshot 中的全部**已知** Check，而非未经证明的所有实际 Check。

### 5.2 一览示例

| Check ID | 对象 | 内容 | 触发事件 | 消息 ID |
|---|---|---|---|---|
| CHK001 | 業務番号 | 必須 | 検索 | E001 |
| CHK002 | 業務番号 | DB存在 | 検索 | E002 |
| CHK003 | 数量 | 必須 | 確認 | E003 |
| CHK004 | 数量 | 数値 | 確認 | E004 |
| CHK005 | 数量 | 1～999 | 確認 | E005 |
| CHK006 | 開始日・終了日 | 開始日≦終了日 | 確認 | E006 |
| CHK007 | 商品明細 | 重複不可 | 確認 | E007 |
| CHK008 | 業務状態 | 登録可能状態 | 登録 | E008 |

### 5.3 数据结构（逻辑字段）

| 字段 | 含义 |
|---|---|
| check_id / screen_id / project_id | 稳定的规则与范围标识 |
| target_item_ids / scope | 一个或多个目标；项目、行、表、业务等 |
| physical_names | 已知 JSP property / HTML name，非必填 |
| check_type | 必須、桁数、形式、数値、範囲、整合、DB、状态等 |
| condition | 通过条件和失败条件，支持自然语言及结构化表达 |
| applicability | 角色、模式、业务状态及其他适用条件 |
| trigger_event_id | 输入、失焦、点击、提交等 |
| order / predecessors | 已确认的执行顺序及前置 Check；未知则显式记录 |
| failure_behavior | 错误消息、停留画面、阻止提交、其他行为 |
| message_id | 对应消息定义，含参数时记录其语义 |
| data_requirements | 需要的业务数据、角色、状态或并发条件 |
| enforcement | 前端限制、服务器 Check、未知等 |
| source_refs | 设计书、代码或调查证据及版本 |
| snapshot_id | 对应正式知识版本 |
| specification_status / implementation_status | 正式规格与实际实现的分别确认状态 |
| completeness / open_questions | 调查范围、缺口及冲突 |

### 5.4 Check 顺序与数据前置条件

**图 07 · 5.4 Check 顺序与数据前置条件**

```mermaid
flowchart TD
 A[数量输入] --> B{必須 Check}
 B -->|失败| X[错误 E003]
 B -->|通过| C{数値 Check}
 C -->|失败| Y[错误 E004]
 C -->|通过| D{範囲 Check}
 D -->|失败| Z[错误 E005]
 D -->|通过| E[后续业务处理]
```

上图是假设短路顺序。如果要测试范围 Check，必须使前置必須、数値检查通过，同时确保其他画面字段及业务条件不阻止目标规则触发。系统也可能一次返回多个错误；不能默认短路。前端 maxlength 可能直接拒绝或截断超长输入，应按真实 UI 规格测试，不应强行篡改 DOM 绕过后宣称 UI Check 已覆盖。

### 5.5 规格与实现的差异

| 情况 | 判定及处理 |
|---|---|
| 设计书与代码一致 | 可按已确认规格生成测试 |
| 设计书 999、代码 99 | 规格与实现冲突，保留规格预期并调查 Bug |
| 代码存在、设计书缺失 | 実装チェック候选，不能直接当正式规格 |
| 设计书存在、代码未找到 | 实现待调查，不能认定不存在 |
| 运行时未观察到 | 未覆盖该分支，不能认定规则不存在 |

![图 08 · Check 规格与实现分析](../figures/figure-e009a7b944367ae7.png)

### 5.6 Graph 关系

**图 09 · Check Graph 分层关系**

```mermaid
flowchart TD
 A["Screen / Item / Event"]
 M["Check 实例"]
 D["Check 共通定义"]
 E["正式设计书 / Message"]
 C["实现证据 / 数据条件"]
 T["测试资产 Case（外部）"]
 A -->|关联 / 触发| M
 M -->|引用| D
 M -->|规格依据| E
 M -->|证据 / 依赖| C
 T -->|覆盖| M
```

关系需带来源及版本；推测关系与正式关系分离。测试资产独立维护，可通过 ID 追踪正式 Check。

### 5.7 Check 对数据准备的影响

| Check 类型 | 典型数据条件 |
|---|---|
| 必須、桁数、数値、固定范围 | 可进入画面、操作项目、通过前置 Check |
| 日付、项目间整合 | 系统日期或关联输入组合 |
| 明细重复、合计 | 多条明细、可识别的业务行 |
| DB 存在 / 不存在 | 可验证的已存在或不存在业务键 |
| 业务状态 | 特定状态数据 |
| 权限 / 排他 | 指定用户角色、多会话或锁条件 |

## 6. Test Data Agent 与共通 JDBC 限制

### 6.1 核心职责与调整后的策略

原先提出过 SQL Runtime Inspector、JDBC Proxy、Java Agent、SQL Bind 与 Request Trace 关联，但用户已说明无法加入 Inspector。本设计**取消运行时 SQL 捕获作为必要条件**，不要求修改共通 JDBC 或既存系统。Debug 仅在环境允许时作为可选调查手段，不作为默认依赖。

**图 10 · 无 SQL Inspector 的数据调查决策**

```mermaid
flowchart TD
 A["数据请求 / 目标 Check"]
 B["已审核 Recipe / UI 查询"]
 C["DB Metadata / 有限只读查询"]
 D["框架映射 / 可选 Debug"]
 M["验证候选与权限"]
 R["分配 / 执行 / 清理"]
 F["阻塞 / 请求最小人工信息"]
 A --> B
 B -->|候选| M
 B -->|不足| C
 C -->|候选| M
 C -->|不足| D
 D -->|候选| M
 M -->|满足| R
 M -->|未满足且有预算| B
 M -->|无证据或超限| F
```

不必把上述每种调查方式都执行一遍，按成本、权限及证据选择。只要能够证明指定数据满足测试前置条件，就不必调查全部业务表。

![图 11 · 数据调查策略对比](../figures/figure-e5aa9e6da6e11029.png)

### 6.2 调查方法

| 方法 | 使用条件与结果 |
|---|---|
| UI 查询 | 从 Menu 到目标业务，以允许的查询条件查找记录；注意限制数据量和可能副作用 |
| UI 可用性验证 | 验证能否进入目标状态、操作目标项目、触发 Check；不能证明全部 DB 依赖 |
| DB Metadata | Schema、类型、主键、外键、Unique、Comment；缺失外键时仅推测关联 |
| DB 只读查询 | 依据已确认字段、业务键、状态进行有限候选查询；避免全库扫描 |
| 共通 JDBC 静态调查 | 一次性理解 Entity / 属性 / Annotation / XML / 继承 / 动态条件映射；规则需实证 |
| Debug（可选） | 允许情况下调查变量、SQL 或调用堆栈；不要求增加 Inspector |
| 人工协助 | 缺乏可信业务条件、无候选或风险不可控时请求最小信息 |

共通 JDBC 调查产物可形成「共通 JDBC フレームワーク解析仕様」，记录表名、字段名、非空条件、共通过滤条件、CRUD 规则及不支持情形。仅当规则确定且可复用时再开发静态映射工具；不承诺完整还原动态 SQL。

### 6.3 数据准备层级

| 层级 | 方式 | 初期策略 |
|---|---|---|
| L1 | 查询并选取既存数据 | 优先；验证可用性与使用权限 |
| L2 | 复制已知完整业务数据 | 有批准的复制和恢复方法才做 |
| L3 | 正式业务 API / 已有准备工具 | 若可用，优先于不安全的 DB 复制 |
| L4 | 受控 SQL 构造 | 初期不默认支持，须确认约束、审批与恢复 |
| L5 | 其他业务前置操作 | 仅必要且获允许；不等于扩大正式测试范围 |

DB 中有数据不意味着能安全使用。对于读写测试需区分只读候选、可独占的可更新记录、不可触碰的数据。不能仅凭表结构生成 INSERT/UPDATE。

### 6.4 调查深度按测试目的决定

| 测试目的 | 最小数据要求 |
|---|---|
| 初期显示 | 可进入目标画面 |
| 输入 Check | 目标项目可操作，前置 Check 可通过 |
| 迁移 | 满足目标事件与状态条件 |
| 查询结果 | 有可识别且可验证的候选记录 |
| 登记、更新 | 已知关键成立条件及隔离/恢复方案 |
| DB 更新验证 | 已确认的实际目标表、字段、期望变化 |
| 复杂跨业务 | 更深入的依赖调查或明确人工阻塞 |

### 6.5 数据请求、结果与生命周期

```yaml
data_request:
  project_id: PROJECT_A
  screen_id: SCREEN_02
  case_id: TC04
  target_state: editable
  conditions:
    - 可进入编辑画面
    - 数量项目可编辑
    - 其他前置Check可通过
  usage: update_test
  isolation_required: true
  db_verification: required_if_specified
```

返回内容包括候选业务键、变量、来源证据、适用状态、可用性验证、分配记录、数据写入授权与清理方法（如适用）。状态建议：REQUESTED → INVESTIGATING → CANDIDATE → VERIFIED → RESERVED → USED → CLEANED，另有 BLOCKED / RECOVERY_REQUIRED。

固定工具负责权限、查询限制、数据分配、写入审批执行、备份与恢复；AI 负责理解需求、候选推理和证据分析。测试环境限制、只读账号、超时、记录数限制、敏感值脱敏、写入独立审批及并发隔离必须落地，不能仅靠 Prompt。

### 6.6 可复用数据知识

「テストデータ準備定義（Test Data Recipe）」可记录业务状态、已知依赖、候选查询、可用性验证及安全准备方法。具体数据值和运行日志属于任务记录；可复用规则须主动提交、审核后进入正式知识库。

## 7. Legacy UI Inspector 与复杂 Table

### 7.1 选型：运行时为主，静态 JSP 为辅

**图 12 · 7.1 选型：运行时为主，静态 JSP 为辅**

```mermaid
flowchart TD
 A[Chrome 实际渲染 DOM] --> B[确定性 DOM / Table / 布局解析]
 C[画面項目定義書 / Check / JSP / ActionForm] --> D[Copilot 语义匹配]
 B --> D
 D --> E[Locator 候选与唯一性验证]
 E --> F{业务项目匹配明确?}
 F -->|是| G[画面操作定义]
 F -->|否| H[补充调查 / 人工拾取]
 H --> E
```

运行时可取得自定义标签渲染结果、动态明细、实际 name、可见及可编辑状态、坐标。静态 JSP 适合调查未渲染分支、property/ActionForm 关系、JS 及 Struts 配置。初期不开发完整 JSP 静态解析器。

示例关系：画面項目定義書「数量」→ JSP `html:text property="quantity"` → 实际 DOM `name="quantity"`；同时可与 ActionForm 属性关联。自定义标签、嵌套属性及动态 name 需实际验证。

### 7.2 Table 类型与解析

**图 13 · 7.2 Table 类型与解析**

```mermaid
flowchart TD
 T[Table] --> L[布局型: 项目名与输入框]
 T --> D[明细型: 表头与业务行]
 T --> X[复合型: 嵌套及合并单元格]
 L --> G[DOM + 空间位置匹配]
 D --> K[多层表头 + 业务键 + 行内定位]
 X --> R[递归解析 + rowspan / colspan 网格]
 G --> V[统一结构化模型]
 K --> V
 R --> V
```

布局型示例：

| 項目名 | DOM 项目 |
|---|---|
| 業務番号 | 输入框 name=gyomuNo |
| 処理区分 | 下拉框 name=procKbn |
| 受付日 | 输入框 name=uketsukeDate |

明细型示例（多层表头）：

<table>
<thead><tr><th rowspan="2">商品番号</th><th colspan="2">変更前</th><th colspan="2">変更後</th></tr><tr><th>数量</th><th>金額</th><th>数量</th><th>金額</th></tr></thead>
<tbody><tr><td>A001</td><td>10</td><td>1000</td><td>输入框</td><td>输入框</td></tr><tr><td>A002</td><td>20</td><td>2000</td><td>输入框</td><td>输入框</td></tr></tbody>
</table>

逻辑列路径应还原为「商品番号」「変更前.数量」「変更前.金額」「変更後.数量」「変更後.金額」。不能仅按列序号或相邻 TD 猜测含义。

![图 14 · 布局、明细与嵌套 Table 的画面实例](../figures/figure-0dcdcab831b53a1a.png)

### 7.3 固定解析工具设计

- 遍历 Frame、Form、Table 及可操作元素；对嵌套 Table 独立建模，避免父表误计子表行。
- 按 rowspan/colspan 建立占位逻辑网格；处理多层表头、无 th、隐藏行列及动态数据。
- 采集 name、id、type、value、disabled、readonly、maxlength、声明事件、Form action、select options、父级与周边文本。
- 利用 DOM API、getBoundingClientRect、getComputedStyle 取得文字与元素空间关系；坐标辅助识别，不作为常规执行定位。
- 明细按 Table、业务键、列路径、元素属性复合定位；同一 name 的多个控件不得随意取第一个。
- 仅返回画面概要、指定区域、表头及少量样本，按需查询指定明细，避免大 HTML 占满上下文。
- 保存画面状态签名及来源。当前 DOM 仅代表当前用户、数据和状态下已渲染分支。

### 7.4 定位策略

| 优先策略 | 说明 |
|---|---|
| 稳定 id 或 name | 在正确 Page / Frame / Form 范围内验证唯一性 |
| button value、文本、role | 有适当语义时使用，不默认依赖 label |
| 明细业务键 + Table + 列 + name | 优先于固定 nth 行号，验证业务键唯一 |
| 结构化 CSS / XPath | 补充定位，避免脆弱的绝对路径 |
| 截图/坐标 | 调查或最后手段，正式执行需慎重 |

**图 15 · 7.4 定位策略**

```mermaid
flowchart LR
 A[当前画面] --> B[目标 Table]
 B --> C[业务行: 商品番号 A002]
 C --> D[列: 変更後.数量]
 D --> E[name=quantity]
 E --> F[唯一 / 可见 / 可编辑验证]
 F --> G[操作]
```

注意 Struts 1 可能存在重复 name、hidden method 字段、onclick 提交、iframe/frameset、window.open、动态增删行。除已确认 Table 和 name/label 特征外，其他均需真实项目验证。正式 UI 测试通过正常用户操作，不篡改隐藏字段或直接请求后台 URL 代替 UI。

### 7.5 工具接口与调用时机

| 拟定接口 | 用途 |
|---|---|
| get_screen_overview | 画面区域、状态、Table 列表 |
| get_screen_fields | 普通输入项目及属性 |
| get_table_structure / get_table_rows | 表头、网格、指定数据样本 |
| get_element_context / find_element | 周边文本、结构及候选 |
| resolve_locator / validate_locator | 生成并验证定位 |
| inspect_frames / get_screen_changes | Frame 与操作前后变化 |

首次进入未知画面、动态状态改变、元素绑定失效时调用；已确认的正式执行不需全量解析每一步，但仍应做操作前检查。初期可实现为 Playwright 会话中的固定 DOM 解析脚本，再决定是否独立 MCP。Inspector 与 Runner 必须能够访问同一受控测试浏览器会话。

## 8. 自然语言测试脚本与 Test DSL

### 8.1 三层模型的最终选型

此前讨论过生成 Playwright 源代码的方案；根据用户最新要求，改为自然语言脚本作为人员维护的主要资产，**不强制生成 Playwright 源代码**。

**图 16 · 8.1 三层模型的最终选型**

```mermaid
flowchart TD
 A[自然语言脚本: 人员可见可编辑] <-->|语义转换及差分确认| B[结构化 Test DSL: 已确认定义]
 B --> C[Test Runner: 解释执行]
 C --> D[Playwright API]
 D --> E[Chrome]
 E --> F[执行结果 / Evidence]
 F --> A
```

正式执行使用批准的 DSL 修订版，避免每次通过 AI 重新解释自然语言。自然语言自由修改后，原 DSL 对应步骤及依赖步骤标记为过期，Copilot 重新解析并展示差分；未经确认不得执行过期定义。结构化字段的确定性修改可由编辑器直接处理，并同步生成自然语言。

### 8.2 DSL 的逻辑结构（初稿）

```yaml
scenario_id: TC04
revision: 3
snapshot_id: SNAPSHOT_EXAMPLE
code_revision: COMMIT_EXAMPLE
status: approved
spec_refs: [CHK005]
variables:
  businessNo:
    source: test_data_agent
steps:
  - id: STEP01
    text: メニューから対象業務へ遷移する。
    action: navigate_menu
    target: BUSINESS_A
    expected_state: SEARCH
  - id: STEP02
    text: 業務番号にテストデータの業務番号を入力する。
    action: fill
    screen_state: SEARCH
    target: businessNo
    value_ref: businessNo
  - id: STEP03
    text: 検索ボタンを押下する。
    action: click
    target: searchButton
    expected_state: SEARCH_RESULT
  - id: STEP04
    text: 対象業務番号に該当する明細を選択する。
    action: select_row
    target: businessDetailTable
    row_key_ref: businessNo
    expected_state: EDIT
  - id: STEP05
    text: 数量に999を入力する。
    action: fill
    screen_state: EDIT
    target: quantity
    value: '999'
  - id: STEP06
    text: 確認ボタンを押下する。
    action: click
    target: confirmButton
    expected_state: CONFIRM
  - id: STEP07
    text: 確認画面の数量が999であることを確認する。
    action: assert_value
    target: confirmQuantity
    expected: '999'
    spec_refs: [CHK005]
```

字段均为建议；元素绑定独立保存，可按画面状态和代码版本关联。动作定义至少支持输入、清空、点击、选择、勾选、明细定位、等待、断言、变量捕获、截图及经批准的 DB 验证。避免允许任意脚本或 SQL 混入自然语言执行路径。

### 8.3 自然语言修改示例

| 项目 | 原脚本 | 修改后 |
|---|---|---|
| 自然语言 | 数量に999を入力する | 数量に1000を入力する |
| 目的 | 新上限正常系 | 超过上限异常系 |
| 预期 | 通过并迁移 | 根据 Check 规格拒绝或显示错误 |
| 后续 | 确认、登记 | 根据规格删除或调整后续步骤 |
| DB | 如需验证正常更新 | 如需验证不发生非预期更新 |

自由文本改动不能只同步输入值，需要检查关联 Check、画面状态、数据要求、后续步骤及预期结果；预期变化必须确认。

## 9. 人工录制与验证录制

### 9.1 录制选型演进

Playwright Codegen 或 VS Code 扩展可以用来验证人工操作录制，但通常输出源代码，不符合最终自然语言资产方向。此前讨论过 Playwright MCP 官方录制接口及可选能力，具体工具名称、版本、返回内容须根据实际安装版本验证，不能作为本设计的必需接口。

最终建议采用轻量事件 Recorder，基于 Playwright 管理的 Chrome 会话，直接采集结构化事件和操作时的 DOM 上下文。使用浏览器事件监听、Playwright 的 `addInitScript` / `exposeBinding` 等能力是可选实现途径；需验证 Frame、Popup、导航与动态 DOM 的覆盖情况。无需自研完整浏览器自动化框架。

**图 17 · 9.1 录制选型演进**

```mermaid
flowchart TD
 A[人工操作 Chrome] --> B[Recorder: 事件 + 操作前后上下文]
 B --> C[UI Inspector: Table / name / 项目候选]
 C --> D{可确定语义?}
 D -->|是| E[固定日文自然语言模板]
 D -->|否| F[Copilot + 知识库 / 人工确认]
 F --> E
 E --> G[自然语言步骤 + DSL 候选]
 G --> H[编辑及审核]
 H --> I[Test Runner]
```

### 9.2 操作事件及自然语言模板

| 操作 | 日文模板 |
|---|---|
| 点击按钮 | XXXボタンを押下する。 |
| 输入 | XXXに「YYY」を入力する。 |
| 清空 | XXXの入力内容をクリアする。 |
| 下拉选择 | XXXから「YYY」を選択する。 |
| 勾选 | XXXにチェックを入れる。 |
| 明细行 | XXXに該当する明細を選択する。 |
| 上传 | XXXに対象ファイルを設定する。 |
| 链接 | XXXリンクを押下する。 |

事件应记录画面、Frame、目标元素、Table 行与列候选、操作类型和值、导航关联；合并连续输入、消除重复事件，敏感输入（密码、令牌、个人数据）过滤或变量化。物理属性不能直接等同业务语义。

示例：人工修改商品 S002 的数量，记录「明細編集画面 / 商品明細 / 商品番号=S002 / 数量 / name=quantity / 输入 999」，生成「商品番号『S002』の明細の数量に『999』を入力する。」行键无法确认时必须待人工修正。

![图 18 · 操作录制与验证录制](../figures/figure-9fc199d3de344407.png)

### 9.3 录制与验证模式

| 模式 | 行为 |
|---|---|
| 操作录制（記録モード） | 记录点击、输入、选择和迁移 |
| 验证录制（検証モード） | 人工选取目标元素，定义期望值、消息、存在性或状态 |
| AI 自主生成 | 根据规格和已知操作定义生成 |
| AI + 人工混合 | 遇到未知画面时仅演示局部操作，随后继续 |

当前实际画面的值只是观察结果，不能自动作为正确预期。验证条件应来自规格或明确的人工确认。

## 10. 本地可视化工作台及 Copilot 交接

### 10.1 选型比较

| 比较 | VS Code Webview 扩展 | 本地 Web | MCP Apps |
|---|---|---|---|
| 人工编辑 | 适合 | 适合 | 适合轻量交互 |
| 多画面与复杂调试 | 可实现 | 优先 | 需验证宿主能力 |
| Chrome 元素拾取 | 需桥接 | 需桥接，独立窗口方便 | 需桥接 |
| 自研 VS Code 扩展 | 需要 | 不需要 | 不需要自研扩展 |
| 长任务状态 | 后端管理 | 后端管理 | 后端管理 |
| 推荐 | 暂不考虑 | **首选** | 后续可选入口 |

MCP Apps 与 Custom Agent 的具体交互能力取决于实际 VS Code/Copilot 版本及企业配置，需 PoC。最终选型建议为本地 Web + MCP Server + Playwright；不另外实现 AI 聊天或模型调用。使用同一后端，未来可增加 MCP Apps 用于简单确认、修改参数和结果概要。

### 10.2 工作台画面示意

**图 19 · 10.2 工作台画面示意**

```mermaid
flowchart TB
 subgraph Studio[UI Test Studio - 本地 Web]
  direction LR
  L[左: Case 与步骤列表]
  M[中: 自然语言 / 数据 / 预期结果]
  R[右: 浏览器预览 / 元素关联 / Table]
  L --- M --- R
 end
 Studio --> B[底部: 保存 / 单步 / 继续 / 审核 / 停止]
 R <--> CH[独立测试 Chrome]
```

示意布局（实际 Chrome 通过受控会话联动，不假定业务站点允许 iframe 嵌入）：

| テスト手順 | 自然言語スクリプト | 実行画面 / 項目関連 |
|---|---|---|
| 01 メニュー | 选中 STEP05 | 編集画面 |
| 02 検索条件 | 数量に999を入力する。 | 業務番号：A001 |
| 03 検索 | 期待結果：999が表示されること | 区分：変更 |
| 04 明細選択 | 数据值：999 | 数量：[999] ← 高亮 |
| **05 数量入力** | 关联 Check：CHK005 | name=quantity |
| 06 確認 | 差分：无 / 待确认 | 元素验证：唯一 / 可编辑 |
| 07 結果確認 | 保存・承認 | 単步実行・要素選択 |

工作台功能：测试概要、测试设计、画面调查、操作录制、测试数据、执行调试、测试结果、测试资产。第一阶段不必将八个模块做成完整独立页面，可先实现统一编辑/执行页面。

![图 20 · 自然语言编辑与 Chrome 元素关联工作台](../figures/figure-8fd93451a9c45e77.png)

### 10.3 人工交接流程

**图 21 · 10.3 人工交接流程**

```mermaid
sequenceDiagram
 participant C as Copilot Custom Agent
 participant M as MCP / Tool Server
 participant W as 本地 Web 编辑器
 participant U as 人员
 C->>M: 创建任务并保存计划
 M-->>C: task_id / 本地 URL
 C-->>U: 请求人工编辑或确认
 U->>W: 修改自然语言 / 元素关联
 W->>M: 保存新 revision 与差分
 U->>C: 继续任务
 C->>M: 读取状态与差分
 C->>M: 生成修订 DSL / 待确认项
 U->>W: 确认修订版
 C->>M: 请求执行已批准版本
 M-->>C: 结果 / Evidence
```

不能假设 Web 按钮会自动唤醒已结束的 Copilot 会话。初期用户回 VS Code 输入「继续」，Agent 根据 task_id 恢复；避免 MCP 调用无限阻塞。保存任务状态、版本与差分，支持中断重启及重复请求保护。MCP Apps 后续可验证是否能改善交接体验。

### 10.4 技术栈建议

| 模块 | 方案 |
|---|---|
| Agent | GitHub Copilot Custom Agent / Skills |
| Tool Server | TypeScript + MCP SDK；本地 HTTP 服务可用 Fastify |
| 编辑器 | React + TypeScript |
| 状态推送 | WebSocket 或 SSE |
| 浏览器 | Playwright；统一受控浏览器会话 |
| 持久化 | 项目 Git / 文件保存测试定义；SQLite 保存运行状态 |
| 数据校验 | JSON Schema、版本及引用一致性检查 |

本地服务绑定回环地址，配置任务级授权及来源检查；测试账号及连接凭据不写入 Git。真实画面预览可优先使用独立 Chrome 窗口及高亮，或受控截图预览；不假定可无条件嵌入真实页面。

## 11. Test Runner、状态与异常处理

### 11.1 确定性执行与共通组件

Runner 解释 DSL，通过 Playwright API 执行；运行中不需要每一步调用 AI，也不需要生成 Playwright 源文件。登录、Menu 路径、查询、选择明细、日期、下拉、文件上传下载、消息验证及 DB 验证可封装为共通组件。项目特定登录和 Menu 差异通过配置或专用组件解决。

操作前检查：当前画面状态、正确 Frame/Table、业务行唯一、目标元素唯一、可见可编辑或符合动作要求、业务语义映射已确认。对登记等不可重复动作增加授权及状态检查。等待使用明确的条件，不盲目固定 sleep。

### 11.2 Screen State 与上下文

**图 22 · 11.2 Screen State 与上下文**

```mermaid
flowchart TD
 U[同一 URL: business.do] --> A[初期画面]
 U --> B[查询结果]
 U --> C[编辑状态]
 U --> D[错误状态]
 A --> S[状态签名: 标题 / Form / 特征元素]
 B --> S
 C --> S
 D --> S
 S --> V[执行前后状态验证]
```

画面识别不只依靠 URL；使用标题、Form action、特征元素、按钮、Table 表头、错误消息等。隐藏状态只能作为调查证据，不主动篡改。

**图 23 · 11.2 Screen State 与上下文**

```mermaid
flowchart TD
 A[L1 业务级上下文: 目标 / 场景 / 路径 / 数据依赖] --> B[L2 当前画面: 局部设计与操作]
 A --> C[L2 其他画面: 按需加载]
 B --> D[L3 外部状态: task / page / frame / step / variables]
 C --> D
 D --> E[脚本连续执行与证据记录]
```

变量来自数据准备、画面捕获、DB 查询或环境配置，例如登记取得 businessNo 后供后续查询与 DB 验证使用。多画面不依赖聊天历史传递运行状态。

### 11.3 断点与恢复

| 恢复方式 | 条件 |
|---|---|
| 保持当前浏览器会话继续 | 当前状态有效 |
| 重试当前步骤 | 未发生不确定或不可重复更新 |
| 从检查点重建状态 | 有明确前置操作和数据准备方法 |
| 恢复数据后重跑 | 已更新数据且有可靠批准的恢复方法 |
| 从头执行 / 标记阻塞 | 无法可靠恢复状态 |

保存登录状态不等于恢复服务端事务或业务状态。不能在发生超时后无条件重试登记按钮；先判断是否已经提交成功。

### 11.4 失败分类

**图 24 · 失败分类与处理边界**

```mermaid
flowchart TD
 A["保留失败现场"]
 M["Main 分派临时调查"]
 B["定位 / 等待问题"]
 C["数据 / 环境问题"]
 D["脚本 / 规格问题"]
 E["业务缺陷"]
 F["验证后修订绑定"]
 G["重新准备或阻塞"]
 H["重新审核，不改期望掩盖缺陷"]
 I["回 PG / UT"]
 A --> M
 M --> B
 M --> C
 M --> D
 M --> E
 B --> F
 C --> G
 D --> H
 E --> I
```

允许受限的等待调整、已证实同一业务元素的 Locator 修复及安全候选重新查找；测试逻辑修改、预期修改必须审核；禁止擅自删除失败测试或降低断言。状态至少包括 PASS、FAIL、BLOCKED、NOT_RUN，必要时增加 INCONCLUSIVE / RECOVERY_REQUIRED。正式结果引用测试定义修订版。

## 12. 资产、版本、覆盖率与成果物

### 12.1 资产分离

| 资产 | 保存位置 |
|---|---|
| 正式设计知识与 Check | 版本化知识库 |
| 已审核画面操作知识 / Recipe | 正式知识库，可独立引用 |
| 自然语言脚本、DSL、元素绑定 | 项目测试资产库 / Git |
| 实际数据、截图、执行日志、变量 | 任务运行记录（脱敏、权限及保留期） |
| 未审核调查结果 | 独立调查记录库，不更新正式 Snapshot |

**图 25 · 12.1 资产分离**

```mermaid
flowchart TD
 A[任务调查 / 测试运行] --> B[调查记录库]
 B --> C[选择有复用价值的候选]
 C --> D[主动提交]
 D --> E{审核}
 E -->|批准| F[正式知识 / RAG / Graph / Snapshot]
 E -->|退回| B
 A --> G[测试资产与 Evidence]
 F --> H[后续 PG/UT 任务复用]
```

### 12.2 规格追踪与覆盖率

**图 26 · 12.2 规格追踪与覆盖率**

```mermaid
flowchart TD
 A[设计差分: CHK005 1-99 改为 1-999] --> B[TC01: 99 回归]
 A --> C[TC02: 999 正常]
 A --> D[TC03: 1000 异常]
 B --> E[自然语言 / DSL 修订]
 C --> E
 D --> E
 E --> F[执行结果 / Evidence]
```

UI Coverage 不等于代码 Coverage。分别统计已确认范围中的设计差分、Check、事件、迁移、DB 处理及业务分支。计划覆盖率（已有测试定义）、执行覆盖率（已执行）、通过率（已通过）分开管理。分母仅为已识别并确认的范围；知识缺口单独显示。

| 规格类别 | 已设计覆盖 | 已确认范围 | 示例覆盖率 |
|---|---:|---:|---:|
| 修改规格 | 12 | 12 | 100% |
| Check | 24 | 28 | 85.7% |
| 画面事件 | 15 | 18 | 83.3% |
| 画面迁移 | 8 | 10 | 80% |
| DB 更新 | 5 | 7 | 71.4% |
| 业务分支 | 9 | 15 | 60% |

数字仅为示意，不代表实测。测试覆盖不足、设计书缺失、不可执行 Case 必须单独呈现。

### 12.3 成果物

- 测试计划、测试式样书（正常系、异常系、边界值及回归范围）。
- 测试数据准备记录、前置条件及隔离/恢复记录。
- 已确认自然语言脚本及内部 DSL 版本。
- 实际与预期对照、执行状态、截图、必要日志及 DB 验证证据。
- 规格追踪矩阵、覆盖情况、未执行原因、缺陷及未决事项。

## 13. MCP 接口与 Agent Skill

### 13.1 拟定接口（非现成标准）

| 类别 | 接口 | 说明 |
|---|---|---|
| 知识库 | get_screen_checks / get_item_checks / get_event_checks | 画面、项目、事件全部已知 Check |
| 知识库 | get_check_detail / get_check_dependencies | 条件、触发、前置及证据 |
| 知识库 | get_check_coverage / get_check_diff / get_related_checks | 完整性、差分、关联 |
| 知识库 | get_screen_test_knowledge | 画面测试知识包及缺口 |
| 数据 | get_db_metadata / query_candidates | 元数据、限定只读调查 |
| 数据 | reserve_test_data / validate_test_data / release_test_data | 数据分配、验证、释放；写入另行授权 |
| 任务 | create_test_task / save_test_plan / open_test_editor | 创建任务及编辑入口 |
| 任务 | get_review_status / get_script_diff / update_test_definition | 确认交接及修订 |
| 画面 | inspect_screen / get_table_structure / resolve_locator / validate_locator | 运行时解析、定位 |
| 录制 | start_recording / stop_recording / get_recorded_events | 采集事件及自然语言候选 |
| 执行 | execute_step / execute_test / get_test_result / export_evidence | 执行控制与成果物 |

所有接口应明确项目、任务、版本、输入 schema、权限、返回状态、证据及失败码，读写分离。此处未锁定具体实现协议。

### 13.2 Skill 分工与目录

```text
.github/
  agents/
    pg-ut.agent.md
    test-plan.agent.md
    test-data.agent.md
    impact-analysis.agent.md
    pg.agent.md
    ut.agent.md
  skills/
    test-plan/SKILL.md
    test-design/SKILL.md
    test-script/SKILL.md
    test-review/SKILL.md
    data-investigation/SKILL.md
    data-search/SKILL.md
    data-preparation/SKILL.md
    data-validation/SKILL.md
    ui-inspection/SKILL.md
    ui-execution/SKILL.md
    failure-analysis/SKILL.md
    evidence/SKILL.md
.vscode/mcp.json
ui-tests/
  plans/
  scenarios/
  definitions/
  screen-mappings/
  test-data/
  results/
  evidence/
```

各 Skill 可带 references、schema、模板和案例，按需读取。第16章单入口配置为最终编排规则。Agent 定义负责角色与路由，Skill 负责调查策略、步骤、工具选择、质量与完成条件，不把表结构、业务 SQL、解析算法或具体业务规则硬编码进去。凭据与敏感运行记录不纳入 Git。

### 13.3 规模估算及修正

| 对象 | 原讨论估算 |
|---|---:|
| 单个 Agent 定义 | 50–100 行 |
| 普通 Skill | 100–250 行 |
| 复杂 Skill | 250–400 行 |
| Test Plan Agent 全部 Skill | 500–750 行（细分示例约 670 行） |
| Test Data Agent 全部 Skill | 450–750 行（细分示例约 670 行） |
| 两者合计 | 950–1,500 行 |
| 整体 PG/UT Skills | 约 4,000–6,000 行，原示例 4,940 行 |

在提出 JDBC Runtime Inspector 后，曾将 Test Data Skill 估算提高到 1,400–2,050 行；由于用户明确无法加入 Inspector，该估算不应直接作为最终目标。建议先明确无 Inspector 时的数据调查策略、知识缺口、人工阻塞和工具契约，再根据 PoC 修订。Skill 行数不是质量指标；以上均为估算，不包含工具代码、Schema、设计书及参考案例。

## 14. 完整案例推演

### 14.1 假设的修改

单业务从 Menu 进入查询、编辑、确认及完成画面。修改数量允许范围从 1–99 扩大为 1–999，其他规则待规格确认。

**图 27 · 14.1 假设的修改**

```mermaid
flowchart LR
 A[Menu] --> B[検索画面: 查询业务号]
 B --> C[編集画面: 修改数量]
 C --> D[確認画面: 核对数量]
 D --> E[完了画面: 登记结果]
 C -->|Check 失败| C
```

| Case | 输入值 | 预期（示例） |
|---|---:|---|
| TC01 | 1 | 最小有效值 |
| TC02 | 99 | 原上限回归 |
| TC03 | 100 | 新增有效范围 |
| TC04 | 999 | 新上限 |
| TC05 | 1000 | 依据规格拒绝输入或触发错误 |
| TC06 | 0 | 下限异常 |
| TC07 | 空白 | 查询必須 Check 规格 |
| TC08 | ABC | 查询数値 Check 及前端限制 |

![图 28 · 四画面业务操作实例](../figures/figure-c845b12f98d2dd57.png)

### 14.2 端到端执行

1. Main Agent 取得设计差分和影响画面，经人工确认交给 Test Plan Agent。
2. 查询指定画面的 Check 列表，核对数量、其他必填项、触发事件及消息定义；对未确认规则标记待调查。
3. 生成逻辑场景及数据需求，不要求先取得全部 SQL。
4. Test Data Agent 从 Menu 查询或通过已知业务键、DB Metadata 和只读查询查找候选；验证可进入编辑画面、数量可操作、其他前置条件可满足。
5. UI Inspector 运行时解析 Chrome DOM 和 Table；以 name、业务行及列路径绑定数量项目，不依赖 label。
6. Agent 生成日文自然语言步骤及 DSL 候选。人员在本地 Web 修改、拾取元素、核对预期。必要时人工录制局部操作。
7. Copilot 读取差分并确认 DSL。Runner 从 Menu 开始按确定性动作执行，逐步检查画面状态和目标唯一性。
8. TC04 输入 999，按确认按钮；验证确认画面，若测试范围要求且数据安全则登记并检查结果及已知 DB 更新。
9. TC05 使用独立或可恢复数据，按规格验证 1000 的实际 UI 行为；若不能通过正常 UI 输入，则记录前端限制及后端 Check 未由该场景覆盖，不强行通过 DOM 注入。
10. 保存预期、实际、证据及覆盖结果。失败进入分类处理；复用知识主动提交、审核，不自动写正式库。

## 15. 实现阶段、PoC 与未决事项

### 15.1 分阶段实施建议

| 阶段 | 核心范围 | 验收方向 |
|---|---|---|
| PoC | 真实 Struts 1 画面、Check 提取、既存数据查询、自然语言/DSL、同一 Chrome 会话 | 验证单一业务可从 Menu 完成可重复的 Check 测试 |
| 第一阶段 | 本地编辑器、MCP 交接、DOM/Table 解析、元素拾取、状态、变量、Runner、截图及基本数据查询 | 人员修改自然语言后能重新确认并执行，无需源代码编辑 |
| 第二阶段 | 操作/验证录制、共通组件、断点恢复、受控数据准备、失败分析、规格覆盖 | 支持复杂明细和可复用业务测试 |
| 第三阶段 | 跨版本回归、资产管理、可选 MCP Apps、审核知识复用 | 多项目可维护、可追踪、可迭代 |

由于人工录制已明确要求自然语言，PoC 可先验证一小段事件录制与转换，不必等第二阶段才能验证该方向。阶段划分为建议，并非承诺。

### 15.2 PoC 验证矩阵

| 验证对象 | 需要证明的能力 |
|---|---|
| 简单查询画面 | 无 label 时 name 和周边文本定位 |
| 复杂登记画面 | 布局 Table、rowspan/colspan、多个控件 |
| 明细编辑画面 | 重复 name、行排序后正确业务键定位 |
| 复合画面 | 嵌套 Table、多层表头、动态显示 |
| Check 规格 | 按画面获取已知规则、冲突和未确认项 |
| 共通 JDBC | 不增加 Inspector 时能否通过 UI / DB 元数据 / 框架规则取得数据候选 |
| 可视化 | 自然语言修改使旧 DSL 失效，并能经 Copilot 重新确认 |
| 录制 | 操作事件转为自然语言，区分实际观察与验证预期 |
| 执行 | 无 Playwright 源文件的 DSL Runner，可重跑、记录证据 |
| 安全 | 重复提交保护、只读 DB、数据隔离与失败阻塞 |

![图 29 · 实施可行性分析与 PoC](../figures/figure-a57bb4d670c89dcc.png)

### 15.3 主要风险与未决事项

- 画面項目定義書是否包含物理名，复杂 Table 能否准确映射业务项目；需要脱敏真实 HTML/JSP/设计书验证。
- 共通 JDBC 框架映射是否存在可稳定抽取的规则，DB Metadata 是否有足够注释、键及访问权限。
- 能否从 UI 查询找到特定业务状态的数据；没有候选时不能保证自动生成复杂关联数据。
- Check 设计书缺失程度、检查顺序、消息参数、前后端检查分布；不能声称所有规则已经完整覆盖。
- 具体 VS Code/Copilot 版本的 Subagent、Skill 加载及 MCP Apps 支持；同一浏览器会话接入方式需实测。
- 自然语言和 DSL 双向一致性、修订审批及任务恢复协议尚需详细设计。
- 真实环境的 Frame、Popup、动态明细、权限、外部依赖及数据恢复能力尚未确认。

### 15.4 最终设计结论

以 GitHub Copilot Custom Agent 为流程与语义分析中心，以知识库中的画面测试知识包和 Check 一览为正式测试规格输入，以 Test Data Agent 按需寻找可用数据，以本地 Web 工作台提供自然语言编辑、人工录制和确认，以 Legacy UI Inspector 运行时解析复杂 Table，最终由 Test DSL Runner 调用 Playwright API 执行。既存业务系统及共通 JDBC 无需为了本方案增加运行时 Inspector。

下一步应优先用真实业务验证「画面 Check 一览 → 测试计划 → 数据候选 → 画面绑定 → 自然语言人工修改 → DSL 执行」的最小闭环，然后再锁定 Skill、Schema 和 MCP 接口详细设计。

---

## 16. Agent 编排与单入口配置

### 16.1 最终选型及责任边界

**一个对用户可见的 PG/UT Main Agent，五个隐藏专用 Subagent，按需临时任务，模块化 Skills，固定 MCP 工具。** UI Test Agent 不再作为独立 Custom Agent 文件；保留 UI 测试这一逻辑阶段，由 Main 负责调度。任何历史章节的 UI Test Agent 称谓均指该逻辑阶段，不意味着新增入口。

| 角色 | 可见性 | 输入 | 唯一负责的输出 | 权限边界 |
|---|---|---|---|---|
| Main | 可见 | 修改需求、Snapshot | 任务状态、分派、审批、最终汇总 | 不绕过审批；唯一更新任务主状态 |
| Impact Analysis | 隐藏 | 设计差分、范围 | 影响清单与来源 | 只读调查 |
| PG | 隐藏 | 已确认修改及影响 | 代码变更与生成记录 | 限定代码范围 |
| UT | 隐藏 | 修改规格、代码 | TDD 结果、Coverage、失败 | 测试工作区；回归范围须明确 |
| Test Plan | 隐藏 | 画面知识包、差分 | 逻辑 Case、规格追踪、数据请求 | 不修改业务代码或 DB |
| Test Data | 隐藏 | 数据请求、环境 | 候选、证据、租约、阻塞 | 默认只读；写入由授权工具执行 |
| 临时任务 | 无固定入口 | 具体调查问题 | 结构化发现及证据 | 最小权限；不得直接审批 |

Main 直接分派，初期不依赖嵌套 Subagent。测试计划可与代码修改并行，但共用文件由 Main 串行合并；UT 与 PG 按 TDD 迭代而非固定先写全部代码再补测试。已确认规格的变更必须返回对应审批阶段。

### 16.2 VS Code 配置（示例，不是完整可运行 Agent 文件）

主 Agent：`user-invocable: true`；隐藏 Agent frontmatter：

```yaml
---
name: Test Data
description: Investigate and validate test data for approved UI cases.
user-invocable: false
disable-model-invocation: false
---
```

隐藏只控制选择列表，不是权限隔离。隐藏 Agent 仍可被内部委派；使用工具权限和后端授权做真正的隔离。Copilot harness 的任务委派使用原生 `task`；不要把 Local harness 专用 `agents` allowlist、`runSubagent` 或 handoffs 配置直接照搬。模型优先项可在支持的 Agent 文件中配置，具体模型 ID、任务级覆盖及工具名称以目标安装版本为准；不支持时由 Main 使用当前模型执行相同 Skill。避免依赖嵌套委派。

参考（2026-11-24 查阅）：[Custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents)、[Subagents](https://code.visualstudio.com/docs/agents/run/subagents)、[Agent file reference](https://code.visualstudio.com/docs/agents/reference/custom-agent-file-reference)。实际企业版本仍需验证。

### 16.3 任务契约与冲突控制

每次分派提供 task_id、parent_id、project_id、snapshot_id、code_revision、role、目标、输入资产引用、允许工具、输出路径、调查预算及完成标准。返回 status（completed/blocked/failed）、artifact_refs、evidence_refs、open_questions、proposed_changes；不传完整聊天历史。Main 检查输入版本未变化后合并，冲突时拒绝覆盖并重新调查。子任务使用独立输出文件；并行 PG 修改需显式分离文件范围或串行化。审批必须由人执行，不能由 Subagent 自行通过。

**图 30 · 单入口与按需任务分派**

```mermaid
flowchart TD
 A["VS Code Agent 选择列表 / 仅 PG/UT 为项目自定义入口"]
 M["Main：task / 状态 / 审批"]
 B["5 个隐藏专用 Subagent"]
 C["临时调查任务"]
 D["按职责加载 Skill"]
 E["最小权限 MCP"]
 F["结构化结果 / 证据 / 阻塞"]
 A --> M
 M --> B
 M --> C
 B --> D
 C --> D
 D --> E
 E --> F
 F -->|合并| M
```

## 17. 知识完整性与增量治理

### 17.1 调查单元与完成判定

以 (project, snapshot, screen, state, event, item/group) 为调查单元；独立记录项目清单、事件清单是否齐全。状态 NOT_INVESTIGATED、PARTIAL、CONFIRMED、CONFIRMED_NONE、CONFLICT；CONFIRMED 仅代表限定的已审范围内证据充分，不证明隐藏分支全部已发现。CONFIRMED_NONE 必须有针对该范围的审查证据；RAG 零结果不够。每条记录保存来源位置、调查方法、版本、审查者、遗漏分支和时间。共通 Check 定义与画面 Check 实例分离，实例独立记录覆盖、触发及参数。事件级规则不强行归属单项目。

| 项目 | 已知 Check | 调查状态 | 已设计覆盖 |
|---|---:|---|---:|
| 業務番号 | 3 | CONFIRMED | 3/3 |
| 数量 | 4 | CONFIRMED | 4/4 |
| 処理区分 | 2 | PARTIAL | 2/2 |
| 受付日 | 0 | NOT_INVESTIGATED | 未知 |
| 備考 | 0 | CONFIRMED_NONE | 不适用 |
| 明細情報 | 3 | PARTIAL | 2/3 |

示例：已知 12、已覆盖 11，但三个调查缺口不能从分母中消失。覆盖率不得解释为全系统规则完整性。正式规格、实现观察、运行结果分别记录；只有正式规格可作为默认断言依据。

**图 31 · 知识完整性与测试覆盖的双轨判定**

```mermaid
flowchart TD
 A["画面 / 项目 / 事件清单"]
 B["规格与实现调查"]
 C["未调查 / 部分 / 冲突"]
 D["已确认 / 确认无 Check"]
 M["已知正式 Check 清单"]
 P["Case 设计覆盖"]
 R["执行覆盖 / 通过率"]
 G["缺口独立报告"]
 A --> B
 B --> C
 B --> D
 D --> M
 M --> P
 P --> R
 C --> G
 G -->|限制结论| P
```

### 17.2 版本和增量

大版本为业务标签（如 3Q上期），内部 ID 稳定；先后关系显式配置，不按文字排序。每个大版本 current / preview / release 分支的具体发布规则沿用知识库主设计，本文不另行假定分支语义。测试任务固定具体 Snapshot 与代码 revision；更新规格时，以稳定 Check ID 对比新增、修改、删除、关联变化，标记受影响的测试定义 STALE，不自动覆盖历史结果。调查候选先独立保存，主动提交审核后才进入正式版本；拒绝则保留调查记录，不更新正式索引。

**图 32 · 知识版本与测试资产增量**

```mermaid
flowchart TD
 A["大版本业务标签 / 显式前后关系"]
 B["current / preview / release"]
 C["固定 Snapshot S1"]
 D["经审核新 Snapshot S2"]
 M["Check ID 差分"]
 E["关联 Case 标记 STALE"]
 F["重新设计 / 审核 / 回归"]
 G["S1 历史结果不可变"]
 A --> B
 B --> C
 B --> D
 C --> M
 D --> M
 M --> E
 E --> F
 C --> G
```

## 18. 数据调查决策与生命周期

### 18.1 搜索与停止算法

1. 从 Case 确定目标状态、目标 Check、所有已知前置条件、测试是否写入及需要的断言。未知关键条件列入待调查。
2. 按 Recipe、允许的 UI 查询、DB Metadata/有限只读查询、共通 JDBC 静态映射、可选 Debug 顺序选择适用手段；无需逐项执行。框架映射缺失时不猜 SQL，不安装 Inspector。
3. 对候选以业务键去重，记录角色、状态、验证证据、使用限制。优先验证只读且无副作用的路径；进入编辑画面也须考虑锁定等副作用。
4. 逐一验证实际可达、可操作及前置 Check；失败记录原因，不以单次成功推导全部业务依赖。已存在数据可用不代表允许更新。
5. 在可配置预算内继续（PoC 建议最多 10 个候选、3 轮策略变更；可按项目调整）；无可信新证据、权限不足、数据不可隔离、预算用尽时 BLOCKED，返回最小人工请求。预算不作为成功证明。
6. 更新类测试仅在已确认授权、隔离、预期副作用和清理方案后分配；没有可靠恢复方式则使用一次性独立测试数据或阻塞。初期不默认直接构造复杂关联数据。

### 18.2 数据请求与响应

请求包含 case_id、screen/state、check_id、predicate_refs、role、usage（READ_ONLY/WRITE/UNKNOWN）、required_count、isolation_policy、assertion_refs、snapshot_id。响应包含 candidate_id、masked_business_key、variable_ref、verified_predicates、unknown_predicates、evidence_refs、lease_id、expiry、side_effect_policy、cleanup_recipe_ref、status。未知写入行为不得当作只读。

测试记录复用原则：只读/无状态变化的 Check 可复用，但每次验证状态；更新/删除/状态迁移需独立记录或已确认的恢复；并发测试独立租约和用户会话。分配数量按会改变状态的 Case 分组计算，不按所有 Case 简单乘算。

**图 33 · 数据分配、使用、恢复与释放**

```mermaid
flowchart TD
 A["REQUESTED / INVESTIGATING"]
 B["CANDIDATE / VERIFIED"]
 M["RESERVED：独占租约"]
 C["USED：实际操作"]
 D["无副作用 / 已确认清理"]
 E["更新结果不确定"]
 F["RECOVERY_REQUIRED：禁止重试"]
 G["RELEASED / CLEANED"]
 H["BLOCKED"]
 A --> B
 A -->|无候选| H
 B -->|授权| M
 M --> C
 C --> D
 C --> E
 D --> G
 E --> F
 F -->|人工确认恢复| G
```

### 18.3 无法恢复与重复提交

数据租约仅管理本工具范围内的并发，不能保证外部系统不会修改数据。执行写操作前重新验证业务状态；超时后先通过允许的查询/画面确认是否已提交，无法判断则保留记录并进入 RECOVERY_REQUIRED。不得盲目补偿 SQL、重试登记、删除历史或强制释放仍有副作用的记录。外部通知、文件输出、批处理等须在隔离环境或批准的替代环境中执行，否则阻塞。

## 19. DSL、审批及恢复协议

### 19.1 单一执行事实与修订绑定

自然语言是用户编辑入口，批准的 DSL 是唯一执行事实。每个 revision 保存 nl_hash、dsl_hash、binding_hash、snapshot_id、code_revision、data_policy_hash、approval_id。任意相关内容变化生成新 revision，旧审批不继承；运行锁定旧批准版本，编辑只能生成新草稿，不允许改变正在执行的定义。服务端原子比对 revision，冲突返回 REVISION_CONFLICT。

| 动作 | 必填参数 | 验证 |
|---|---|---|
| navigate_menu | menu_ref, expected_state | 正常入口、角色 |
| fill/select/check/click | target_ref, value 或 value_ref（适用时） | 当前状态、唯一目标、可操作 |
| select_row | table_ref, key predicates | 业务键唯一，禁止默认首行 |
| assert_value/message/state | target/state, expected, spec_ref | 预期来源，不自动修改 |
| capture | target_ref, variable_name | 类型与脱敏 |
| wait/screenshot | condition 或 evidence_label | 超时及取证策略 |
| assert_db | approved_query_ref, parameters, expected | 只读授权、目标已确认 |

每个 step 具有稳定 ID、自然语言、动作、前后状态、依赖、失败策略、副作用等级、证据策略；未知动作或任意代码/SQL 禁止执行。变量未解析、绑定不唯一、预期未知均阻止对应正式 Case。结构化字段修改由固定模板同步自然语言；自由文本改动由 Copilot 转换为候选 DSL 并展示差分。不得直接静默更改后续登记步骤或预期。

**图 34 · 自然语言修改与审批失效**

```mermaid
flowchart TD
 A["批准 Rev.01：999 / 正常系"]
 B["人工改为 1000"]
 M["Rev.02 DRAFT / 旧审批不适用于新版本"]
 C["Copilot：检查 Check / 后续步骤 / 数据"]
 D["差分：异常系 / 删除不适用登记"]
 E["人工审核及重新绑定"]
 F["批准 Rev.02 → Runner"]
 A --> B
 B --> M
 M --> C
 C --> D
 D --> E
 E --> F
```

### 19.2 状态与交接

任务状态 DRAFT → REVIEW_REQUIRED → REVISING → REVIEW_REQUIRED → APPROVED → READY → RUNNING → COMPLETED；从 RUNNING 可 PAUSED/FAILED/BLOCKED/RECOVERY_REQUIRED。审批绑定内容哈希、用户与时间；READY 还需环境健康、数据租约有效、所有必需绑定确认。单步调试使用独立 debug run，不得记为正式通过；正式重跑从可证明的前置状态开始。Web 保存 revision 后返回 task_id，用户回 VS Code 指定任务继续；不假定自动唤醒 Copilot 或长期阻塞 MCP。

Runner 每步写入 STARTED、操作意图、副作用等级，再记录结果及 Evidence；进程崩溃后 STARTED 未结束的写操作视为不确定，不自动重试。浏览器会话有效时可继续；失效后只能重建检查点或重新准备数据。记录 PASS/FAIL/BLOCKED/NOT_RUN/INCONCLUSIVE，不以跳过判定成功。

**图 35 · 运行状态与异常恢复**

```mermaid
flowchart TD
 A["APPROVED / READY"]
 M["RUNNING / step journal"]
 B["PAUSED：会话仍有效"]
 C["FAILED：可调查"]
 D["RECOVERY_REQUIRED：写入不确定"]
 E["重新验证 / 重新审批（如需）"]
 F["COMPLETED"]
 G["BLOCKED"]
 A --> M
 M --> B
 B -->|验证通过| M
 M --> C
 M --> D
 C --> E
 D -->|确认副作用| E
 D -->|无法确认| G
 E -->|新运行| A
 M --> F
```

## 20. 运行时解析与录制算法

### 20.1 DOM / Table 算法

对每个 Frame 建立独立身份；遍历直接属于当前 Table 的行与单元格（按 closest table 限定）。依 DOM 顺序为每行寻找第一个空闲逻辑列，展开 rowspan/colspan 占位，保留 origin cell 引用；rowspan=0 按所属 row group 剩余行处理，异常重叠标记歧义。嵌套表另建 ID 和父单元格关系。保留物理与逻辑坐标、可见性及边界矩形；隐藏单元格仍可能占逻辑位置，不能直接删除后重编号。表头优先 th/scope/headers，再用结构、文本、空间位置和设计书推断；不确定列路径标候选。每个目标绑定包含 frame、form、table、row key、column path、name/id、证据和版本。操作前重新解析必要局部，验证业务语义及唯一性；动态重渲染不复用旧元素句柄。

| DOM 单元格 | 逻辑网格映射 | 语义路径 |
|---|---|---|
| 商品番号 rowspan=2 | (0,0),(1,0) | 商品番号 |
| 変更前 colspan=2 | (0,1),(0,2) | 変更前 |
| 変更後 colspan=2 | (0,3),(0,4) | 変更後 |
| 数量（第二层第4逻辑列） | (1,3) | 変更後.数量 |
| A002 行 quantity | (3,3) 示例 | A002 / 変更後.数量 |

**图 36 · 复杂 Table 解析前后：合并表头到业务定位**

```mermaid
flowchart TD
 A["DOM：rowspan=2 / colspan=2"]
 B["逻辑网格 / 商品番号 | 変更前(数量,金額) | 変更後(数量,金額)"]
 C["A001 / A002 明细行"]
 M["业务键 A002 + 変更後.数量"]
 D["name=quantity / 正确 Frame 与 Table"]
 E["唯一性 / 可见性 / 可编辑性"]
 F["允许操作，否则人工拾取"]
 A --> B
 B --> C
 C --> M
 M --> D
 D --> E
 E --> F
```

### 20.2 Recorder 事件归一化

使用受控 Chrome 会话，通过 Playwright Context 的初始化脚本和事件桥接（具体版本需验证）记录 click/input/change、导航及 popup；在操作前捕获最小 DOM 上下文，不能等页面跳转后才解析旧元素。处理 IME composition、连续输入合并、checkbox/select 的 click 与 change 去重、键盘提交、Frame 和动态 DOM。按 page/frame + element identity + event sequence 关联；不确定事件保留原始证据并待确认。密码、令牌、文件路径等敏感输入用变量引用或过滤；不记录完整页面敏感数据。模板实时生成日文操作句，歧义交 Copilot。验证拾取模式阻止普通点击副作用，仅记录人工选定的断言候选，实际观察值不可自动转为规格预期。

**图 37 · 人工操作录制的事件归一化**

```mermaid
flowchart TD
 A["Chrome 输入 / 点击 / 选择"]
 B["操作前 DOM + Frame + Table 行上下文"]
 C["连续输入合并 / 事件去重 / 脱敏"]
 M["语义明确？"]
 D["固定日文模板"]
 E["待确认 / Copilot 语义匹配"]
 F["自然语言步骤 + DSL 候选"]
 G["人工确认预期与绑定"]
 A --> B
 B --> C
 C --> M
 M -->|是| D
 M -->|否| E
 E -->|确认后| D
 D --> F
 F --> G
```

## 21. MCP 契约与安全控制

所有下列接口为拟定应用层契约，不是现成 Playwright MCP 标准。共通输入 envelope: task_id、project_id、snapshot_id（知识调用）、revision（修改/执行）、request_id（幂等请求）；返回 status、data、evidence_refs、errors、next_action。认证与用户身份由服务端验证，不信任 Agent 传入的角色声明。

| 接口 | 必要业务输入 | 返回核心数据 | 约束 |
|---|---|---|---|
| get_screen_test_knowledge | screen_id, state/event filters | items, checks, events, completeness, refs | 固定 Snapshot |
| get_screen_checks | screen_id, filters | known_checks, scope, gaps | 无结果不等于无 Check |
| get_check_diff | from/to snapshot, check_ids | added/changed/deleted | 版本存在 |
| query_candidates | approved source, bounded predicates, limit | masked candidates, query evidence | 只读账号、超时、限行 |
| validate_test_data | candidate_id, predicate_refs | verified/unknown, evidence | 不隐式写入 |
| reserve/release_test_data | candidate_id/lease_id, policy | lease, status | 原子租约、恢复检查 |
| create_test_task | project, scope, input refs | task_id, revision | 去重请求 |
| save_test_plan | revision, plan | new_revision, validation | 乐观锁 |
| open_test_editor | task_id | local URL | 回环地址、会话授权 |
| get_review_status/get_script_diff | task_id, revision pair | approval, diff, hashes | 只读 |
| update_test_definition | base_revision, DSL, binding refs | draft revision, validation | 自动失效旧审批 |
| inspect_screen/get_table_structure | session_id, frame/table scope | DOM model, candidates | 限量脱敏 |
| resolve/validate_locator | target_ref, state, row predicates | candidate, match count, evidence | 歧义禁止执行 |
| start/stop_recording | session_id, mode | recording_id, events | 不记录敏感值 |
| execute_step/execute_test | approved revision, lease, idempotency key | run_id, status, step results | 审批、环境、副作用 gate |
| get_test_result/export_evidence | run_id, format | result refs, report refs | 脱敏、访问控制 |

错误码：INVALID_INPUT、VERSION_MISMATCH、REVISION_CONFLICT、APPROVAL_REQUIRED、KNOWLEDGE_GAP、AMBIGUOUS_TARGET、DATA_NOT_FOUND、DATA_UNSAFE、SESSION_LOST、SIDE_EFFECT_UNKNOWN、BUDGET_EXCEEDED、FORBIDDEN、TOOL_UNAVAILABLE。错误返回是否可重试及最小补充需求；SIDE_EFFECT_UNKNOWN 不可自动重试。写操作接口初期不开放任意 SQL，人工批准的独立准备工具执行白名单 Recipe。审批端点仅由已认证用户调用；Agent 不能代签。测试环境凭据通过安全配置，固定工具强制环境白名单、角色权限、输出限量和日志脱敏。

## 22. PoC 验收与 Review 追踪

### 22.1 验收矩阵（拟定标准，未实测）

| 验收 ID | 输入 / 操作 | 通过条件 |
|---|---|---|
| POC-01 | 真实无 label 查询、嵌套及合并 Table、重复 name 明细 | 人工确认的目标全部正确绑定；排序后仍定位正确业务行；歧义时阻止，不误操作 |
| POC-02 | 实际 Check 设计书 + 缺失/矛盾样本 | 已知正式规则均有来源，未知/确认无分别展示；异常期望不从实际行为倒推 |
| POC-03 | 共通 JDBC 无 Inspector；一条目标业务数据 | 至少一个实际可用候选并有 UI 前置验证；无候选时明确阻塞，不编造数据 |
| POC-04 | 自然语言 999→1000 | 旧批准不适用于新定义，差分显示异常系与后续步骤变化，重新审核后执行 |
| POC-05 | 人工录制含输入法、重复 name、画面迁移 | 操作正确归一为自然语言；敏感值过滤；歧义和预期须确认 |
| POC-06 | 重复提交、超时、进程中断 | 无自动重复写；不确定副作用阻塞并保留现场 |
| POC-07 | VS Code 目标版本 | 项目自定义选择列表仅 Main；五个隐藏角色可委派；验证模型/工具限制及恢复流程 |
| POC-08 | 新 Snapshot 修改或删除 Check | 受影响 Case 标记过期；旧结果保留；未审核调查不更新正式知识 |

必须提供代表性真实脱敏 HTML/JSP、画面项目和 Check 设计书、共通 JDBC 映射示例（可选）、测试 DB 权限、业务入口及成果物模板；缺失时仅能开展模拟验证。所有验收均以真实结果和证据为准。

### 22.2 Review 修改追踪

| Review ID | 修订位置 | 状态 |
|---|---|---|
| P01 Agent 职责重叠 / 多入口 | 2、13、16 | 已修订设计 |
| P02 Check 完整性 | 17 | 已补充 |
| P03 数据决策 | 18.1–18.2 | 已补充 |
| P04 数据恢复 | 18.3、19 | 已补充 |
| P05 NL/DSL 一致性 | 19.1 | 已补充 |
| P06 Recorder | 20.2 | 已补充 |
| P07 人工交接 | 19.2、21 | 已补充 |
| P08 Runner 恢复 | 19.2 | 已补充 |
| P09 MCP 契约 | 21 | 已补充逻辑契约，完整机器 Schema 待实现 |
| P10 PoC 验收 | 22.1 | 已补充，尚未实测 |

本版保留原 v0.2 内容及画面案例，替换与新 Agent 方案冲突的架构和目录，增加细化章节及图解。设计建议尚非已实现的软件；具体工具版本、数据权限、真实画面匹配和业务数据准备能力须 PoC 后锁定。
