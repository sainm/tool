# PG/UT Agent・Subagent・Skill・测试观点管理详细设计书

> 設計履歴・根拠の参照用。現在の実装範囲・承認・実行方式は [統合詳細設計書](../PG_UT_Agent_Integrated_Detailed_Design_JA_v0.5.1.md) に従う。


-   **文档版本**：v0.1（可调整基线）
-   **日期**：2026-11-25
-   **目标执行环境**：VS Code + GitHub Copilot（Copilot harness）
-   **主要语言**：Agent
    指令与设计文档可中日混合；面向业务人员的测试观点、测试计划和成果物优先日语
-   **状态**：详细设计提案 / PoC 前基线；不得视为已在目标项目验证
-   **设计原则**：先验证真实效果，再决定是否固化；配置优先于硬编码；所有
    AI 结论必须可追溯

------------------------------------------------------------------------

## 0. 本版的关键修正

本版在上一版 Agent / Skill 设计基础上增加和修正以下内容：

1.  **测试观点（Test Perspective /
    テスト観点）作为正式业务对象**，不再隐藏在 Test Plan 的普通步骤中。
2.  增加独立的 `test-perspective` Skill，由 Test Plan Agent
    负责调用；其职责包括主动提出观点、去重、适用性判断、缺口挑战和人工修订。
3.  测试观点先于 PG 生成；PG
    完成后，依据实际代码差分再做一次补充分析。代码实现不能反向取代已确认的业务规格。
4.  将"观点审查率、观点计划覆盖率、测试执行覆盖率、通过率、代码
    Coverage"分开定义。
5.  Agent、模型、Skill、Workflow、Quality Gate
    全部采用可调整配置；保留不可绕过的安全和审批底线。
6.  既存系统没有 Label 的情况纳入 Locator
    设计；不依赖全页扫描，也不要求每次测试前运行完整 Inspector。
7.  明确 TDD/UT 与业务 UI 测试是两条相互追踪但不可互相替代的验证链路。
8.  保留一个可见 Main Agent、五个隐藏专用 Subagent
    作为初始基线，但不把数量和职责永久写死。
9.  下一步先验证一个从 Menu 开始的真实 Business
    Flow，不先建设庞大的通用平台。

## 1. 目标、范围与非目标

### 1.1 目标

建立一套在 VS Code + GitHub Copilot 中运行的 PG/UT 工作体系：

-   用户只与一个可见 Main Agent 交互。
-   Main 按任务需要委派专用 Subagent。
-   Subagent 通过 Skill 执行专业工作。
-   知识库和 Graph 通过 MCP
    提供版本化知识；知识库优先，必要时才对源码做补充调查。
-   通过流程状态和审批记录控制任务阶段。
-   测试观点由 AI 主动提出，并由人确认、修订。
-   测试观点可以追踪到测试条件、测试案例、步骤、断言和执行证据。
-   PG 使用 TDD；UI 测试从 Menu 开始覆盖完整业务流程。
-   通过真实 PoC 数据持续调整 Agent、Skill、模型和流程。

### 1.2 本期范围

-   需求/详细设计差分读取和修改内容整理。
-   影响分析。
-   测试观点生成与审核。
-   测试计划、Case、Coverage Matrix。
-   测试数据候选调查与验证。
-   PG、UT 的 TDD 循环。
-   UI 测试定义、元素绑定、Playwright 执行和证据收集。
-   测试失败分类、修复回路和最终成果物。
-   测试知识候选的主动提交与人工审核。

### 1.3 非目标

-   不自研完整 AI Agent Harness；使用 VS Code / Copilot 的 Agent 能力。
-   不在第一阶段开发新的 VS Code 插件。
-   不为了测试改造既存业务系统，不增加 JDBC Runtime Inspector。
-   不假设能够完整解析所有设计书、源码、SQL 或业务规则。
-   不把 RAG / Graph 的零结果解释为"没有规则"。
-   不自动将调查结果或测试运行记录写入正式知识库。
-   不把 UI 测试缩减为单画面测试；最小验证单元是从 Menu 开始的完整
    Business Flow。
-   不以代码行覆盖率代替业务测试观点覆盖率。

## 2. 已知约束与设计假设

  ------------------------------------------------------------------------------------------------------------------------------------------
  项目                    已知条件 / 约束                                       设计处理
  ----------------------- ----------------------------------------------------- ------------------------------------------------------------
  执行环境                VS Code + GitHub Copilot                              使用 Copilot harness 的 Custom Agent 和原生 Task
                                                                                委派；不照搬 Local harness 配置

  用户入口                不希望出现大量可见 Agent                              初始只显示 Main；专用 Agent 隐藏并由 Main 委派

  既存系统                Struts 1、JSP、自定义 Framework、JDBC 等旧系统特征    不依赖现代 HTML Label 或统一组件规范

  画面元素                部分元素没有 Label，存在重复 name、复杂 Table、动态   使用多属性和上下文定位；必要时局部运行时调查
                          DOM                                                   

  业务状态                Session、跨画面数据流、前置业务输出可能影响当前业务   UI 测试按完整业务流程设计，显式管理前置条件和数据

  知识库                  设计书、代码是素材；知识库/Graph 的内容可能不完整     知识库优先；缺口必须显式呈现，不能推断为无规则

  数据准备                当前没有既存统一数据准备工具；DB                      先只读寻找现有数据；验证业务前置条件；写入需独立授权
                          有数据但不能假设数据可用                              

  JDBC                    共通 JDBC、动态 SQL、反射等造成静态关系不完整         不要求捕获所有 Runtime SQL；结合元数据、业务键、只读查询、UI
                                                                                验证

  UT                      UT 的目标是 TDD                                       必须 Red → PG → Green → Refactor；UT 与 UI Test 分离

  UI 自动化               Playwright MCP 可供 AI 以自然语言操作                 自然语言用于辅助交互；稳定执行仍需明确目标元素、步骤和预期

  知识治理                调查结果不能自动成为正式知识                          调查记录与正式知识分离；主动提交、审核后才入库
  ------------------------------------------------------------------------------------------------------------------------------------------

以上约束来自既有讨论；具体项目技术版本、数据库类型、Playwright MCP
版本和 Copilot 可用模型仍需在 PoC 环境确认。

## 3. 核心设计原则

### 3.1 可调整，但不失控

可调整内容：

-   Agent 数量、职责边界、是否拆分。
-   各 Agent 的模型偏好和降级模型。
-   Skill 拆分、合并、加载方式。
-   Workflow 阶段、顺序、并行关系和可选阶段。
-   测试观点目录、风险权重、覆盖目标。
-   Inspector 触发条件、Locator 评分规则。
-   Task 超时、重试、并行数、上下文预算。
-   Quality Gate 的阈值和例外审批规则。

不可被普通配置关闭的底线：

-   未经人工批准，不得越过要求确认的阶段。
-   未经批准，不得把未知预期伪装成确定规格。
-   不得通过删除失败测试、降低断言或缩小分母来制造 100%。
-   不得执行未经授权的 DB 写入或不安全业务操作。
-   未经审核，不得更新正式知识库 Snapshot。
-   所有执行结果必须绑定具体测试定义版本、代码 Revision 和知识
    Snapshot。

### 3.2 AI 负责推理，程序负责确定性控制

  工作                              主要承担者
  --------------------------------- -------------------------------
  理解需求、发现潜在测试观点        AI / Skill
  归纳业务规则和提出候选影响        AI + KB/Graph MCP
  观点适用性与预期确认              人工审核，AI 辅助
  测试案例和自然语言步骤生成        AI / Test Plan Agent
  任务状态、审批状态、版本校验      Workflow State Manager
  DB 查询范围、数据权限、执行授权   MCP 服务端
  Locator 唯一性校验                Locator Resolver / Playwright
  Playwright 浏览器操作             Playwright MCP 或受控 Runner
  TDD 的测试执行与 Coverage 收集    UT Agent + 测试工具
  正式知识入库                      知识库审核流程

Skill
中的"必须遵守"是行为指导，不等于安全隔离。真正的权限和审批约束必须在工具服务端或执行入口校验。

## 4. 总体架构

``` mermaid
flowchart TB
    U["用户 / VS Code Chat"]
    H["Copilot Harness"]
    M["PG/UT Main Agent（唯一可见入口）"]
    W["Workflow State Manager（配置驱动）"]
    S["Skill Catalog（按需加载）"]

    IA["Impact Analysis Subagent"]
    TP["Test Plan Subagent"]
    TD["Test Data Subagent"]
    PG["PG Subagent"]
    UT["UT Subagent"]
    TMP["临时 Task / 专项 Review"]

    MCP["Domain MCP Layer"]
    KB["Knowledge Base MCP / RAG"]
    GR["Graph MCP"]
    DB["DB MCP（只读优先）"]
    UI["Playwright MCP / UI Test Adapter"]
    RUN["Test DSL Runner（可选的确定性执行路径）"]
    ART["Task Assets / Evidence / Reports"]

    U --> H --> M
    M <--> W
    M <--> S
    M --> IA
    M --> TP
    M --> TD
    M --> PG
    M --> UT
    M --> TMP
    IA --> MCP
    TP --> MCP
    TD --> MCP
    PG --> MCP
    UT --> MCP
    TMP --> MCP
    MCP --> KB
    MCP --> GR
    MCP --> DB
    MCP --> UI
    MCP --> RUN
    M --> ART
    IA --> ART
    TP --> ART
    TD --> ART
    PG --> ART
    UT --> ART
```

### 4.1 组件职责

  组件                     职责                                  是否负责 AI 推理
  ------------------------ ------------------------------------- ------------------
  Copilot Harness          Agent 执行环境、Task 委派、模型调用   是
  Main Agent               流程编排、用户交互、结果合并          是
  Subagent                 专项分析或实现                        是
  Skill                    专业方法、步骤、约束、输出规范        否，提供指令
  Workflow State Manager   状态、审批、版本、并发和恢复          否
  Domain MCP               向 Agent 提供受控业务工具             否
  Knowledge Base / Graph   正式知识和关系查询                    否
  DB MCP                   元数据、只读候选调查和验证            否
  Playwright MCP           浏览器操作和页面交互                  否
  Test DSL Runner          解释已确认的测试定义并执行            否
  Task Asset Store         保存计划、差分、日志、证据            否

### 4.2 UI 执行采用双模式，避免过早锁死

**模式 A：AI 辅助自然语言执行**

-   Agent 读取已知画面结构和元素知识。
-   通过 Playwright MCP 以自然语言组织浏览器操作。
-   在关键动作前解析目标元素并验证唯一性。
-   适合 PoC、探索、人工辅助、尚未固化的业务流程。

**模式 B：已确认定义的重复执行**

-   将已审核的自然语言步骤转为 Test DSL 或固定 Playwright 脚本。
-   通过 Runner 按确定性步骤执行。
-   适合回归、批量执行、稳定复用和可审计成果物。

两种模式共用测试观点、Case、元素绑定和预期定义。第一阶段先验证模式
A；只有当重复执行、稳定性或审计需求证明有必要时，再固化模式 B。不要在
PoC 前强制建设完整 DSL 平台。

## 5. 测试观点（Test Perspective）正式模型

### 5.1 概念区分

  -----------------------------------------------------------------------------------------------
  对象                    定义                                     示例
  ----------------------- ---------------------------------------- ------------------------------
  Requirement / Change    业务或规格发生变化的内容                 数量上限由 99 改为 999
  Point                                                            

  Rule / Check            已知规则及其证据                         数量必须为 1～999

  Test Perspective        从哪个质量/业务角度验证                  上限边界、下限边界、非法输入

  Test Condition          观点下的具体条件或值                     999、1000、0、空值

  Test Scenario           一组完整业务场景                         Menu → 查询 → 编辑 → 确认

  Test Case               有明确前置、输入、操作、预期的测试单元   输入 1000 后验证错误提示

  Test Step               一个可执行动作                           在数量输入框输入 1000

  Assertion               对实际结果的判断                         出现指定错误消息，不能登记

  Target Binding          UI 元素、DB 观察点或 API 目标绑定        数量字段的 Locator

  Evidence                执行证据                                 截图、日志、DB 查询结果
  -----------------------------------------------------------------------------------------------

**Test Perspective 不等于 Check。** Check 是已有规则；Test Perspective
是验证角度。一个 Check 可以展开多个观点；一个观点也可以综合多个
Check、设计差分和代码路径。

### 5.2 观点来源

观点生成必须结合多种来源，不能只读取知识库已有 Check。

  来源                  作用                                        使用时点
  --------------------- ------------------------------------------- -----------------
  用户需求 / 修改说明   确定业务目标和变化范围                      PG 前
  详细设计差分          提取规格变化、输入输出、条件和画面规则      PG 前
  知识库 Check          取得已知验证规则、触发时机、消息和证据      PG 前
  Graph 关系            发现上下游画面、业务事件、数据和共通逻辑    PG 前
  影响分析结果          扩展受影响业务、画面、项目、DB 和回归范围   PG 前
  既存测试资产          识别当前已验证内容和历史遗漏                PG 前
  代码结构 / 调用关系   在设计知识不足时补充候选路径                PG 前或调查阶段
  PG 后代码差分         发现实际实现新增分支、异常处理和副作用      PG 后补充
  历史缺陷 / 失败记录   发现曾经发生过的问题类型                    规划和回归阶段
  人工追加              补充 AI 或现有资料没有发现的观点            全阶段

知识库优先原则不等于只能使用知识库。知识库没有数据、关系不完整或版本不匹配时，必须标记知识缺口，并按授权范围补充调查；不能编造关系。

### 5.3 测试观点生成流程

``` mermaid
flowchart TD
    A["需求 / 设计差分 / Snapshot"]
    B["变更点原子化"]
    C["读取 Check、事件、依赖、画面知识"]
    D["读取影响分析与既存测试"]
    E["生成来源驱动的观点候选"]
    F["套用通用观点目录进行挑战"]
    G["跨来源去重、合并、冲突检查"]
    H["生成观点清单 + 证据 + 未知项"]
    I{"人工审核"}
    J["接受 / 编辑"]
    K["拒绝（记录理由）"]
    L["待补充证据"]
    M["映射测试条件和 Case"]
    N["Coverage Matrix"]
    O["PG 后差分复核"]
    P["新增观点候选 / 影响原计划"]
    A --> B --> C --> D --> E --> F --> G --> H --> I
    I --> J --> M
    I --> K
    I --> L
    M --> N --> O --> P
```

### 5.4 AI 主动提出观点的两轮机制

**第一轮：来源驱动生成**

从需求、详细设计、Check、Graph、影响分析和既存测试中提取明确规则与变化点。每个观点都必须引用至少一个来源，或明确标记为通用测试建议。

**第二轮：通用测试观点挑战**

AI
使用可配置的观点目录，检查是否遗漏常见角度。不得无差别生成全部观点；必须说明适用性、理由和所需证据。

建议的初始观点目录：

  --------------------------------------------------------------------------------------------
  类别                    观点示例                                适用判断
  ----------------------- --------------------------------------- ----------------------------
  正常系                  有效输入、正常流程、正常保存            默认检查

  异常系                  非法值、服务异常、业务拒绝              按规则检查

  边界值                  最小值、最大值、边界外一位              数值/长度/日期等适用

  等价类                  有效/无效输入分组                       输入规则适用

  必填与格式              空值、空白、全角/半角、类型             输入字段适用

  条件组合                多条件同时成立或冲突                    多规则适用

  状态迁移                初期、编辑、确认、完成、取消            状态型业务适用

  画面事件                初期表示、按钮、选择、失焦、提交        UI 适用

  画面项目控制            显示/隐藏、只读、必填、启用/禁用        UI 项目适用

  消息与焦点              错误消息、消息位置、焦点返回            有验证或错误反馈时适用

  Table                   行定位、行追加/删除、排序、分页、汇总   Table 适用

  DB 持久化               新增、更新、删除、关联数据              有持久化变化时适用

  事务一致性              回滚、部分失败、重复提交                有事务或副作用时适用

  幂等性                  连续点击、重复请求、刷新重发            操作可能重复时适用

  并发                    同一记录被多人修改                      业务存在并发风险时适用

  权限                    角色、组织、数据范围                    存在权限规则时适用

  Session / 导航          Session 丢失、返回、刷新、跨画面状态    旧系统适用性较高

  外部联携                API、文件、批处理、其他系统             存在外部依赖时适用

  回归                    未修改但可能受共通逻辑影响的功能        根据影响范围选择

  可恢复性                中断、失败后重试、数据恢复              有长事务或多步骤业务时适用
  --------------------------------------------------------------------------------------------

观点目录应由配置文件维护。每个项目可以增删观点、修改描述和默认风险，但不能通过删观点来隐藏已发现的风险；修改目录必须有版本记录。

### 5.5 观点状态与人工修订

每条观点的状态：

-   `PROPOSED`：AI 或人员提出，尚未审查。
-   `ACCEPTED`：确认适用，进入计划。
-   `REJECTED`：不采用，必须记录理由。
-   `NOT_APPLICABLE`：确认不适用，必须记录适用性判断依据。
-   `NEEDS_EVIDENCE`：缺少证据，暂不能决定。
-   `NEEDS_SPEC_CONFIRMATION`：预期行为不明确，需要业务/规格确认。
-   `SUPERSEDED`：被新版本观点替代。
-   `IMPLEMENTATION_DISCOVERED`：PG 后从实现差分发现，待审查。

人员可以：

-   接受观点。
-   修改观点描述和范围。
-   拆分观点。
-   合并重复观点。
-   拒绝并记录理由。
-   标记不适用。
-   补充来源和证据。
-   手工新增观点。

AI 不得自行把 `NEEDS_SPEC_CONFIRMATION`
改成已确认规格；也不得因没有资料而将观点判为不适用。

### 5.6 观点对象字段

``` json
{
  "perspective_id": "TP-INPUT-BOUNDARY-001",
  "revision": 1,
  "title": "数量上限边界验证",
  "category": "BOUNDARY",
  "description": "验证数量字段在允许上限及上限外一位时的行为",
  "source_refs": [
    {"type": "design_diff", "ref": "DESIGN-DIFF-001"},
    {"type": "check", "ref": "CHECK-ITEM-012"}
  ],
  "change_point_refs": ["CHANGE-001"],
  "applicability": "APPLICABLE",
  "status": "PROPOSED",
  "expected_behavior": {
    "value": null,
    "source_ref": null,
    "confirmation_status": "NEEDS_SPEC_CONFIRMATION"
  },
  "conditions": ["999", "1000"],
  "test_levels": ["UI", "UT"],
  "risk": "HIGH",
  "rationale": "上限变更容易产生边界判断遗漏",
  "case_refs": [],
  "review": {
    "reviewer": null,
    "decision": null,
    "reason": null
  }
}
```

`expected_behavior.value`
可以为空。缺少明确预期时，系统只能提出"需要验证什么"，不能虚构"应该发生什么"。

### 5.7 观点与测试案例的追踪关系

正式追踪链：

``` text
Requirement / Change Point
    ↓
Rule / Check
    ↓
Test Perspective
    ↓
Test Condition
    ↓
Scenario / Test Case
    ↓
Test Step + Assertion
    ↓
Target Binding（UI / DB / API）
    ↓
Execution Run
    ↓
Evidence
```

关系允许多对多：

-   一个观点可以关联多个 Case，例如最大值、超上限、空值。
-   一个 Case 可以覆盖多个观点。
-   一个 Check 可以对应多个观点。
-   一个观点可以由 UT、UI、手工检查等多个层级共同验证。

## 6. 覆盖率定义与质量门禁

### 6.1 必须分开的指标

  ---------------------------------------------------------------------------------------------
  指标                    计算方法                     说明
  ----------------------- ---------------------------- ----------------------------------------
  观点审查率              已作出审查决定的候选观点数 / ACCEPTED、REJECTED、NOT_APPLICABLE
                          全部候选观点数               均视为已处理；NEEDS\_\* 不算完成

  观点计划覆盖率          已关联至少一个有效 Case      判断计划是否覆盖观点
                          的适用观点数 /               
                          已接受的适用观点数           

  Case 追踪率             有观点/规则来源的 Case 数 /  允许探索性 Case，但必须标识来源类型
                          全部正式 Case 数             

  测试执行覆盖率          已执行 Case 数 / 应执行 Case BLOCKED、NOT_RUN、SKIPPED 不得算作已执行
                          数                           

  观点执行覆盖率          已完成其必需 Case            一个观点要求多个边界 Case
                          执行的观点数 /               时不能只执行其中一个
                          有执行要求的适用观点数       

  通过率                  PASS Case 数 / 已执行 Case   与覆盖率分开
                          数                           

  代码 Coverage           行/分支等工具指标            只衡量代码执行覆盖，不代表业务观点覆盖
  ---------------------------------------------------------------------------------------------

### 6.2 100% 的解释

可设置以下目标：

-   观点审查率：100%。
-   适用观点计划覆盖率：100%。
-   应执行 Case 的执行覆盖率：100%。
-   高风险未决观点：0，或有明确人工风险接受记录。
-   所有测试预期：有来源或人工确认。
-   所有执行结果：有版本和证据引用。

不能声称"整个系统测试观点绝对 100%"。正确表述是：

> 在本次已确认的项目、Snapshot、Business
> Flow、变更范围和观点目录版本内，所有已识别候选观点均已审查；所有已接受适用观点均已映射到测试案例；所有要求执行的案例均已执行。未确认范围和知识缺口另行列示。

### 6.3 不得隐藏的分母

覆盖报告必须同时展示：

-   已识别候选观点总数。
-   已接受观点数。
-   已拒绝观点数及理由。
-   不适用观点数及理由。
-   待补充证据数。
-   待规格确认数。
-   已映射 Case 数。
-   未映射观点数。
-   已执行 / 未执行 / 阻塞 Case 数。
-   观点来源完整性和 Snapshot 范围。

未知项不能从分母中静默删除。报告中需要展示"已确认范围覆盖率"和"未确认范围风险"，不能只给一个漂亮的百分比。

### 6.4 Quality Gate

  ------------------------------------------------------------------------------------------------------------
  Gate                    通过条件                                                不通过时
  ----------------------- ------------------------------------------------------- ----------------------------
  G-CHANGE                修改内容已人工确认                                      返回修改提案

  G-IMPACT                影响范围已人工确认                                      补充影响调查

  G-PERSPECTIVE           适用观点已审查；高风险未知项有处理结论                  继续提出观点或请求规格确认

  G-PLAN                  适用观点均已映射 Case；预期有依据                       补充 Case / 确认预期

  G-DATA                  测试数据满足前置条件并有证据                            重新寻找数据或 BLOCKED

  G-TDD                   Red/Green/Refactor 证据及必要 UT 结果完成               返回 PG/UT 循环

  G-UI-EXEC               测试定义已确认、环境/数据授权有效、目标元素可唯一定位   阻止执行

  G-FINAL                 执行覆盖达到配置目标，结果和证据完整                    补测或列出例外
  ------------------------------------------------------------------------------------------------------------

Gate 可以按项目配置为必需或条件触发，但审批和数据安全底线不能被 Skill
文本关闭。

## 7. 完整工作流程

### 7.1 主流程

``` mermaid
flowchart TD
    A["用户提出修改需求"]
    B["Main 创建任务 / 固定 Snapshot 和 Code Revision"]
    C["knowledge-change：读取差分并原子化变更点"]
    D["生成修改提案"]
    E{"人工确认 1"}
    F["Impact Analysis Subagent"]
    G["影响清单 / 证据 / 未知风险"]
    H{"人工确认 2"}
    I["Test Plan：读取 Check / 事件 / 依赖 / 既存测试"]
    J["test-perspective：AI 主动提出测试观点"]
    K["观点去重、挑战、缺口与人工修订"]
    L["test-plan-coverage：Case + Coverage Matrix"]
    M{"测试定义确认（按 Profile）"}
    N["Test Data：只读候选查找与验证"]
    O["UT：按 TDD 编写 RED 测试"]
    P["PG：实现代码"]
    Q["UT：GREEN / Refactor / 回归"]
    R["PG 后代码差分复核观点"]
    S["必要时追加观点 / Case / 重新审批"]
    T["UI Test：从 Menu 执行完整业务流程"]
    U["失败分类与返回对应阶段"]
    V["最终 Review / Evidence"]
    W["交付测试成果物"]
    X["主动提交知识候选"]
    Y["人工审核后进入正式知识库"]

    A --> B --> C --> D --> E
    E -->|修改| D
    E -->|批准| F --> G --> H
    H -->|补充调查| F
    H -->|批准| I --> J --> K --> L --> M
    M -->|修改| J
    M -->|批准| N
    N --> O --> P --> Q --> R
    R -->|有新增观点| S --> K
    R -->|无新增观点| T
    S --> T
    T -->|程序缺陷| P
    T -->|数据问题| N
    T -->|Locator/脚本问题| T
    T -->|规格不明| K
    T -->|完成| V --> W --> X --> Y
```

### 7.2 阶段说明

  ------------------------------------------------------------------------------------------------------------------------
  阶段           负责人             输入                          输出                可并行
  -------------- ------------------ ----------------------------- ------------------- ------------------------------------
  任务建立       Main               修改需求、项目、Snapshot      Task Record         否

  修改内容整理   Main +             设计差分、需求                Change Proposal     否
                 knowledge-change                                                     

  人工确认 1     人                 Change Proposal               Approval 1          否

  影响分析       Impact             已批准变更、知识引用          Impact Report       内部只读调查可并行

  人工确认 2     人                 Impact Report                 Approval 2          否

  测试观点提出   Test Plan +        变更、Check、影响、既存测试   Perspective         与部分数据元信息调查可并行
                 test-perspective                                 Register            

  观点审核       人 + Main          Perspective Register          已确认观点版本      否

  测试计划       Test Plan          已确认观点                    Case                部分 Case 可并行生成
                                                                  Catalog、Coverage   
                                                                  Matrix              

  数据调查       Test Data          Data Request                  Candidate /         可与 PG 前的部分准备并行
                                                                  Evidence / Blocker  

  TDD            UT + PG            已确认规格、观点、代码差分    UT 结果、代码修改   PG/UT 按测试循环协作

  PG 后观点复核  Test Plan / 临时   实际代码差分                  Supplemental        与不冲突的 UI 数据准备并行
                 Review Task                                      Perspectives        

  UI 测试        Main + UI Skill /  已确认 Case、数据、画面知识   UI Run / Evidence   独立业务流可并行，初期不启用
                 临时 Task                                                            

  最终 Review    Main               所有成果物                    Final Report        否

  知识提交       Main + 人工审核    可复用知识候选                Submission          与成果物整理可并行；正式入库须审核
                                                                  Candidate           
  ------------------------------------------------------------------------------------------------------------------------

### 7.3 原有两次人工确认如何保留

-   **确认 1**：确认要修改什么，范围是否正确。
-   **确认 2**：确认影响哪些文件、画面、业务和验证范围。
-   **测试定义确认**：确认观点、预期和 Case；默认对正式 UI
    测试启用，可按风险配置。
-   **执行授权**：仅当 UI
    测试会产生业务写入、数据变更或其他副作用时要求。
-   **知识提交审核**：决定调查/测试新发现是否进入正式知识库。

后续可通过 Workflow Profile 调整确认策略，但不能让 Agent 自己批准。

## 8. Agent / Subagent 设计

### 8.1 初始 Agent 结构

  -----------------------------------------------------------------------------------------------------------------------------------------------
  Agent       可见性       唯一责任                   输入                          输出                             权限
  ----------- ------------ -------------------------- ----------------------------- -------------------------------- ----------------------------
  PG/UT Main  可见         流程、用户交互、Task       用户需求、任务状态            主任务状态、分派记录、最终报告   不绕过审批；不自行改写其他
                           委派、审批协调、结果汇总                                                                  Agent 的正式成果

  Impact      隐藏         影响分析                   已确认变更、Snapshot          Impact Report                    KB/Graph/源码只读
  Analysis                                                                                                           

  Test Plan   隐藏         测试观点、Case、Coverage   变更、影响、Check、测试资产   Perspective Register、Test Plan  不改业务代码、不写业务 DB
                           Matrix                                                                                    

  Test Data   隐藏         测试数据候选、验证、租约   Data Request、环境            Candidate Report、Lease          默认只读；不执行任意 SQL
                                                                                                                     写入

  PG          隐藏         业务代码修改               已批准变更、影响、测试要求    Code Diff、Build 结果            限定代码工作区

  UT          隐藏         TDD、UT、代码 Coverage     已确认规则、代码差分          UT Diff、Run、Coverage           限定测试工作区和测试命令

  临时 Task   无固定入口   特定调查、独立             Main 明确分配的范围           专项结果与证据                   最小权限、无审批权
                           Review、复杂失败分析                                                                      
  -----------------------------------------------------------------------------------------------------------------------------------------------

### 8.2 为什么初期不建立固定 UI Test Agent

初期只验证一个从 Menu 开始的业务流程。Main 使用 `ui-testing` Skill 和
Playwright MCP 即可。

以下情况出现后，再评估固定 UI Test Agent：

-   UI 测试执行时间长，明显占用 Main 上下文。
-   UI 失败调查需要大量独立分析。
-   UI 测试有稳定、重复、独立的执行任务。
-   需要独立的工具权限和模型偏好。
-   多条 Business Flow 可以独立并行。

临时 Task 是一次性委派，不意味着运行时动态创建新的 Custom Agent
文件。Copilot 的自定义 Agent 定义仍需在项目中维护。

### 8.3 Agent Profile

Agent
的模型和工具不应写死在业务流程中。建议维护一个项目级角色配置，作为设计和审核基线；VS
Code 的实际 `.agent.md` 文件仍是 Copilot Harness 的执行配置。

``` yaml
version: 1
agents:
  main:
    visible: true
    model_policy: preferred
    preferred_model: null
    fallback: current_session_model
    skills:
      - pg-ut-workflow
      - knowledge-change
      - evidence-governance
    responsibilities:
      - orchestration
      - approval_coordination
      - result_merge

  impact-analysis:
    visible: false
    model_policy: preferred
    preferred_model: null
    fallback: main_model
    skills:
      - impact-analysis
    permissions:
      source_read: true
      source_write: false
      database_write: false

  test-plan:
    visible: false
    model_policy: preferred
    preferred_model: null
    fallback: main_model
    skills:
      - test-perspective
      - test-plan-coverage
    permissions:
      business_code_write: false
      database_write: false

  test-data:
    visible: false
    model_policy: economical
    preferred_model: null
    fallback: main_model
    skills:
      - test-data
    permissions:
      database_read: true
      database_write: false

  pg:
    visible: false
    model_policy: coding
    preferred_model: null
    fallback: main_model
    skills:
      - tdd-cycle
    permissions:
      business_code_write: true

  ut:
    visible: false
    model_policy: coding
    preferred_model: null
    fallback: main_model
    skills:
      - tdd-cycle
      - test-plan-coverage
    permissions:
      test_code_write: true
      business_code_write: false
```

`model_policy` 是项目自己的策略标签，不是 VS Code
的原生模型配置字段。实际 `.agent.md`
的模型字段、可选模型和工具名必须按当前 Copilot Harness
版本生成并验证。不要在设计书中假定某个模型 ID 永远可用。

### 8.4 模型分配策略

  -----------------------------------------------------------------------------------------
  任务                    模型选择原则                       PoC 观察指标
  ----------------------- ---------------------------------- ------------------------------
  Main                    推理、长流程控制、工具规划         是否跳阶段、是否正确合并结果

  Impact                  复杂关系推理、证据归纳             影响漏报、误报、证据质量

  Test Plan               业务规则推理、观点生成、测试设计   观点遗漏率、人工修订率、Case
                                                             质量

  Test Data               SQL/数据结构理解、约束推理         候选可用率、错误候选率

  PG                      代码理解与生成                     修改正确率、编译/构建结果

  UT                      测试设计与调试                     Red/Green 正确性、分支覆盖

  临时 Review             与主任务不同的推理视角             新发现的有效缺口、重复意见率
  -----------------------------------------------------------------------------------------

模型选择不是按"强模型一定更好"决定。记录每次 Task
的实际模型、耗时、Token/费用（如果可获取）、返工和人工修订；根据真实结果调整。

## 9. Skill 设计

### 9.1 Skill 清单

  ----------------------------------------------------------------------------------------------------
  Skill                   主要使用者        责任                                     关键输出
  ----------------------- ----------------- ---------------------------------------- -----------------
  `pg-ut-workflow`        Main              主流程规则、阶段、委派、恢复             Workflow Action

  `knowledge-change`      Main              读取设计差分、整理修改提案               Change Proposal

  `impact-analysis`       Impact            多路径影响发现、证据验证                 Impact Report

  `test-perspective`      Test Plan         主动提出观点、挑战遗漏、去重、人工修订   Perspective
                                                                                     Register

  `test-plan-coverage`    Test Plan / UT    观点展开 Case、追踪矩阵、Coverage 检查   Test Plan /
                                                                                     Coverage Matrix

  `test-data`             Test Data         元数据、候选、验证、租约                 Data Candidate
                                                                                     Report

  `tdd-cycle`             UT / PG           Red → Green → Refactor                   UT / Code Result

  `ui-testing`            Main / 临时 UI    Business Flow、元素绑定、Playwright 操作 UI Run / Evidence
                          Task                                                       

  `failure-analysis`      Main / 临时 Task  分类失败并决定返回阶段                   Failure Report

  `evidence-governance`   Main              证据、成果物、知识候选提交               Evidence Package
  ----------------------------------------------------------------------------------------------------

### 9.2 Skill 的统一目录

``` text
.github/
  agents/
    pg-ut-main.agent.md
    impact-analysis.agent.md
    test-plan.agent.md
    test-data.agent.md
    pg.agent.md
    ut.agent.md

  skills/
    pg-ut-workflow/
      SKILL.md
      references/
      templates/

    knowledge-change/
      SKILL.md
      templates/

    impact-analysis/
      SKILL.md
      references/
      templates/

    test-perspective/
      SKILL.md
      references/
        perspective-catalog.yaml
        perspective-generation-rules.md
      templates/
        perspective-register.yaml

    test-plan-coverage/
      SKILL.md
      schemas/
      templates/

    test-data/
      SKILL.md
      schemas/
      templates/

    tdd-cycle/
      SKILL.md
      templates/

    ui-testing/
      SKILL.md
      references/
      templates/

    failure-analysis/
      SKILL.md
      references/

    evidence-governance/
      SKILL.md
      schemas/
      templates/

  instructions/
    project-conventions.instructions.md

  mcp.json
```

不要为了目录整齐而强行给每个 Skill
增加脚本。只有重复、确定性、适合程序执行的工作才放入
`scripts/`；判断和业务语义放在 Skill 指令与 AI 推理中。

### 9.3 Skill 的标准内容

每个 `SKILL.md` 至少包含：

1.  名称、描述和触发条件。
2.  不负责的工作。
3.  输入与前置条件。
4.  执行步骤。
5.  可用 MCP / Tool。
6.  证据与版本要求。
7.  输出 Schema。
8.  异常和阻塞处理。
9.  完成条件。
10. 至少一个正例和反例。

### 9.4 `test-perspective` Skill 详细执行规范

**目标**：从已知资料和通用测试方法主动提出测试观点，并将未知项暴露出来。

**输入**：

-   task_id / project_id / snapshot_id。
-   已批准 Change Proposal。
-   Impact Report。
-   Check、事件、依赖、画面知识。
-   既存测试资产和历史缺陷（如可用）。
-   观点目录版本。

**执行步骤**：

1.  检查输入 Revision 和 Snapshot 是否一致。
2.  将修改拆分为原子 Change Point。
3.  逐一提取明确业务规则和已有 Check。
4.  按画面、项目、事件、业务流程、数据和外部关系扩展来源。
5.  对每个 Change Point 执行来源驱动观点生成。
6.  使用观点目录做第二轮遗漏挑战。
7.  生成正常、异常、边界、条件组合、状态迁移、持久化、事务、消息、权限、回归等适用候选。
8.  对候选去重，保留合并后的全部来源。
9.  对适用性进行 `APPLICABLE / NOT_APPLICABLE / UNKNOWN` 判断。
10. 没有预期来源时标记 `NEEDS_SPEC_CONFIRMATION`，不得推断预期。
11. 形成观点清单、来源、理由、风险和待确认问题。
12. 请求 Main 展示给用户审核。
13. 根据用户决定更新 Perspective Register。
14. 记录每次修改的 Revision 和审批人。
15. PG 完成后，读取代码差分，生成 `IMPLEMENTATION_DISCOVERED` 候选。
16. 比较原观点和新增候选，判断是否需要补充 Case 或重新确认。

**输出**：

-   Perspective Register。
-   Perspective Source Map。
-   Unresolved Perspective List。
-   Suggested Test Conditions。
-   Test Data Requests（候选）。
-   Review Required List。

**禁止事项**：

-   不得将无知识库结果视为无规则。
-   不得从实际实现自动推断业务预期。
-   不得静默删除观点。
-   不得把 UNKNOWN 变成 NOT_APPLICABLE。
-   不得为了达到 100% 修改覆盖率分母。
-   不得直接修改业务代码或写业务 DB。

### 9.5 `test-plan-coverage` Skill 详细执行规范

1.  读取已审核的 Perspective Register。
2.  对每个 ACCEPTED 观点建立一个或多个 Test Condition。
3.  决定测试层级：UT、UI、集成、手工或其他；说明选择理由。
4.  将多个条件组合为逻辑 Case，避免无意义的笛卡尔积。
5.  明确前置数据、操作、预期、断言、证据。
6.  将 Case 映射到观点、Check、Change Point 和业务流程。
7.  识别无 Case 观点、无来源 Case、无预期 Case。
8.  计算计划覆盖率并输出分母明细。
9.  为 Test Data Agent 生成 Data Request。
10. 生成可供人员编辑的测试计划草案。
11. 保存用户确认后的版本。
12. PG 后依据代码差分重新计算增量覆盖。

### 9.6 `tdd-cycle` Skill 详细执行规范

-   UT Agent 先根据已确认的规则和观点编写测试。
-   Red 阶段必须证明新增测试能在预期条件下失败；记录失败原因。
-   PG Agent 只修改授权范围内的业务代码。
-   Green 阶段运行新增测试及相关回归。
-   Refactor 阶段保持测试通过，检查副作用。
-   Coverage 统计行/分支等指标，单独报告。
-   不得通过删除失败测试、跳过断言或降低测试强度来通过门禁。
-   如果实现揭示规格缺口，返回观点/规格确认流程，不由 PG
    自行决定业务预期。

### 9.7 Skill 与 Agent 的调用关系

``` text
Main
  ├─ pg-ut-workflow
  ├─ knowledge-change
  ├─ evidence-governance
  │
  ├─ Task → Impact Analysis
  │           └─ impact-analysis
  │
  ├─ Task → Test Plan
  │           ├─ test-perspective
  │           └─ test-plan-coverage
  │
  ├─ Task → Test Data
  │           └─ test-data
  │
  ├─ Task → UT
  │           ├─ tdd-cycle
  │           └─ test-plan-coverage（只读已批准观点/Case）
  │
  ├─ Task → PG
  │           └─ tdd-cycle
  │
  └─ 临时 Task
              ├─ ui-testing
              └─ failure-analysis
```

Skill 是按需加载的指令和资源，不应假设 Skill A 可以像函数一样直接调用
Skill B。流程调度由 Main 完成；Subagent 的 Task 必须明确输入、要求使用的
Skill 和输出格式。

## 10. Workflow State Manager 详细设计

### 10.1 设计目标

建立一个轻量、配置驱动的状态服务，负责：

-   Task 创建、查询、版本管理。
-   Workflow Profile 读取。
-   阶段状态迁移。
-   人工审批记录。
-   Task / Agent 输出登记。
-   并行任务冲突控制。
-   失败、恢复、重试记录。
-   审批与执行绑定。
-   统计实际流程数据。

它不负责：

-   调用模型推理。
-   取代 Copilot Task 委派。
-   决定业务预期。
-   取代知识库和 Graph。
-   直接执行 PG 或浏览器操作。

### 10.2 技术建议

优先考虑 Rust 实现 MCP Server / Workflow
Service，但不把具体存储引擎锁死：

-   单用户 PoC：可使用本地 SQLite。
-   多人或长期运行：评估 PostgreSQL。
-   状态变更采用追加式事件记录；当前状态可通过投影表快速读取。
-   配置文件版本化并纳入 Git。
-   MCP Server 与知识库服务解耦；知识库可以更换，只要符合 MCP Adapter
    契约。

不要在第一阶段建设复杂的通用 BPMN 引擎。先做有限状态机 + 配置化
DAG；真实流程复杂度证明有必要时再扩展。

### 10.3 状态模型

Task 总状态：

-   `NEW`
-   `READY`
-   `RUNNING`
-   `WAITING_APPROVAL`
-   `BLOCKED`
-   `FAILED`
-   `NEEDS_REPLAN`
-   `COMPLETED`
-   `CANCELLED`

Phase 状态：

-   `NOT_STARTED`
-   `READY`
-   `RUNNING`
-   `WAITING_APPROVAL`
-   `BLOCKED`
-   `FAILED`
-   `COMPLETED`
-   `SKIPPED_WITH_REASON`
-   `SUPERSEDED`

### 10.4 默认阶段

``` yaml
workflow:
  id: pg-ut-default
  version: 1
  phases:
    - id: intake
      required: true
    - id: change_proposal
      required: true
      approval_gate: change_approval
    - id: impact_analysis
      required: true
      approval_gate: impact_approval
    - id: test_perspective
      required: true
      approval_gate: perspective_review
    - id: test_plan
      required: true
      approval_gate: test_plan_review
    - id: test_data
      required: true
      blocking_policy: block_if_required_data_missing
    - id: tdd
      required: true
    - id: post_pg_perspective_review
      required: true
    - id: ui_test
      required: conditional
      condition: ui_scope_exists
      approval_gate: execution_approval_if_side_effect
    - id: final_review
      required: true
    - id: knowledge_submission
      required: conditional
      condition: reusable_knowledge_candidate_exists
      approval_gate: knowledge_review
```

这是默认配置，不是唯一流程。项目可通过 Profile 调整
`required`、`condition`、顺序和并行关系。安全底线和审批服务端校验不能被普通流程配置关闭。

### 10.5 状态迁移规则

  当前状态           允许迁移           触发条件
  ------------------ ------------------ ----------------------------
  NEW                READY              任务输入完整
  READY              RUNNING            Main 开始执行
  RUNNING            WAITING_APPROVAL   到达人工审批 Gate
  WAITING_APPROVAL   READY              人工批准
  WAITING_APPROVAL   NEEDS_REPLAN       人工要求修改
  RUNNING            BLOCKED            必要数据、知识或工具不可用
  BLOCKED            READY              阻塞原因已解除并重新验证
  RUNNING            FAILED             不可恢复错误
  FAILED             READY              经授权的重试/恢复
  RUNNING            COMPLETED          完成条件和证据通过
  任意非终态         CANCELLED          用户取消

Agent 只能提交
`proposed_transition`；服务端校验允许迁移。人工审批必须由可验证的人类交互产生，不能仅凭
Agent 在 JSON 中写入 `approved: true`。

### 10.6 Profile 配置项

``` yaml
profile:
  id: pg-ut-default
  version: 1

  execution:
    max_parallel_tasks: 2
    allow_nested_subagents: false
    default_timeout_seconds: 900
    retry_limit: 1
    retry_only_idempotent: true

  context:
    pass_full_chat_history: false
    pass_artifact_refs: true
    max_input_refs: 30
    require_compact_task_brief: true

  ui:
    execution_mode: natural_language
    inspector_policy:
      on_first_visit: true
      on_profile_drift: true
      on_locator_ambiguous: true
      on_locator_failure: true
      scan_entire_page_every_run: false

  test_perspective:
    generation_rounds: 2
    require_source_or_rationale: true
    require_human_review: true
    post_pg_review: true
    target_disposition_rate: 1.0
    target_plan_coverage: 1.0

  quality:
    require_expected_result_source: true
    block_unknown_high_risk: true
    allow_manual_waiver: true
    waiver_requires_reason: true
```

### 10.7 配置调整与回滚

-   每个 Task 记录 `workflow_profile_id` 和 `workflow_profile_version`。
-   已运行 Task 不自动套用新配置；需要显式升级或重开。
-   每次修改配置必须记录修改人、修改原因、影响范围。
-   保留上一个可用版本，允许回滚。
-   关键审批策略的变更需要人工审核。
-   配置调整不能追溯改变已完成任务的历史结果。

## 11. Task 输入输出契约

### 11.1 Task 输入

``` json
{
  "task_id": "TASK-2026-0001",
  "parent_task_id": null,
  "project_id": "PROJECT-A",
  "snapshot_id": "KB-SNAPSHOT-001",
  "code_revision": "GIT-COMMIT-001",
  "workflow_profile": {
    "id": "pg-ut-default",
    "version": 1
  },
  "agent_role": "test-plan",
  "goal": "Generate test perspectives and a traceable test plan",
  "scope": {
    "change_point_refs": ["CHANGE-001"],
    "screen_refs": ["SCREEN-001"],
    "business_flow_refs": ["FLOW-001"]
  },
  "input_artifact_refs": [
    "CHANGE-PROPOSAL-001",
    "IMPACT-REPORT-001"
  ],
  "required_skills": [
    "test-perspective",
    "test-plan-coverage"
  ],
  "allowed_actions": [
    "knowledge_read",
    "test_asset_write"
  ],
  "output_contract": "test-plan-result-v1",
  "budget": {
    "timeout_seconds": 900,
    "max_iterations": 5
  }
}
```

### 11.2 Task 输出

``` json
{
  "task_id": "TASK-2026-0001",
  "status": "completed",
  "artifact_refs": [
    "PERSPECTIVE-REGISTER-001",
    "TEST-PLAN-001",
    "COVERAGE-MATRIX-001"
  ],
  "evidence_refs": [
    "KB-QUERY-001",
    "GRAPH-QUERY-004"
  ],
  "open_questions": [
    "数量字段上限外一位的业务预期尚未确认"
  ],
  "proposed_changes": [],
  "proposed_next_action": "request_perspective_review",
  "used_skills": [
    "test-perspective",
    "test-plan-coverage"
  ],
  "actual_model": null,
  "metrics": {
    "elapsed_ms": null,
    "manual_correction_count": null
  }
}
```

输出状态：

-   `completed`：达到该 Task 的完成标准。
-   `blocked`：等待外部条件或人工补充。
-   `failed`：执行失败。
-   `needs_review`：已生成候选结果，等待人工审核。

Main
不传完整聊天历史；只传必要上下文、版本化资产引用、任务目标和输出契约。这样降低上下文消耗，也方便复用和重试。

## 12. MCP 接口设计

以下为应用层拟定契约，不是现成标准接口。具体方法名、参数和返回格式应在
MCP Server 实现前用 JSON Schema 固化。

### 12.1 Workflow MCP

  --------------------------------------------------------------------------------
  工具                      目的                    关键限制
  ------------------------- ----------------------- ------------------------------
  `create_task`             创建任务                幂等 Request ID

  `get_task`                获取任务状态            按项目/任务权限过滤

  `get_workflow_profile`    读取当前 Profile        只读

  `propose_transition`      Agent 提议状态迁移      服务端验证，不接受 Agent
                                                    自行批准

  `submit_human_approval`   记录人工确认            必须验证人类身份/交互授权

  `record_agent_result`     登记 Subagent 结果      记录
                                                    Agent、模型、Skill、Revision

  `get_task_history`        查询事件历史            不允许修改历史

  `create_recovery_task`    创建恢复任务            保留 parent_task_id 和失败原因
  --------------------------------------------------------------------------------

### 12.2 Knowledge MCP

  工具                          用途
  ----------------------------- ----------------------------------
  `get_screen_test_knowledge`   取得画面测试知识包
  `get_screen_checks`           取得画面已知 Check 和完整性状态
  `get_item_checks`             取得画面项目的 Check
  `get_event_checks`            取得事件关联 Check
  `get_check_detail`            取得规则、条件、触发、消息和证据
  `get_check_dependencies`      取得前置条件与依赖
  `get_check_coverage`          取得知识侧已知覆盖状态
  `get_check_diff`              比较 Snapshot 间 Check 增删改
  `get_related_checks`          取得关联规则

无结果必须返回 `UNKNOWN / NOT_INVESTIGATED / PARTIAL / CONFIRMED_NONE`
等状态，不能只返回空数组。

### 12.3 Test Perspective / Plan MCP

  工具                              用途
  --------------------------------- --------------------------
  `create_perspective_draft`        创建观点草案
  `get_perspective_register`        读取观点清单
  `update_perspective_draft`        保存人工修订草案
  `submit_perspective_review`       提交人工审核请求
  `get_perspective_review_status`   查询审核结果
  `save_test_plan`                  保存计划 Revision
  `get_test_plan_diff`              查看计划变更
  `validate_coverage_matrix`        校验观点与 Case 追踪关系

正式审核结果必须由人类审核流程写入，不允许 Agent
直接把自己的草案标记为已批准。

### 12.4 Test Data MCP

  工具                      用途                             限制
  ------------------------- -------------------------------- ------------------
  `get_db_metadata`         读取表、列、主键、索引等元数据   只读账号
  `query_candidates`        按限定条件寻找候选数据           限行、超时、脱敏
  `validate_test_data`      验证业务前置条件                 不隐式修改数据
  `reserve_test_data`       建立数据租约                     必须符合数据策略
  `release_test_data`       释放租约                         可重复调用
  `get_data_lease_status`   检查租约                         不暴露敏感值

禁止开放任意 DB 写入。若未来需要数据准备，使用独立的白名单 Recipe
和人工授权，不允许 Agent 自由拼接写入 SQL。

### 12.5 UI / Execution MCP

  工具                      用途
  ------------------------- -----------------------------
  `get_screen_profile`      取得知识库中的画面/元素结构
  `inspect_screen`          必要时局部读取运行时 DOM
  `get_table_structure`     读取指定 Table 的行列上下文
  `resolve_locator`         按元素知识和上下文解析目标
  `validate_locator`        验证匹配数量和证据
  `execute_approved_case`   执行已批准 Case
  `get_test_run`            获取运行状态
  `export_evidence`         导出截图、日志和报告

Playwright MCP 的具体工具名称依安装版本而定。MCP Adapter
屏蔽工具版本差异；不在 Skill 中硬编码未经 PoC 验证的工具名。

### 12.6 通用返回格式

``` json
{
  "status": "ok",
  "data": {},
  "evidence_refs": [],
  "warnings": [],
  "errors": [],
  "next_action": null,
  "revision": 1
}
```

建议统一错误码：

-   `INVALID_INPUT`
-   `VERSION_MISMATCH`
-   `REVISION_CONFLICT`
-   `APPROVAL_REQUIRED`
-   `KNOWLEDGE_GAP`
-   `PERSPECTIVE_UNRESOLVED`
-   `EXPECTED_RESULT_UNKNOWN`
-   `AMBIGUOUS_TARGET`
-   `DATA_NOT_FOUND`
-   `DATA_UNSAFE`
-   `SESSION_LOST`
-   `SIDE_EFFECT_UNKNOWN`
-   `BUDGET_EXCEEDED`
-   `FORBIDDEN`
-   `TOOL_UNAVAILABLE`

`SIDE_EFFECT_UNKNOWN` 不得自动重试；必须先确认实际业务状态。

## 13. 旧系统 UI 元素与 Playwright 设计

### 13.1 核心原则

-   画面元素仍然是必要知识。
-   不依赖 HTML Label。
-   不要求每次执行前全页扫描。
-   优先使用知识库已确认的画面结构和元素绑定。
-   首次访问、画面结构变化、Locator 歧义、定位失败时才触发 Inspector。
-   不能唯一确定目标时停止操作，不允许猜测点击。

### 13.2 元素知识模型

`ScreenProfile`：

-   screen_id
-   project_id
-   snapshot_id
-   route / URL pattern
-   menu_entry
-   frame / dialog 信息
-   form 信息
-   table 列结构
-   页面状态
-   profile_revision
-   last_verified_at
-   source_refs

`ElementProfile`：

-   element_id
-   screen_id
-   business_name
-   element_type
-   html_id
-   name
-   type
-   class / attributes
-   form_id / form_name
-   parent_context
-   table_id
-   column_key
-   row_key_strategy
-   event_binding
-   jsp_source_ref
-   javascript_source_ref
-   locator_candidates
-   locator_confidence
-   verification_status

### 13.3 无 Label 的 Locator 解析策略

按可用性组合使用：

1.  稳定 ID。
2.  稳定 Name + Form 上下文。
3.  Input 类型、属性和业务字段特征。
4.  父容器、相邻标题、DOM 层级等上下文。
5.  Table 的业务行键 + 列标识。
6.  JSP / JavaScript 中的字段名、事件处理关联。
7.  运行时 DOM 结构与实际匹配结果。

不要仅依赖 `nth()` 或绝对行号定位动态
Table。应优先用业务行键确定行，再结合列上下文确定单元格。

### 13.4 Locator 置信度与执行规则

  结果                         动作
  ---------------------------- ----------------------------------
  唯一匹配且证据充分           可以进入执行前校验
  多个匹配                     局部 Inspector / 补充上下文
  无匹配                       检查页面状态、版本漂移和知识缺口
  匹配唯一但业务身份不确定     人工确认，不直接操作
  Profile 与运行时结构不一致   标记 Profile Drift，生成更新候选
  关键目标不可定位             BLOCKED，不允许猜测操作

置信度阈值由 `ui-profile.yaml` 配置；PoC
中记录误定位和人工修订后再调整阈值。

### 13.5 Inspector 触发条件

默认：

-   第一次执行该画面 / 元素。
-   当前页面 Profile 不存在。
-   Snapshot 或代码版本变化导致 Profile 可能过期。
-   Locator 匹配数量不为 1。
-   页面结构与知识库不一致。
-   执行失败且疑似元素定位问题。

禁止默认每次完整扫描整个页面。Inspector
只采集当前测试所需的区域，输出脱敏结构和候选证据。

### 13.6 Playwright 自然语言与 Test DSL 的关系

自然语言是 AI 的工作接口，不代表测试目标可以不定义。

-   自然语言可以表达"从 Menu
    打开查询画面，查找符合条件的数据并进入编辑"。
-   Agent 必须把自然语言绑定到 Business Flow、Screen、Element、Data 和
    Assertion。
-   对稳定回归场景，可以保存为 DSL / Playwright Script。
-   未经确认的自然语言步骤只是草案，不是正式测试定义。

## 14. Test Data 与 TDD / UI Test 的边界

### 14.1 Test Data Agent

职责：

-   根据 Test Plan 的数据需求寻找候选。
-   优先使用既存数据。
-   读取 DB Metadata，构建只读候选查询。
-   验证业务键、状态、关联记录和 UI 前置条件。
-   记录数据可用性证据和租约。
-   找不到时返回明确阻塞，不编造数据。
-   释放租约或标记需要恢复。

不负责：

-   设计业务测试观点。
-   修改业务代码。
-   自动写 DB。
-   假设某个表中的记录一定可用。
-   为了测试随意修改正式业务数据。

### 14.2 TDD / UT

TDD 的目标是验证代码层面的实现行为：

``` mermaid
flowchart LR
    A["已确认观点 / 规则"] --> B["UT 写测试"]
    B --> C["RED：确认测试失败"]
    C --> D["PG 实现"]
    D --> E["GREEN：测试通过"]
    E --> F["REFACTOR"]
    F --> G["回归 + Coverage"]
```

UT 负责：

-   代码层断言。
-   单元边界和异常分支。
-   Mock / Stub / Fixture。
-   TDD 循环和代码 Coverage。

UT Fixture / Mock 与 UI 真实业务数据分离，不要把 UT 的模拟数据当成 UI
数据准备成功。

### 14.3 UI Test

UI Test 负责：

-   从 Menu 开始执行完整业务链。
-   使用真实测试环境数据。
-   验证跨画面、Session、业务状态和持久化结果。
-   检查消息、项目控制、画面迁移和 Table 操作。
-   保存截图、日志和必要的数据验证证据。

UT 通过不代表 UI 测试通过；UI 测试通过也不代表代码分支已充分覆盖。

## 15. 失败分类与恢复

  ---------------------------------------------------------------------------------------------
  失败类型          识别依据                     返回阶段          允许自动动作
  ----------------- ---------------------------- ----------------- ----------------------------
  规格缺失          预期无来源、Check 不完整     Test Perspective  只补充候选，不猜预期
                                                 / 人工确认        

  影响分析遗漏      新发现依赖或业务路径         Impact Analysis   扩展只读调查

  测试观点遗漏      新规则或边界未覆盖           Test Perspective  生成补充观点

  测试设计错误      Case 与观点不一致            Test Plan         修改草案，必要时重新审批

  数据不可用        前置状态不满足               Test Data         重新只读查找

  Locator Drift     元素结构变化                 UI Testing /      局部重新解析
                                                 Inspector         

  Playwright        浏览器状态、超时、交互错误   UI Testing        有界重试，仅限无副作用动作
  操作失败                                                         

  业务缺陷          实际结果与已确认预期不符     PG / UT           创建修复任务

  UT 失败           TDD 测试不通过               PG / UT           按 TDD 循环修复

  环境问题          服务不可用、登录异常         环境处理          不将环境失败算作测试通过

  副作用状态未知    超时发生在可能写入之后       BLOCKED /         禁止自动重复执行
                                                 人工确认          
  ---------------------------------------------------------------------------------------------

每次恢复都创建关联记录，保留原始失败和原始
Evidence。不得通过覆盖旧结果来伪装成功。

## 16. 版本、成果物与知识治理

### 16.1 版本绑定

每个 Test Run 至少绑定：

-   project_id
-   task_id
-   workflow_profile_version
-   agent_profile_version
-   skill_revision（如可追踪）
-   knowledge_snapshot_id
-   code_revision
-   perspective_register_revision
-   test_plan_revision
-   data_lease_id
-   screen_profile_revision
-   execution_environment

任何关键输入版本变化都要判断旧审批是否失效。

### 16.2 正式成果物

-   Change Proposal。
-   Impact Report。
-   Perspective Register。
-   Perspective Review History。
-   Test Plan。
-   Coverage Matrix。
-   Test Data Candidate Report。
-   TDD / UT Result。
-   UI Test Definition / DSL。
-   UI Run Result。
-   Evidence Package。
-   Final Review Report。
-   Knowledge Submission Candidate。

### 16.3 知识治理

-   正式知识、Check 和已审核画面操作知识保存在版本化知识库。
-   Test Plan、DSL、元素绑定等项目测试资产保存在 Git / 项目资产库。
-   运行记录、截图、日志和实际数据引用保存在独立 Task Asset Store。
-   未审核调查记录与正式知识隔离。
-   测试执行结束只生成 Knowledge Submission Candidate。
-   用户主动提交并经审核后，才允许更新 RAG / Graph / Snapshot。

## 17. 可调整性与实际效果反馈机制

### 17.1 调整对象

  对象               可调参数                         不建议的初期做法
  ------------------ -------------------------------- ----------------------------
  Agent              数量、职责、模型偏好、工具权限   一开始拆成十几个 Agent
  Skill              合并/拆分、执行步骤、输出模板    按每个工具动作拆一个 Skill
  Workflow           阶段顺序、并行、Gate、超时       写死唯一流程
  Test Perspective   观点目录、适用规则、风险权重     所有观点无条件生成
  UI                 Inspector 触发、Locator 权重     每次扫描全页
  Data               候选条件、限行、超时、验证规则   假设已有数据准备工具
  Model              模型偏好、Fallback、预算         固定某个模型 ID
  Quality            覆盖目标、阻塞阈值、例外审批     只显示一个 100% 数字

### 17.2 每次 PoC 必须收集的指标

**Agent / Skill 指标**

-   Main 是否正确委派。
-   预期 Skill 是否实际加载。
-   Subagent 输出是否符合 Schema。
-   人工修订次数。
-   重复调查次数。
-   Task 超时和重试次数。
-   上下文消耗、耗时和模型成本（可获取时）。

**测试观点指标**

-   AI 提出观点总数。
-   人工接受、编辑、拒绝、不适用数量。
-   人工新增观点数量。
-   PG 后新增观点数量。
-   有效观点遗漏率（由 Review 发现）。
-   观点到 Case 的映射完整性。
-   无预期来源的观点数量。
-   未确认高风险观点数量。

**UI 指标**

-   已知 Locator 的成功解析率。
-   多匹配/零匹配比例。
-   Inspector 触发次数。
-   Profile Drift 次数。
-   误定位次数（目标为 0）。
-   Playwright 操作成功率。
-   UI Case 可重复执行率。

**Data 指标**

-   候选数据发现率。
-   候选数据通过业务前置验证的比例。
-   数据阻塞原因分布。
-   租约冲突和释放失败数。

### 17.3 调整循环

``` text
PoC 执行
  ↓
采集实际数据与人工修订
  ↓
判断问题来自 Agent / Skill / Workflow / Knowledge / Tool / Model
  ↓
提出最小配置变更
  ↓
新 Profile Revision
  ↓
同一类任务再次验证
  ↓
对比效果
  ↓
保留或回滚
```

每轮尽量只调整一个主要因素，避免无法判断效果来自哪里。保留旧
Profile，支持回滚。不要仅因一次失败就增加一个新 Agent 或拆分一个 Skill。

## 18. PoC 实施计划

### 18.1 PoC 范围

只选一个真实业务：

-   从 Menu 开始。
-   包含多个画面迁移。
-   有真实业务数据前置条件。
-   至少一个输入或项目规则。
-   至少一个正常系和一个异常/边界系。
-   有可确认的预期结果。
-   能够取得必要的画面元素和 Check 资料。

不要在第一轮追求全系统覆盖。

### 18.2 PoC 阶段

  -----------------------------------------------------------------------------------------------------
  阶段                    实施内容                                         验收结果
  ----------------------- ------------------------------------------------ ----------------------------
  P0 环境确认             VS Code、Copilot harness、模型、MCP、Playwright  环境清单
                          版本                                             

  P1 Agent 骨架           Main + 五个 Subagent，确认 Task 委派             只有 Main
                                                                           作为用户入口；委派真实发生

  P2 Skill 骨架           先做                                             能实际加载并按步骤工作
                          workflow、test-perspective、test-plan-coverage   

  P3 观点生成             输入真实设计差分、Check、影响结果                产生可审查观点清单和来源

  P4 Coverage Plan        观点 → 条件 → Case → Coverage Matrix             适用观点均有 Case 或明确阻塞

  P5 数据调查             只读查询候选并做业务前置验证                     得到真实候选或明确阻塞

  P6 UI 元素绑定          读取已知元素；必要时局部 Inspector               无 Label 的目标也能可靠定位

  P7 Playwright 执行      自然语言操作完整 Business Flow                   结果和 Evidence 可追踪

  P8 TDD                  UT Red、PG Green、Refactor                       测试结果和代码 Coverage
                                                                           分开呈现

  P9 复核                 PG 后观点补充、失败分类、Profile 调整            形成下一版调整清单
  -----------------------------------------------------------------------------------------------------

### 18.3 PoC 验收标准

  ------------------------------------------------------------------------------------------------
  验收 ID                 验收内容                通过条件
  ----------------------- ----------------------- ------------------------------------------------
  POC-01                  Agent 委派              Main 实际调用对应 Subagent，返回结果符合契约

  POC-02                  Skill 使用              指定 Skill 在新会话中可发现、加载并按预期执行

  POC-03                  测试观点提出            AI 不只复制 Check，还能提出有理由的新增观点

  POC-04                  观点审核                人可以编辑、接受、拒绝、不适用、待确认

  POC-05                  Coverage                观点、Case、执行和通过率分别统计，分母可审查

  POC-06                  预期管理                无来源预期不会被当成已确认结果

  POC-07                  数据调查                使用真实 DB 只读候选；不能假设数据可用

  POC-08                  无 Label 定位           通过 ID/Name/Form/属性/DOM/Table
                                                  上下文定位；歧义时阻止

  POC-09                  Inspector 策略          正常重复执行不做全页扫描；漂移或失败时按需调查

  POC-10                  Business Flow           从 Menu 开始验证完整业务链

  POC-11                  TDD                     体现 Red → Green → Refactor，且不与 UI Test
                                                  混为一谈

  POC-12                  知识治理                未审核调查和运行结果不更新正式 RAG / Graph

  POC-13                  可调整性                修改 Profile 后可复测、比较、回滚

  POC-14                  证据                    每个 Case 可追踪定义版本、执行结果和 Evidence
  ------------------------------------------------------------------------------------------------

### 18.4 PoC 不通过时的调整原则

-   Agent 不委派：先修 Main 的 Task Brief 和 Agent
    Description，不立即增加 Agent。
-   Skill 未加载：先修 Skill Description、目录和 Harness 配置。
-   观点遗漏：先修观点目录和生成/挑战步骤；必要时再引入独立 Review
    Task。
-   Case 不完整：修 Test Plan Skill 和映射规则。
-   Locator 不稳定：补充元素知识或局部 Inspector，不做全页扫描。
-   数据找不到：补充数据知识和查询条件，不假定需要新建数据准备系统。
-   上下文过大：减少传递聊天历史，改传 Artifact Reference
    和摘要；再评估拆分 Task。
-   模型结果不稳定：比较模型偏好和输出质量，不直接提高所有 Agent
    的模型等级。

## 19. 开发顺序与首批交付物

### 19.1 第一批：可运行骨架

1.  `.github/agents/pg-ut-main.agent.md`
2.  `.github/agents/impact-analysis.agent.md`
3.  `.github/agents/test-plan.agent.md`
4.  `.github/agents/test-data.agent.md`
5.  `.github/agents/pg.agent.md`
6.  `.github/agents/ut.agent.md`
7.  `.github/skills/pg-ut-workflow/SKILL.md`
8.  `.github/skills/test-perspective/SKILL.md`
9.  `.github/skills/test-plan-coverage/SKILL.md`
10. `agent-profile.yaml`
11. `workflow-profile.yaml`
12. `perspective-catalog.yaml`

第一轮先实现上述核心文件，不要求一次性写完所有 10 个 Skill。

### 19.2 第二批：Workflow 和契约

-   Rust Workflow MCP Server 骨架。
-   Task / Approval / Event 数据结构。
-   JSON Schema。
-   Knowledge MCP Adapter。
-   Test Perspective / Plan MCP。
-   Task Asset Store。
-   最小状态机和事件日志。

### 19.3 第三批：真实业务 PoC

-   选定一个 Business Flow。
-   导入该业务所需的设计差分和 Check。
-   生成观点并人工审核。
-   生成 Coverage Matrix 和 Case。
-   只读找数据。
-   验证元素绑定。
-   使用 Playwright MCP 执行。
-   执行 TDD。
-   复盘并调整配置。

## 20. 主要风险与应对

  ----------------------------------------------------------------------------------------
  风险                     影响                    应对
  ------------------------ ----------------------- ---------------------------------------
  AI 只复制已有 Check      遗漏新观点              独立观点生成 Skill + 通用观点目录 +
                                                   第二轮挑战

  AI 生成大量无关观点      审核成本高              适用性理由、风险分级、按 Change Point
                                                   生成

  预期结果无依据           假通过/假失败           预期来源必填或人工确认

  知识库不完整             观点漏项                来源完整性、未知项、代码/测试补充调查

  Agent 过多               成本和管理复杂          五个固定角色基线，按指标再拆分

  Skill 过多               加载和维护复杂          按工作能力组织，先合并后拆分

  Workflow 过度固定        实际流程难适配          Profile 配置化、版本化、可回滚

  直接暴露高权限工具       审批可绕过              最小工具权限、服务端授权、执行网关

  旧系统元素不规范         Locator 不稳定          多属性、Form、Table、DOM 上下文

  测试数据不满足前置条件   UI 无法执行             只读候选验证、租约、明确 BLOCKED

  UT 代替 UI Test          业务流程未验证          独立覆盖模型和结果报告

  代码差分反向改变规格     业务预期被实现污染      PG 后只提出新增观点候选，不自动修改预期
  ----------------------------------------------------------------------------------------

## 21. 尚待 PoC 确认的事项

以下不应在没有实测的情况下提前锁定：

1.  目标 VS Code 版本、Copilot Harness 和企业策略。
2.  实际可用模型及 Subagent 模型配置行为。
3.  Playwright MCP 的实际版本、工具名、浏览器会话复用方式。
4.  一个真实 Business Flow 的入口、画面和数据条件。
5.  该业务的正式 Check 数量和完整性。
6.  现有 DB 的只读权限、主键和业务键可用性。
7.  是否需要单独的 Test DSL Runner，还是自然语言 Playwright MCP
    已满足第一轮需求。
8.  UI 测试执行时哪些业务动作会产生不可逆副作用。
9.  本地 UI 工作台是否在第一轮就必要；先用结构化 Markdown/JSON
    审核也可作为基线。
10. 是否需要独立 Perspective Reviewer Subagent；先用同一个 Test Plan
    Agent 的第二轮挑战，依据漏项率再决定。

## 22. 最终设计结论

本系统的关键不在于创建多少
Agent，而在于建立可验证、可调整、可追踪的执行体系：

-   Main Agent 管理流程和用户确认。
-   Subagent 负责边界明确的专业任务。
-   Skill 固化可复用的专业工作方法。
-   Test Perspective Skill 主动提出测试观点，填补"只从已有 Check 生成
    Case"的缺陷。
-   Test Plan Skill 将已审核观点转化为 Case 和 Coverage Matrix。
-   TDD/UT 负责代码层验证。
-   UI Test 负责完整业务流程验证。
-   MCP 提供知识、数据、浏览器和状态工具。
-   Workflow State Manager 控制阶段、版本和审批。
-   Profile 使 Agent、Skill、Workflow、模型和 Quality Gate 能根据 PoC
    效果调整。
-   正式知识必须主动提交并审核后才能入库。

**第一阶段的成功标准不是做出一个庞大的 Agent 平台，而是用一个真实
Business Flow 证明：AI
能提出有价值的测试观点，人员能有效审核，观点能完整映射为测试计划，数据能找到，画面能可靠操作，执行结果能追溯，并且可以根据实际结果调整配置。**

------------------------------------------------------------------------

## 附录 A：测试观点示例

假设需求变化为：数量输入范围从 `1～99` 扩大为 `1～999`。

  ----------------------------------------------------------------------------------------------------
  观点 ID        测试观点         条件                           测试层级       预期来源
  -------------- ---------------- ------------------------------ -------------- ----------------------
  TP-001         下限边界         0、1                           UT/UI          详细设计或人工确认

  TP-002         上限边界         999、1000                      UT/UI          详细设计或人工确认

  TP-003         空值处理         null、空字符串、空白           UT/UI          Check / 详细设计

  TP-004         输入格式         小数、字母、全角数字           UT/UI          输入规则；未知则确认

  TP-005         错误消息         非法输入时的消息和焦点         UI             Check / 画面知识

  TP-006         保存结果         999 是否正确保存               UI/DB          DB 规则 / 业务确认

  TP-007         确认画面         编辑值是否正确传递到确认画面   UI             画面迁移 / 业务流程

  TP-008         重复提交         连续点击确认或刷新重发         UI/UT          业务副作用和幂等规则

  TP-009         下游业务         使用该数量的后续业务是否正常   UI/回归        Graph / 影响分析

  TP-010         未变更规则回归   其他字段校验是否保持           UT/UI          既存 Check / 测试资产
  ----------------------------------------------------------------------------------------------------

如果资料只确认 `1～999`，但没有说明 1000 的具体消息，则 TP-002
的测试观点可以提出，但其预期结果必须标记为 `NEEDS_SPEC_CONFIRMATION`。

## 附录 B：建议的配置文件

``` text
config/
  agent-profile.yaml
  workflow-profile.yaml
  quality-profile.yaml
  perspective-catalog.yaml
  ui-profile.yaml
  data-policy.yaml

schemas/
  task-input.schema.json
  task-result.schema.json
  perspective.schema.json
  test-plan.schema.json
  coverage-matrix.schema.json
  evidence.schema.json
```

## 附录 C：官方实现参考

-   VS Code Agent
    Skills：<https://code.visualstudio.com/docs/agent-customization/agent-skills>
-   VS Code Custom
    Agents：<https://code.visualstudio.com/docs/agent-customization/custom-agents>
-   VS Code
    Subagents：<https://code.visualstudio.com/docs/agents/run/subagents>

实现时以目标环境当前版本为准，特别是 Copilot
harness、模型字段、工具名称、Subagent 委派和 Skill 加载行为。
