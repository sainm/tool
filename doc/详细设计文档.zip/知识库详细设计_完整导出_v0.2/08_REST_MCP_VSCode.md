# 08 Knowledge Service REST、MCP Server 与 VS Code 交付接口

## 8.1 统一服务

REST 前缀 `/api/v1`；HTTPS、JSON、UUID、带时区时间、Cursor 分页、Idempotency-Key、请求审计。每个读取操作最终固定 Snapshot；写入操作携带预期 HEAD。通过服务端授权，不允许浏览器/VS Code 直连数据库。

## 8.2 REST 分组

| 模块 | 典型路径 |
|---|---|
| Version | `GET/POST /versions`、`GET /versions/{id}/branches`、`GET /versions/{id}/releases` |
| Snapshot | `POST /snapshots/resolve` |
| Source/Import | `/sources`、`POST /imports`、`GET /imports/{id}`、`POST /imports/{id}/retry` |
| Review | `/reviews/batches`、`POST /reviews/items/{id}/decisions`、`POST /reviews/batches/{id}/publish` |
| Knowledge | `POST /knowledge/search`、`GET /knowledge/artifacts/{id}/sheets`、`GET /knowledge/entries/{id}` |
| Graph | `POST /graph/related`、`POST /graph/traverse`、`GET /graph/relations/{id}` |
| Design Diff | `/design-diff/versions`、`/scopes`、`/packages/resolve`、`/packages/{id}/items`、`/export` |
| Operations | `POST /operations`（RELEASE/CLOSE/REOPEN/ROLLBACK） |
| Quality | `/quality` 核验与报告 |

创建后续大版本示例：

```json
{
 "version_name":"3Q下期",
 "previous_major_version_id":"<UUID>",
 "base":{"source_type":"RELEASE","release_id":"<UUID>"}
}
```

若 `source_type=CURRENT`，不填 release_id；服务端创建时固定对应 READY Snapshot，并初始化 Current、Preview。

## 8.3 VS Code 插件（严格限定）

仅 `Detailed Design Diff`：选择大版本文字名、Function/Screen；查询同大版本 Current→Preview 的 READY Package，查看 Before/After 与证据，按需导出 JSON/Markdown，把差分包引用交给单一 PG/UT Agent。插件**无 Knowledge Search / Current File Context / Graph Explorer**。

查找 Package 与生成/审核 Package 分离：插件只读，未找到 READY 时不能将候选直接交付。已验证空差分包与 `NOT_FOUND` 有不同含义。

## 8.4 PG/UT Agent handoff

```json
{
 "handoff_version":"1.0",
 "task_type":"PG_UT",
 "diff_package_id":"<UUID>",
 "major_version_name":"3Q下期",
 "current_snapshot_id":"<UUID>",
 "preview_snapshot_id":"<UUID>"
}
```

通过 `AgentHandoffAdapter` 对接实际 PG/UT Agent（扩展 API / 命令 / 可复制的 Package 引用），不假定 VS Code 可注入任意 Agent。Agent 只在授权范围内通过 MCP 获取差分；其程序修改/UT 执行逻辑不属于知识库平台。

## 8.5 MCP 权限

必须：`get_detailed_design_diff(package_id)`、`get_diff_detail(package_id, diff_item_id)`、`list_diff_items`。服务器可以另外实现 `search_knowledge`、`resolve_knowledge_snapshot`、`get_related_objects` 等**单独授权**工具；不因此扩大 VS Code 插件功能，也不默认向 PG/UT Agent 开放所有读取能力。

## 8.6 错误与并发

`INVALID_REQUEST 400`、`UNAUTHENTICATED 401`、`PERMISSION_DENIED 403`、`NOT_FOUND 404`、`SNAPSHOT_CONFLICT 409`、`INVALID_STATE 409`、`REVIEW_INCOMPLETE 422`、`DEPENDENCY_INCOMPLETE 422`、`KNOWLEDGE_NOT_READY 503`。公开错误避免泄漏未授权对象存在性。重复创建/发布请求使用幂等键返回同一操作记录。

完整 OpenAPI 3.x、字段级校验、OAuth/OIDC、分页 Cursor 格式、Agent 真实 SDK 对接仍待实现。
