# 04 PostgreSQL Graph 权威记录与 Neo4j 版本化投影

## 4.1 节点范围

只使用五类节点：`Document`、`SourceFile`、`Function`、`Screen`、`UIElement`。业务重要关系如 `HAS_SCREEN`、`DESCRIBED_BY`、`IMPLEMENTED_BY`、`HAS_ELEMENT`、`REFERENCES`、`RELATED_TO`，需正式定义允许的端点类型组合。

不构建完整方法/变量/动态运行图；重要 UIElement 属性（必填、长度、输入限制、条件）主要在 PostgreSQL 内容中。`KnowledgeEntry` **不进入 Neo4j**。Document/SourceFile 的 Graph 身份须与 Artifact 身份一致映射。

## 4.2 PostgreSQL 表

- `graph_object(object_id, object_type, created_at)`：稳定逻辑身份。
- `graph_object_version(object_version_id, object_id, display_name, properties JSONB, created_at)`：历史名称和少量显示属性。
- `graph_relation(relation_id, source_object_id, target_object_id, relation_type, created_at)`：稳定关系身份。
- `graph_relation_version(relation_version_id, relation_id, review_status, properties JSONB, created_by, created_at)`：候选、确认、待复核、驳回。
- `relation_evidence` / Evidence 权威表：来源 ArtifactVersion/Sheet/单元格或代码行、抽取方式、审核证据与关系版本映射（DDL 待补）。

关系在某 Snapshot 下是否有效由 `commit_change` 及有效版本索引确定，不能简单使用 Graph 关系的最新状态。

## 4.3 Neo4j 投影

Neo4j 存逻辑节点及其版本关系的**不可变投影**，查询时由 Knowledge Service 固定 Snapshot。可对关系使用明确类型 Cypher 模板，禁止从用户输入拼接任意 Cypher。候选关系不能混入已确认查询结果。

## 4.4 Snapshot 历史隔离

- 当前 S300 有 `Document C → SourceFile D`；Preview S315 将该关系失效并新增 `C → E`；S300 仍可查 C→D，S315 只查 C→E。
- 第一版可用 PostgreSQL 解析有效关系版本集合 + Neo4j 局部查询；**不能**对全库结果事后过滤。
- 多跳遍历中每个中间节点和边都要符合目标 Snapshot；大范围遍历需有效性物化索引或专门投影，不应向 Neo4j 传入巨量 ID 列表。
- 历史节点显示名称也要按 Snapshot 解析，不能直接采用最新属性。
- Graph 删除为版本视图的 tombstone，不物理删除仍被历史 Snapshot 引用的关系。

## 4.5 Graph API

`get_related_objects(snapshot_id, object_id, relation_types)`、`traverse_relations(snapshot_id, start_object_id, max_depth, limit)`、`get_relation_detail(relation_id)`。Graph 缺边只能说明当前已确认知识不足，不能得出零影响结论。

## 4.6 PoC 验收

继承、Preview 新增/删除、候选审核、历史节点更名、多跳版本过滤、Neo4j 重建与发布失败时 HEAD 不变。多跳性能需真数据验证，不提前要求复制整图。
