# 02 统一对象模型与 PostgreSQL 表结构设计

## 2.1 Schema 划分

单一 PostgreSQL 数据库：`kb_core`（原始文件身份和业务对象）、`kb_version`（大版本/Commit/Branch/Snapshot）、`kb_content`（Sheet/Chunk/Embedding/人工知识）、`kb_graph`（Graph 权威与证据）、`kb_ingest`（导入/审核）、`kb_diff`（设计书差分）、`kb_admin`（操作/审计）。通用 Job 表可以归入 `kb_admin` 或独立 `kb_job`，PoC 以一致命名为先。

## 2.2 Artifact 与 ArtifactVersion

- `artifact`: `artifact_id UUID PK`、`artifact_type`（DOCUMENT/JAVA/JSP/JS/PROPERTIES...）、`repository_id`、`logical_path`、`display_name`、创建时间。Artifact 是原始文件的稳定身份；Function、Screen、KnowledgeEntry 不强制成为 Artifact。
- `artifact_version`: `artifact_version_id UUID PK`、`artifact_id FK`、`content_hash SHA256`、`source_revision`、`source_path`、`blob_key`、`file_size`、创建时间。不可变，引用 Azure Blob 文件内容。
- `source_revision` 与 `repository_id/source_id` 搭配使用，不能把来自不同仓库的 revision 视为同一个全局 ID。
- 文件重命名要有身份识别/审核规则；不能仅因路径变化无条件生成新 Artifact，也不能无依据把两个文件合并为同一 Artifact。

## 2.3 Excel Sheet JSONB

- `excel_sheet_version(sheet_version_id PK, content_hash, parser_version, content_jsonb JSONB, created_at)`；规范化内容 Hash 与解析器版本决定复用。
- `artifact_sheet_map(artifact_version_id FK, sheet_order, sheet_name, sheet_version_id FK)`；每个文件版本可以复用旧 SheetVersion。
- 原始 `.xlsx` 始终保留 Blob；JSONB 面向结构检索、差分和出处定位，**不保证还原 Excel 外观**。
- 示例：Current 文件 DV10 含 S001/S002/S003，Preview DV11 只更新第二 Sheet 到 S005，其余 Sheet 指向原版本。
- Sheet 解析应保留单元格坐标、合并区域、表头、区块/表格关系、原文及特殊业务格式；过大 Sheet 是否进一步分块待性能验证。

## 2.4 Chunk 与来源位置

- `knowledge_chunk(chunk_id, content, content_hash, chunk_type, chunker_version, created_at)`：完整上下文化内容去重；不在本表固定 `major_version/branch`。
- `chunk_source(chunk_source_id, chunk_id FK, artifact_version_id FK, sheet_order, cell_range, source_locator JSONB)`：定位 Excel Sheet/单元格或 Word 章节、Java/JSP 行范围。
- Excel 插入行但内容不变，可以复用 Chunk/Embedding，新增不同的 ChunkSource；**不能因文本相同而省略新版位置**。
- `chunk_embedding(chunk_id, model_id, embedding, created_at)`：向量按模型版本管理。示例 `vector(1536)` **仅供说明**；模型实际维度/索引方案待 PoC 定型。
- Chunk Hash 需包含业务检索上下文；相同短句在不同业务中并不必然表示同一可复用内容。

## 2.5 KnowledgeEntry

- `knowledge_entry(knowledge_id UUID PK, created_by, created_at)`；
- `knowledge_entry_version(knowledge_version_id UUID PK, knowledge_id FK, title, content, knowledge_type, scope_metadata JSONB, created_by, created_at)`。
- 可选 Function/Screen 范围元数据仅作检索过滤，不建立 Neo4j 关系；可独立 embedding，按 Snapshot 解析有效版本。
- 人工知识包括不足以从文档推导的业务经验、UT 前置条件等；普通文档中的每条描述不必升格为 KnowledgeEntry。

## 2.6 版本关联方式

Content 表不直接存 `branch='PREVIEW'`。Snapshot → 有效 ArtifactVersion / KnowledgeEntryVersion / GraphRelationVersion → Sheet/Chunk/Embedding。跨版本共享不可变内容。历史 Release 不能因新模型替换或物理清理而不受控地改变检索结果。

## 2.7 数据约束待补

- `artifact.repository_id` 的正式外键依赖 Source 表定型。
- 统一多态 `object_version_id` 注册/校验方式待定。
- Blob Hash 及文件版本去重的安全性、唯一性、Hash 碰撞策略待定。
- 需定义外部来源权限、文件级唯一范围、Chunk 规范化规则、向量模型升级策略。
