# 12 DDL 统一清单、已知冲突与开发前事项

## 12.1 草案核心表目录

| Schema | 表 |
|---|---|
| kb_core | artifact、artifact_version、Function/Screen/UIElement 等业务身份表（完整 DDL 待定） |
| kb_version | major_version、knowledge_commit、commit_change、knowledge_snapshot、knowledge_branch、release_record |
| kb_content | excel_sheet_version、artifact_sheet_map、knowledge_chunk、chunk_source、chunk_embedding、knowledge_entry、knowledge_entry_version |
| kb_graph | graph_object、graph_object_version、graph_relation、graph_relation_version、evidence / relation_evidence（待定） |
| kb_ingest | data_source、source_cursor、import_job、import_file、staging_change、review_batch、review_item、review_decision、publish_batch、publish_item |
| kb_diff | design_diff_job、design_diff_scope、design_diff_item、design_diff_item_scope、design_diff_review、diff_package、diff_package_item |
| kb_admin | operation、approval、audit_log、job_execution、job_step、job_error、snapshot_validation、outbox_event 等（具体归属待定） |

## 12.2 必须修正的历史草案点

1. **大版本不使用 `version_code=V3`** 作为业务编号；改为文字名称与显式前置版本关系。名称在可跨年度复用时需业务周期联合唯一。
2. `major_version.base_snapshot_id` 只记录固定基线不够，还应保存来源大版本、CURRENT/RELEASE、被选 ReleaseRecord。
3. `knowledge_branch.head_snapshot_id` 允许引用从前一大版本继承来的 Snapshot；不能只允许本大版本 Commit。
4. `design_diff_job` 的 `current_snapshot_id <> preview_snapshot_id` CHECK **必须取消**；空差分合法。
5. `knowledge_snapshot` 的 `READY` 与发布批次 `PUBLISHED` 是不同状态，不要把 Snapshot 改为全局 PUBLISHED。
6. `graph_object_version` 和 `graph_relation_version` 如何通过统一 CommitChange 解析、怎样保证外键，需要对象版本注册或类型安全的关联机制。
7. `knowledge_chunk` 与 `chunk_source` 分开；同内容不同单元格位置不能丢失出处。
8. `source_cursor` 扫描游标与安全发布游标分开；部分批准时不得跳过未处理文件。
9. `diff_package` 必须固定 Snapshot、所选 Scope 集合、审核结果/格式版本与内容 Hash；READY 后不可变。
10. 审核 item 与 staging_change 必须属于同一 import_job；跨表约束需数据库事务/触发器落实。
11. 外部 `source_revision` 不能混作 Knowledge Commit；文件身份/仓库/路径唯一规则待定。
12. 历史 Neo4j 属性/多跳遍历必须固定 Snapshot；不能全图遍历后只过滤终点。

## 12.3 还未完成的可开发规格

- 一套可执行的 Flyway Migration（真实 FK、CHECK、索引、约束、回滚策略）。
- Snapshot 有效版本映射、Commit 长链检查点、版本授权 SQL。
- Neo4j 完整 Constraints/Indexes、投影规则与多跳 Cypher PoC。
- OpenAPI 3.x 完整 schema、错误码、Cursor 和认证。
- Excel 原始与规范化规则、Sheet/Block/Item 稳定匹配算法及真实标注数据。
- 真实 AgentHandoffAdapter 与 VS Code 目标 Agent 的可编程接口验证。
- 自动化测试、私有部署配置、备份恢复演练、性能基线。

## 12.4 开发起点建议

先实现一组可运行 Migration + Snapshot 继承/切换 API + 文件/S​​heet 导入 PoC，使用 `3Q上期` Release → `3Q下期`，验证不复制旧知识；再增加审核发布和基础 RAG/Graph，最后进入 MVP2 Diff Package/Agent。
