# 11 集成验证、开发验收与 MVP 路线

## 11.1 端到端测试链

`3Q上期` Current/Release → 创建 `3Q下期` → 固定 Git/SVN Revision → Blob/Sheet/Chunk/Embedding/Graph 候选 → 自动验证 → 人工审核 → Preview READY Snapshot → CAS 发布 → Current/Preview RAG/Graph 版本查询 → Excel 差分审核 → READY Diff Package → VS Code → 单一 PG/UT Agent → Release/Close 历史查询。

## 11.2 重点测试用例

| 编号 | 场景 | 预期 |
|---|---|---|
| V01 | 从前一大版本 Current 继承 | Current/Preview 初始同基线，不复制全套内容 |
| V02 | 从历史 Release 继承 | 指定历史快照固定，不随来源 Current 变化 |
| V03 | 来源大版本 Close | 后续大版本独立可用 |
| V04 | 大版本业务文字名 | `3Q上期/3Q下期`，不用名称字典序确定继承 |
| I01 | Excel 只修改一个 Sheet | 其余 Sheet/Chunk/向量尽可能复用，定位正确 |
| I02 | 未审核导入 | Preview 不改变 |
| I03 | 部分批准 | 独立且依赖完整的变更组可发布 |
| I04 | Graph 投影失败 | HEAD 不切换 |
| I05 | 并发发布 | CAS 检测并发，重建/复核 |
| I06 | 部分发布后游标前移 | 未解决文件不丢失 |
| R01 | Current/Preview RAG/Graph | 不跨 Snapshot 混用 |
| R02 | 历史 Release Graph 多跳 | 中间节点/边按历史有效性过滤 |
| D01 | Excel 插空行 | 不生成业务差分 |
| D02 | 删除整个区块 | 必须检测 |
| D03 | 字段必填/长度/DB 条件变化 | Before/After、原始位置完整 |
| D04 | Current=Preview | 允许验证空差分 |
| D05 | Package 后 Preview 更新 | 旧包不变 |
| A01 | Agent 读取 READY 包 | 按固定包 ID 分页、授权且可重复 |
| O01 | Release/Close/Rollback | 历史不破坏、权限与前置条件检查 |
| O02 | 发布事务成功但响应丢失 | 重试不重复 Commit |

## 11.3 MVP1 范围（已讨论确认的建议）

**MVP1：版本继承 + 增量入库 + 人工审核 + Snapshot 隔离 + 基础 RAG/Graph。**

- 基础：Docker Compose、PostgreSQL/pgvector、Neo4j、Flyway Migration、Spring Boot 服务。
- 版本：文字大版本创建；从前一大版本 Current 或 Release 继承；Current/Preview/Release 历史查询。
- 内容：Excel Sheet JSONB、Java/JSP 文件、Chunk/Embedding 基础检索、五类 Graph 节点和必要已确认关系。
- 导入：固定来源 Revision、增量、Staging、人工审核、Snapshot 发布及幂等重试。
- 最小 Web：Version、Import、Review、Knowledge Explorer。
- 验收：未审不可见、无历史污染、Sheet 去重、重复导入幂等、服务重启数据正确。

## 11.4 MVP2 范围

**MVP2：详细设计书语义差分 + 差分审核 + Diff Package + VS Code / 单一 PG/UT Agent 集成。** 包括复杂 Excel File/Sheet/Block/Item 匹配、分类与证据、按 Function/Screen 范围、Package REST/MCP、授权与 Agent handoff。

## 11.5 PoC 建议技术与非目标

建议 Java 21 + Spring Boot、PostgreSQL+pgvector、Neo4j、Apache POI、Flyway、React+TypeScript、Docker Compose，Azure Blob 可由适配器接入私有存储。具体选型待现有运行环境和版本兼容性验证。

第一版不做全系统全量静态依赖图、复杂分支合并、跨站多租户权限体系、完整 IT/ST 自动步骤生成，也不将 PG/UT Agent 内部改码/UT 成功率作为知识库核心功能验收。

## 11.6 性能与质量指标

先采集实际文件数量、Sheet 大小、Chunk/向量/关系数量、版本链长度、导入耗时、复用率、Graph 一跳/多跳 P95、RAG Recall@K、Excel 差分关键漏检率，再决定阈值与检查点规模；不虚构性能或准确率承诺。
