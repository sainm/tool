# 05 RAG 建构、检索与版本限定

## 5.1 处理链

源文件固定 Revision → Blob 快照 → 解析 → 标准结构 → Excel Sheet JSONB → 逻辑 Chunk → Embedding → 检索索引 → 自动验证 → 人工审核 → Preview Snapshot 可见。

## 5.2 解析策略

- Excel 按 Sheet/表格/处理区块解析，保留表头、合并单元格、项目名、条件、原文、单元格范围；不要将每个单元格变为独立 Graph 节点。
- Word/PDF/文本按章节/表格语义切块；Java/JSP/JS 文件级知识对象，内容 Chunk 可按合理代码片段，但不必构建方法级图。
- 文档不一致和缺失时保留来源及信心标识；人工补充知识独立进入 KnowledgeEntry。

## 5.3 Chunk / Embedding

- Chunk 必须包含检索时足以解释的业务上下文（例如 Function、Sheet 名、字段、校验规则）；Hash 覆盖规范化内容及 Chunker 版本。
- Embedding 按模型标识/版本复用；模型升级需有检索配置迁移策略。
- 新旧 Excel 只移动行时，新 `chunk_source` 指向新位置，Chunk 向量可复用。

## 5.4 检索

查询首先解析固定 Snapshot，构建该 Snapshot 下有效的文档版本、ChunkSource、KnowledgeEntryVersion 集合，再执行关键词+向量混合检索、必要的 Graph 关联补充。

**严禁**先对全部历史 Chunk 取 Top-K 再简单丢掉其他版本：可能使本版本命中永久缺席。初期可使用有效版本物化映射、候选过滤、分阶段召回与重排；方案需在真实数量级验证。

输出包含 Snapshot、来源 ArtifactVersion、Sheet/范围、证据与是否属于人工 KnowledgeEntry。缺少来源/权限不符合条件的记录不应进入返回集合。

## 5.5 质量指标

人工问答标注样本的 Recall@K、版本正确率、来源定位准确率、无答案时误答率、重复/矛盾证据处理。PoC 测基线后设上线门限；不预设虚构达标数值。
