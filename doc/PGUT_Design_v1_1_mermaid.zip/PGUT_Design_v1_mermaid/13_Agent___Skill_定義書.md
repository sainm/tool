# 13　Agent / Skill 定義書

> 文書ID：PGUT-D13　｜　版：1.1 図表形式改訂案　｜　作成日：2026-11-24  
> 基準資料：PG/UT Agent UI Test Design v0.3（第13, 16章）  
> 状態：詳細設計案・未実装／実システム未検証。業務名、ID、画面、数値、API は明示のない限り提案例。

[設計書一覧](README.md)

## 1. 最終構成
利用者向け Custom Agent は PG/UT Main の1個のみ。専門ロールを5個の非表示 Custom Agent として定義し、Main が直接委譲する。UI Test は Main の工程と Skill で実施し、必要時に一時 Subagent を起動する。入れ子委譲を必須としない。Copilot harness と Local harness の設定を混同しない。

*図 13-01　単一入口と内部委譲（設計図）*

```mermaid
flowchart TD
  n0["利用者"]
  n1["PG/UT Main（表示）"]
  n2["影響分析（非表示）"]
  n3["PG（非表示）"]
  n4["UT（非表示）"]
  n5["Test Plan（非表示）"]
  n6["Test Data（非表示）"]
  n7["一時Subagent"]
  n8["UI工程Skill"]
  n9["仕様・Check Skill"]
  n10["データ調査Skill"]
  n0 --> n1
  n1 --> n2
  n1 --> n3
  n1 --> n4
  n1 --> n5
  n1 --> n6
  n1 --> n7
  n1 --> n8
  n5 --> n9
  n6 --> n10
```

## 2. 設定例
```yaml
---
name: test-data
description: 指定Caseのデータ条件調査と既存候補検証を行う内部専門ロール
user-invocable: false
disable-model-invocation: false
---
```
上記は frontmatter の例であり完成した Agent ファイルではない。user-invocable と disable-model-invocation は可視性とモデル委譲可否を別々に制御する。実際の Copilot harness の task ツール、利用可能モデル名、工具権限を検証してから固定する。Main の表示を有効にし、プロジェクトの他カスタム定義や組織提供 Agent まで消えるとは仮定しない。

## 3. ロール契約
|ロール|指示の中核|利用ツール・禁止|
|---|---|---|
|Main|工程状態、G1/G2/G3、委譲、成果物統合|承認代理禁止、書込ゲート順守|
|影響分析|差分起点の関係・ファイル・画面・Check調査|知識基盤優先、未確認の関係を確定しない|
|PG|承認済影響範囲内で変更、固定生成ツール利用|無関係な変更禁止|
|UT|TDD、変更仕様の検証、Coverage|失敗を隠す期待値変更禁止|
|Test Plan|仕様に基づくCase、データ条件、期待値、網羅性|実装観察を正式仕様にしない、DB書込不可|
|Test Data|有限候補探索、前提・安全性検証、租約|任意SQL書込、Inspector追加、無制限探索禁止|

## 4. Skill ライブラリ
|Skill|適用条件|手順と終了条件|
|---|---|---|
|design-diff|対象版指定|差分取得、出典、未決事項を返す|
|change-analysis|差分取得済|変更要求を整理、G1へ|
|impact-analysis|G1承認済|関係を調査、G2へ|
|programming / tdd|G2承認済|固定生成・変更・テスト・Coverage|
|test-planning|画面と変更範囲確定|Check一覧、論理Case、要求、gaps|
|check-analysis|Check対象|順序、適用条件、境界、到達性|
|data-investigation / data-search|データ要求あり|Recipe、UI、DB、静的対応、有限探索|
|data-preparation / data-validation|候補あり|安全性、予約、前置検証、復旧方針|
|ui-inspection|未知画面・binding不足|DOM/Table、意味対応、一意性|
|natural-language-script|論理計画・録制あり|操作文、DSL候補、差分、期待値|
|ui-execution|承認・READY|Runner起動、状態・結果取得|
|failure-analysis|失敗|原因分類、証拠、再開条件|
|evidence-generation|結果確定|追跡、マスク、報告書|
Skill は役割を増やすためでなく、手順を再利用するために分割する。SKILL.md に目的、発火条件、入力、手順、禁止、出力、完了条件を記載。長い例、Schema、テンプレートは references/ に分離。共通JDBCの具体表や業務Checkをハードコードしない。

## 5. リポジトリ構成（候補）
```text
.github/agents/pg-ut.agent.md
.github/agents/impact-analysis.agent.md
.github/agents/pg.agent.md
.github/agents/ut.agent.md
.github/agents/test-plan.agent.md
.github/agents/test-data.agent.md
.github/skills/<skill-name>/SKILL.md
.github/skills/<skill-name>/references/
.vscode/mcp.json
ui-tests/plans/
ui-tests/scenarios/
ui-tests/definitions/
ui-tests/screen-mappings/
```
ディレクトリの発見規則は対象 harness と組織設定で確認する。個人データ、接続情報、実行証跡は Git 外。行数は品質尺度ではない。Test Plan Skill 500～750行、Test Data 450～750行は初期見積であり、動的SQL制約に合わせて PoC 後に改定する。Inspector 前提の旧見積は採用しない。

## 6. 公式資料（確認日 2026-11-24）
- [Custom agents in VS Code](https://code.visualstudio.com/docs/agent-customization/custom-agents)
- [Custom agent file reference](https://code.visualstudio.com/docs/agents/reference/custom-agent-file-reference)
- [Subagents](https://code.visualstudio.com/docs/agents/run/subagents)
- [Agent Skills](https://code.visualstudio.com/docs/agent-customization/agent-skills)

```mermaid
flowchart TD
 U[利用者] --> M[PG/UT Main Agent]
 M --> I[影響分析]
 M --> P[PG]
 M --> T[UT]
 M --> L[テスト計画]
 M --> D[テストデータ]
 M --> X[必要時の臨時委譲]
 I --> R[構造化成果物]
 P --> R
 T --> R
 L --> R
 D --> R
 X --> R
 R --> M
```

*参考図 30　単一入口と委譲（設計内容に基づく再構成図）*

## 関連設計書

- [02　PG/UT Agent 処理フロー設計書](02_PG_UT_Agent_処理フロー設計書.md)
- [03　テスト計画 Agent 詳細設計書](03_テスト計画_Agent_詳細設計書.md)
- [04　テストデータ Agent 詳細設計書](04_テストデータ_Agent_詳細設計書.md)
- [12　MCP インターフェース仕様書](12_MCP_インターフェース仕様書.md)

## 残課題・確定条件

実システムの代表画面、設計書、データ権限、対象 Copilot harness、既存 MCP 契約及び成果物テンプレートを確認して差分改訂する。未確認仕様・実装・試験結果を確定済みとして扱わない。
