# 02　PG/UT Agent 処理フロー設計書

> 文書ID：PGUT-D02　｜　版：1.1 図表形式改訂案　｜　作成日：2026-11-24  
> 基準資料：PG/UT Agent UI Test Design v0.3（第2, 3, 11, 14, 16, 19章）  
> 状態：詳細設計案・未実装／実システム未検証。業務名、ID、画面、数値、API は明示のない限り提案例。

[設計書一覧](README.md)

## 1. 処理方針
Main Agent が工程・成果物の唯一の統括責任を持つ。UI Test は独立した利用者向け Agent ではなく Main の工程である。専門タスクは影響分析、PG、UT、Test Plan、Test Data に委譲する。既存の固定生成ツールを PG 工程で利用し、TDD により変更仕様を検証する。テスト計画は変更後のコードから期待値を逆算しないよう、承認済設計差分から開始できる。

*図 02-01　工程と承認ゲート（設計図）*

```mermaid
flowchart TD
  n0["設計差分取得"]
  n1["変更内容整理"]
  n2["承認 G1"]
  n3["影響分析"]
  n4["承認 G2"]
  n5["PG・TDD・UT"]
  n6["論理テスト計画"]
  n7["環境準備"]
  n8["データ要求・画面調査"]
  n9["自然言語・DSL 編集"]
  n10["承認 G3"]
  n11["Runner"]
  n12["結果・証跡"]
  n13["失敗調査"]
  n0 --> n1
  n1 --> n2
  n2 --> n3
  n3 --> n4
  n4 --> n5
  n4 --> n6
  n5 --> n7
  n6 --> n8
  n7 --> n8
  n8 --> n9
  n9 --> n10
  n10 --> n11
  n11 --> n12
  n11 --> n13
  n13 --> n9
```

## 2. 工程定義
|工程ID|担当|入力|処理・終了条件|出力|
|---|---|---|---|---|
|P01|Main|対象版、業務|知識基盤から詳細設計差分を取得、出典確認|差分セット|
|P02|Main|差分|変更内容と未決事項を整理、G1 承認|変更要求|
|P03|影響分析|承認済変更要求|変更・影響ファイル、共通処理、画面、Check の候補を列挙、G2 承認|影響分析結果|
|P04|PG/UT|G2結果|既存生成ツール、TDD、実装、UT、変更対象 Coverage|コード revision、UT 証跡|
|P05|Test Plan|G2結果、Snapshot|仕様一覧、Check、条件、境界、期待値、未調査箇所|論理 Case、データ要求|
|P06|Main / Test Data|実行環境、Case|既存候補の探索・検証、必要な権限・隔離|lease、変数、BLOCKED理由|
|P07|Main / Skill|Case、実画面|Inspector、Recorder、要素紐付け、DSL候補|編集可能な定義|
|P08|Main / 人|草稿|Studioで確認・差分再解析、G3承認|承認済 revision|
|P09|Runner|承認版、lease|事前条件検査、順次実行、結果保存|Run、Evidence|
|P10|Main|結果|失敗分類、必要時再PG又は再承認、成果物|報告書・未解決一覧|

## 3. 工程間契約
各委譲は task_id、subtask_id、project_id、snapshot_id、base_revision、目的、入力参照、許可ツール、調査予算、終了条件を持つ。返却は status、artifact_refs、evidence_refs、gaps、recommendation とする。子タスクは親の承認済成果物を書き換えず、候補を別領域へ保存する。Main のみ比較更新で統合する。独立な論理計画と PG は並行可能だが、同じファイル・DB・Chrome を同時に操作しない。

## 4. 人工承認と再開
G1 変更内容、G2 影響範囲、G3 UI 定義。データ書込や外部副作用は別途許可が必要。Studio 保存後の自由文変更は G3 を無効にし、Main が差分を取得して再解析する。Web ボタンが Copilot を自動起動するとは仮定しない。ユーザが VS Code に戻り task_id を指定して継続する。MCP は人間の編集を無期限に待たない。

## 5. 状態遷移

*図 02-02　タスクの状態遷移（設計図）*

```mermaid
flowchart TD
  n0["DRAFT"]
  n1["REVIEW_REQUIRED"]
  n2["REVISING"]
  n3["APPROVED"]
  n4["READY"]
  n5["RUNNING"]
  n6["PAUSED"]
  n7["FAILED"]
  n8["RECOVERY_REQUIRED"]
  n9["COMPLETED"]
  n10["BLOCKED"]
  n0 --> n1
  n1 --> n2
  n2 --> n1
  n1 --> n3
  n3 --> n4
  n4 --> n5
  n5 --> n6
  n6 --> n5
  n5 --> n7
  n5 --> n8
  n5 --> n9
  n7 --> n2
  n8 --> n10
```

READY は承認だけでなく、環境・データ・画面 binding・変数の検証済みを意味する。RUNNING は revision 固定。新規編集は別草稿とし、実行中の内容を変更しない。中断時に未終了の書込ステップがある場合は RECOVERY_REQUIRED。成功判定できない場合は BLOCKED、NOT_RUN、INCONCLUSIVE 等を使い分ける。

## 6. 異常時処理
|異常|処理|再開条件|
|---|---|---|
|知識不足|不足項目を明示し調査委譲|根拠確定又は範囲除外を人が承認|
|データ不足|Test Data の有限探索|前提条件と安全性検証|
|仕様不整合|仕様と実装を別記録|正式な期待値を確認|
|コード欠陥|PG/UTへ戻す|新コード版と回帰範囲確定|
|Locator 不一致|実画面再調査|同一業務項目の再紐付けと必要な再承認|
|更新結果不明|書込再試行禁止|状態確認、復旧許可又は新規隔離データ|

```mermaid
flowchart TD
 N0["設計差分取得"]
 N1["変更内容整理"]
 N2["人工承認①"]
 N3["影響分析"]
 N4["人工承認②"]
 N5["PG・UTとテスト計画"]
 N6["データ準備"]
 N7["スクリプト承認"]
 N8["UI実行"]
 N9["成果物"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
 N3 --> N4
 N4 --> N5
 N5 --> N6
 N6 --> N7
 N7 --> N8
 N8 --> N9
```

*参考図 01　PG/UT全体フロー（設計内容に基づく再構成図）*


```mermaid
flowchart TD
 N0["Copilot が草案を保存"]
 N1["Studio で編集"]
 N2["修訂差分を保存"]
 N3["Copilot で再解析"]
 N4["承認"]
 N5["Runner"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
 N3 --> N4
 N4 --> N5
```

*参考図 21　人工確認の連携（設計内容に基づく再構成図）*


```mermaid
flowchart TD
 A[実行停止・証跡保存] --> B{副作用と前提状態を確認}
 B -->|再開可能| C[現在ステップから再開]
 B -->|復旧可能| D[データ復旧・チェックポイント再実行]
 B -->|不明または不可逆| E[隔離・人工判断]
```

*参考図 35　実行状態と復旧（設計内容に基づく再構成図）*

## 関連設計書

- [03　テスト計画 Agent 詳細設計書](03_テスト計画_Agent_詳細設計書.md)
- [04　テストデータ Agent 詳細設計書](04_テストデータ_Agent_詳細設計書.md)
- [07　Test DSL データ構造設計書](07_Test_DSL_データ構造設計書.md)
- [10　UI Test Studio 画面設計書](10_UI_Test_Studio_画面設計書.md)
- [11　Test Runner 詳細設計書](11_Test_Runner_詳細設計書.md)
- [13　Agent / Skill 定義書](13_Agent___Skill_定義書.md)

## 残課題・確定条件

実システムの代表画面、設計書、データ権限、対象 Copilot harness、既存 MCP 契約及び成果物テンプレートを確認して差分改訂する。未確認仕様・実装・試験結果を確定済みとして扱わない。
