# 08　Legacy UI Inspector 詳細設計書

> 文書ID：PGUT-D08　｜　版：1.1 図表形式改訂案　｜　作成日：2026-11-24  
> 基準資料：PG/UT Agent UI Test Design v0.3（第7, 20.1章）  
> 状態：詳細設計案・未実装／実システム未検証。業務名、ID、画面、数値、API は明示のない限り提案例。

[設計書一覧](README.md)

## 1. 方式
既存 JSP ソースを完全解析する方式ではなく、Chrome の実行時 DOM を主とする。Struts タグ、自作タグ、JavaScript の描画結果を取得する。静的 JSP、ActionForm、画面項目定義は意味の補助に限定する。アプリサーバに Inspector を追加しない。DOM 解析ツールはテスト用ブラウザ側で動作する。

*図 08-01　DOM解析と業務意味の分離（設計図）*

```mermaid
flowchart TD
  n0["管理対象Chrome"]
  n1["Frame・Form・DOM採取"]
  n2["Table論理グリッド"]
  n3["座標・可視性・属性"]
  n4["候補項目"]
  n5["画面項目定義・JSP"]
  n6["意味照合"]
  n7["Locator検証"]
  n8["承認済Binding"]
  n9["曖昧・人工拾取"]
  n0 --> n1
  n1 --> n2
  n1 --> n3
  n2 --> n4
  n3 --> n4
  n5 --> n6
  n4 --> n6
  n6 --> n7
  n7 --> n8
  n7 --> n9
```

## 2. 抽出対象
|対象|取得項目|
|---|---|
|Page/Frame|session_id, page_id, frame_id, URL, 親frame、generation|
|Form|name, id, action, method、所属画面|
|操作要素|tag, name, id, type, value候補, readonly, disabled, maxlength, options|
|構造|親子、隣接文字、Table、行、セル、見出し候補|
|空間|getBoundingClientRect、computed style、必要な文字範囲|
|状態|可視性、操作可能性、特征要素、DOM差分|
値の全量取得は禁止を初期設定とし、対象業務キーなど必要情報だけを返す。hidden は状態調査に利用可能だが書換操作はしない。アクセシビリティ snapshot だけに依存しない。

## 3. Table 解析アルゴリズム
1. 各 Frame 内の Table を列挙し、親 Table と親セルを記録する。layout、detail、mixed の分類は候補であり、単一のタグ構造から断定しない。
2. 現在 Table に直接属する行・セルのみ取得する（closest table が一致）。ネスト Table の行を親へ混入させない。
3. DOM 順に論理行を割当て、各セルを最初の空き列に配置する。rowspan/colspan の占有マスを origin cell 参照で埋める。rowspan=0 は row group の残行。異常な重なりは曖昧とする。
4. 非表示セルも論理座標を保持する。実際の表示位置・サイズと論理座標を別管理し、非表示除外で列番号をずらさない。
5. th、scope、headers があれば優先し、なければ先頭行・文字・配置・設計書を用いて多段見出し候補を構成する。正解未確認なら候補のまま返す。
6. 明細行の識別は業務キーを優先し、単一キーで重複する場合は複合キーを使う。キーが不明なら人工確認。単純 nth は初期既定にしない。

## 4. 解析例（仮想）
|DOMセル|論理座標|意味パス|
|---|---|---|
|商品番号 rowspan=2|(0,0),(1,0)|商品番号|
|変更前 colspan=2|(0,1),(0,2)|変更前|
|変更後 colspan=2|(0,3),(0,4)|変更後|
|数量（第2見出し行）|(1,3)|変更後.数量|
|商品A002の数量 input|(3,3) 等|A002 / 変更後.数量|

```mermaid
flowchart TD
 A[Table] --> B[レイアウト型]
 A --> C[明細型]
 A --> D[複合・入れ子型]
 B --> E[項目名と入力欄の対応]
 C --> F[列・業務行・重複name]
 D --> G[親子構造・結合セル]
```

*参考図 13　Tableの分類（設計内容に基づく再構成図）*


![複雑Tableの画面例](images/08_03.png)

*参考図 14　複雑Tableの画面例（v0.3 から継承した概念図、一部中国語表記）*


![複雑Table解析例](images/08_04.png)

*参考図 36　複雑Table解析例（v0.3 から継承した概念図、一部中国語表記）*

## 5. Locator 選択と検証
優先順は確定した id/name、form/frame の範囲、Table識別、行業務キー、列意味パス、安定属性の組合せ。CSS/XPath は実装方法として利用可。座標は意味照合・人工選択に利用し、正式操作の既定にはしない。操作前に画面状態、対象業務行、元素数1、可視性、可操作性を再確認する。再描画後の古い element handle を使わない。name 重複の場合、表・行・列まで限定する。並べ替えやページング後に同じ業務行を見つけられなければ BLOCKED。

## 6. インターフェース・制限
|操作|入力|出力|
|---|---|---|
|inspect_screen|session/frame, scope|画面概要、要素、状態、Table一覧|
|get_table_structure|table_ref|論理グリッド、見出し候補、曖昧点|
|get_table_rows|table_ref, key/filter, limit|必要範囲の行、業務キー候補|
|resolve_locator|target_ref, state, row predicates|候補と根拠|
|validate_locator|binding_ref, session|match_count, visible, actionable, evidence|
|get_screen_changes|before/after generation|構造差分|
未知画面進入、動的項目、Locator失敗、コード改版時に按需解析する。既知の正式テストは必要局所のみ検証する。複雑なカスタムUI、Frame/Pupup、動的レイアウト、権限差は実画面 PoC が必要。完全認識は保証しない。

```mermaid
flowchart TD
 N0["実行時DOM・配置"]
 N1["項目候補の抽出"]
 N2["設計書・JSPによる補足"]
 N3["意味対応"]
 N4["Locator検証"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
 N3 --> N4
```

*参考図 12　実行時解析と静的調査（設計内容に基づく再構成図）*


```mermaid
flowchart TD
 N0["画面状態"]
 N1["対象Table"]
 N2["業務キーによる行特定"]
 N3["name・列による項目特定"]
 N4["一意性・操作可能性検証"]
 N0 --> N1
 N1 --> N2
 N2 --> N3
 N3 --> N4
```

*参考図 15　Locator選択（設計内容に基づく再構成図）*

## 関連設計書

- [07　Test DSL データ構造設計書](07_Test_DSL_データ構造設計書.md)
- [09　UI Recorder 詳細設計書](09_UI_Recorder_詳細設計書.md)
- [10　UI Test Studio 画面設計書](10_UI_Test_Studio_画面設計書.md)
- [11　Test Runner 詳細設計書](11_Test_Runner_詳細設計書.md)

## 残課題・確定条件

実システムの代表画面、設計書、データ権限、対象 Copilot harness、既存 MCP 契約及び成果物テンプレートを確認して差分改訂する。未確認仕様・実装・試験結果を確定済みとして扱わない。
